export type TElementType = number;
