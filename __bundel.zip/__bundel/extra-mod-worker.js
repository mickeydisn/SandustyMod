"use strict";
(self.webpackChunksand_v1 = self.webpackChunksand_v1 || []).push([[247], {
    57393(e, t, r) {
        r.d(t, {
            createExternalWorkerEntryRuntime: () => $
        });
        var l = r(46781)
          , o = r(38163)
          , i = r(2028);
        const n = Object.freeze({
            Empty: o.vZ.Empty,
            Element: o.vZ.Element,
            Dirt: o.vZ.Dirt,
            SporeSoil: o.vZ.SporeSoil,
            Fog: o.vZ.Fog,
            FogJetpackBlock: o.vZ.FogJetpackBlock,
            FogWater: o.vZ.FogWater,
            FreezingIceSoil: o.vZ.FreezingIceSoil,
            Divider: o.vZ.Divider,
            Grass: o.vZ.Grass,
            Moss: o.vZ.Moss,
            GoldSoil: o.vZ.GoldSoil,
            Petal: o.vZ.Petal,
            FogLava: o.vZ.FogLava,
            Fluxite: o.vZ.Fluxite,
            Block: o.vZ.Block,
            SlidingBlock: o.vZ.SlidingBlock,
            SlidingBlockLeft: o.vZ.SlidingBlockLeft,
            SlidingBlockRight: o.vZ.SlidingBlockRight,
            ConveyorLeft: o.vZ.ConveyorLeft,
            ConveyorRight: o.vZ.ConveyorRight,
            ShakerLeft: o.vZ.ShakerLeft,
            ShakerRight: o.vZ.ShakerRight,
            Stone: o.vZ.Stone,
            VelocitySoaker: o.vZ.VelocitySoaker,
            Ice: o.vZ.Ice,
            Grower: o.vZ.Grower,
            NascentWater: o.vZ.NascentWater,
            SandiumSoil: o.vZ.SandiumSoil,
            Obsidian: o.vZ.Obsidian,
            Crackstone: o.vZ.Crackstone
        })
          , a = Object.freeze({
            Sand: o.RJ.Sand,
            Particle: o.RJ.Particle,
            Water: o.RJ.Water,
            WetSand: o.RJ.WetSand,
            Sandium: o.RJ.Sandium,
            Residue: o.RJ.Residue,
            Gold: o.RJ.Gold,
            Gloom: o.RJ.Gloom,
            Shake: o.RJ.Shake,
            Steam: o.RJ.Steam,
            Fire: o.RJ.Fire,
            FreezingIce: o.RJ.FreezingIce,
            Flame: o.RJ.Flame,
            BurntResidue: o.RJ.BurntResidue,
            Seed: o.RJ.Seed,
            WetSeed: o.RJ.WetSeed,
            Seedling: o.RJ.Seedling,
            Petalium: o.RJ.Petalium,
            Lava: o.RJ.Lava,
            Basalt: o.RJ.Basalt
        })
          , s = Object.freeze({
            Solid: o.es.Solid,
            Liquid: o.es.Liquid,
            Particle: o.es.Particle,
            Gas: o.es.Gas,
            Static: o.es.Static,
            Slushy: o.es.Slushy,
            Wisp: o.es.Wisp,
            Powder: o.es.Powder
        })
          , c = Object.freeze({
            ConveyorLeft: o.ev.ConveyorLeft,
            ConveyorRight: o.ev.ConveyorRight,
            ShakerLeft: o.ev.ShakerLeft,
            ShakerRight: o.ev.ShakerRight,
            LauncherUp: o.ev.LauncherUp,
            LauncherLeft: o.ev.LauncherLeft,
            LauncherRight: o.ev.LauncherRight,
            SplitterLeft: o.ev.SplitterLeft,
            SplitterRight: o.ev.SplitterRight,
            Dropper: o.ev.Dropper,
            Foundation: o.ev.Foundation,
            FoundationAngledLeft: o.ev.FoundationAngledLeft,
            FoundationTriangleLeftDel: o.ev.FoundationTriangleLeftDel,
            FoundationAngledRight: o.ev.FoundationAngledRight,
            FoundationTriangleRightDel: o.ev.FoundationTriangleRightDel,
            Collector: o.ev.Collector,
            FilterLeft: o.ev.FilterLeft,
            FilterRight: o.ev.FilterRight,
            SlidingFoundation: o.ev.SlidingFoundation,
            VelocitySoaker: o.ev.VelocitySoaker,
            Grower: o.ev.Grower,
            SoundBox: o.ev.SoundBox,
            Pipe: o.ev.Pipe,
            Pump: o.ev.Pump,
            LiquidVent: o.ev.LiquidVent,
            Light: o.ev.Light,
            FluxEmanator: o.ev.GloomEmitter
        })
          , d = Object.freeze({
            Weapon: o.SP.Weapon,
            Tool: o.SP.Tool,
            Consumable: o.SP.Consumable,
            Mod: o.SP.Mod
        })
          , u = Object.freeze({
            Shovel: o.Np.Shovel,
            Grabber: o.Np.Grabber,
            Demolisher: o.Np.Demolisher,
            GrapplingHook: o.Np.GrapplingHook,
            Vacuum: o.Np.Vacuum,
            Gun: o.Np.Gun,
            Copier: o.Np.Copier,
            RocketLauncher: o.Np.RocketLauncher,
            Digger: o.Np.Digger,
            Shotgun: o.Np.Shotgun,
            Teleporter: o.Np.Teleporter,
            Flamethrower: o.Np.Flamethrower,
            PipeRemover: o.Np.PipeRemover,
            Hauler: o.Np.Hauler,
            Cryoblaster: o.Np.Cryoblaster,
            MegaShotgun: o.Np.MegaShotgun
        })
          , p = Object.freeze({
            Bullet: o.Ag.Bullet,
            Rocket: o.Ag.Rocket,
            GrapplingHook: o.Ag.GrapplingHook,
            Fire: o.Ag.Fire,
            Digger: o.Ag.Digger,
            Mod: o.Ag.Mod
        })
          , g = Object.freeze({
            Weapon: o.X2.Weapon,
            Building: o.X2.Building,
            Tool: o.X2.Tool,
            Mod: o.X2.Mod
        })
          , F = Object.freeze({
            Start: o.qy.Start,
            Active: o.qy.Active,
            End: o.qy.End
        })
          , m = Object.freeze({
            Dig: o.V6.Dig,
            Shoot: o.V6.Shoot,
            Spray: o.V6.Spray,
            Laser: o.V6.Laser
        })
          , y = Object.freeze({
            Clip: o.Ih.Clip,
            Single: o.Ih.Single,
            OverTime: o.Ih.OverTime
        })
          , v = Object.freeze({
            Hotbar: o.JU.Hotbar,
            SoundBoxConfig: o.JU.SoundBoxConfig,
            Root: o.JU.Root,
            Menu: o.JU.Menu,
            Management: o.JU.Management,
            FilterConfig: o.JU.FilterConfig,
            Resources: o.JU.Resources,
            TechTree: o.JU.TechTree,
            Tutorial: o.JU.Tutorial,
            Loader: o.JU.Loader,
            Options: o.JU.Options,
            ShortcutHelper: o.JU.ShortcutHelper,
            Upgrades: o.JU.Upgrades,
            Tooltip: o.JU.Tooltip,
            Notifications: o.JU.Notifications,
            Objectives: o.JU.Objectives,
            DroneAdminList: o.JU.DroneAdminList,
            HotbarOverlays: o.JU.HotbarOverlays,
            IntroScreen: o.JU.IntroScreen,
            StoryNotifications: o.JU.StoryNotifications,
            FactoryProgress: o.JU.FactoryProgress,
            Dialogs: o.JU.Dialogs,
            GlobalOverlays: o.JU.GlobalOverlays,
            Lexicon: o.JU.Lexicon,
            ModsScreen: o.JU.ModsScreen,
            CustomMapsScreen: o.JU.CustomMapsScreen,
            CinematicPanel: o.JU.CinematicPanel,
            Feedback: o.JU.Feedback,
            MainMenuActions: o.JU.MainMenuActions,
            HudTopLeft: o.JU.HudTopLeft,
            HudTopRight: o.JU.HudTopRight
        })
          , C = Object.freeze({
            Up: o.$T.Up,
            Down: o.$T.Down,
            Pressed: o.$T.Pressed,
            Released: o.$T.Released,
            All: o.$T.All
        })
          , h = Object.freeze({
            OpenBuildMenu: o.$V.OpenBuildMenu,
            GrapplingHook: o.$V.GrapplingHook,
            Escape: o.$V.Escape,
            OpenTechTree: o.$V.OpenTechTree,
            OpenInventory: o.$V.OpenInventory,
            ReverseBuildDirection: o.$V.ReverseBuildDirection,
            Marquee: o.$V.Marquee,
            Pause: o.$V.Pause,
            Copy: o.$V.Copy,
            Paste: o.$V.Paste,
            Flip: o.$V.Flip,
            Delete: o.$V.Delete,
            PauseCamera: o.$V.PauseCamera,
            OpenUpgrades: o.$V.OpenUpgrades,
            BuildMode: o.$V.BuildMode,
            Demolish: o.$V.Demolish,
            Hover: o.$V.Hover,
            Ruler: o.$V.Ruler,
            Left: o.$V.Left,
            Right: o.$V.Right,
            Boost: o.$V.Boost,
            Descend: o.$V.Descend,
            SprintBoost: o.$V.SprintBoost,
            OverrideReplaceStructures: o.$V.OverrideReplaceStructures,
            QuickSave: o.$V.QuickSave,
            QuickLoad: o.$V.QuickLoad,
            ToggleGameHud: o.$V.ToggleGameHud
        })
          , H = Object.freeze({
            Linear: o.Ww.Linear,
            Rectangular: o.Ww.Rectangular
        })
          , f = Object.freeze({
            Available: o.J6.Available,
            FullyBlocked: o.J6.FullyBlocked,
            PartiallyBlocked: o.J6.PartiallyBlocked,
            CanBeReplaced: o.J6.CanBeReplaced
        })
          , A = Object.freeze({
            NoJetpack: o.s0.NoJetpack,
            NoGrab: o.s0.NoGrab,
            NoBuild: o.s0.NoBuild,
            NoTool: o.s0.NoTool,
            NoExcavation: o.s0.NoExcavation,
            NoToolExceptFlamethrower: o.s0.NoToolExceptFlamethrower
        })
          , S = Object.freeze({
            Digger: o.RG.Digger,
            Hauler: o.RG.Hauler
        })
          , T = Object.freeze({
            Artifact: o.KW.Artifact,
            GlyphKey: o.KW.GlyphKey,
            Stratacore: o.KW.Stratacore,
            Orb: o.KW.Orb
        })
          , b = Object.freeze({
            Available: o.Hu.Available,
            Visible: o.Hu.Visible,
            Researched: o.Hu.Researched,
            Unknown: o.Hu.Unknown,
            Hidden: o.Hu.Hidden
        })
          , k = Object.freeze(Object.assign(Object.assign({}, o.xQ), {
            FluxEmanator: "fluxEmanator"
        }))
          , R = Object.freeze({
            MainMenu: o.Z5.MainMenu,
            Intro: o.Z5.Intro,
            Deploy: o.Z5.Deploy,
            Game: o.Z5.Game
        })
          , B = Object.freeze({
            CellType: n,
            ElementType: a,
            MatterType: s,
            StructureType: c,
            ItemType: d,
            ItemId: u,
            ProjectileType: p,
            ActionType: g,
            ActionState: F,
            AbilityType: m,
            ReloadType: y,
            ComponentId: v,
            KeyBinding: h,
            KeyState: C,
            BuildMode: H,
            BuildingClearance: f,
            AuthorizationType: A,
            DroneType: S,
            PickupType: T,
            WorldItemType: T,
            Scene: R,
            Tech: k,
            TechStatus: b
        })
          , I = Object.freeze({
            normal: i.J8.NORMAL,
            skip: i.J8.SKIP,
            aggressiveSkip: i.J8.AGGRESSIVE_SKIP
        })
          , O = Object.freeze({
            physics: I
        })
          , J = new WeakMap
          , L = e => Object.freeze(e)
          , w = e => void 0 === (null == e ? void 0 : e.durationTicks) ? e : Object.assign(Object.assign({}, e), {
            duration: e.durationTicks
        })
          , P = {
            uint8: Uint8Array,
            uint16: Uint16Array,
            uint32: Uint32Array,
            int8: Int8Array,
            int16: Int16Array,
            int32: Int32Array,
            float32: Float32Array,
            float64: Float64Array
        }
          , D = (e, t) => {
            if ("string" != typeof t || 0 === t.length)
                throw new TypeError("Shared buffer key must be a nonempty string.");
            return `external:${e}:${t}`
        }
          , V = (e, t, r="__anonymous") => {
            let o = J.get(e);
            const i = null == o ? void 0 : o.get(r);
            if (void 0 !== i) {
                if (i.adapter !== t)
                    throw new Error("A worker State cannot be rebound to a different local event adapter.");
                return i.facade
            }
            const n = ( (e, t, r) => {
                const o = e
                  , i = e => "string" == typeof e ? l.FH.elements.getElementTypeFromId(o, e) : e
                  , n = L({
                    getValueFromCellId: e => l.FH.collector.getValueFromCellId(o, e),
                    getValueByType: e => l.FH.collector.getValueFromElementType(o, e),
                    isCellIdCollectable: e => l.FH.collector.isCellCollectable(o, e),
                    isCellIdCollectableForSprite: e => l.FH.collector.isCellCollectableForSprite(o, e),
                    notifyPickupAtCell: (e, t) => {
                        l.FH.collector.notifyPickup(o, e, t)
                    }
                })
                  , a = (e, t, r) => {
                    const i = l.FH.effects.createLight(o, e, t, (e => void 0 === (null == e ? void 0 : e.durationTicks) ? e : Object.assign(Object.assign({}, e), {
                        duration: e.durationTicks
                    }))(r));
                    return {
                        lightId: i.index,
                        index: i.index
                    }
                }
                  , s = (e, t, r, i) => {
                    l.FH.effects.createEffect(o, e, t, r, i)
                }
                  , c = L({
                    createAtWorld: s,
                    createEffectAtWorld: s,
                    createLightAtWorld: a,
                    createParticlesAtWorld: (e, t, r) => {
                        l.FH.effects.createParticles(o, e, t, r)
                    }
                })
                  , d = L({
                    createAtWorld: a
                })
                  , u = L({
                    temporary: d,
                    vfx: d
                })
                  , p = e => l.FH.elements.getElementTypeFromId(o, e)
                  , g = (e, t, r, i) => l.FH.elements.swap(o, e, t, r, i)
                  , F = e => {
                    l.FH.elements.markMovementBlocked(o, e)
                }
                  , m = L({
                    getTypeById: p,
                    getTypeFromId: p,
                    getIdByType: e => l.FH.elements.getElementIdFromType(o, e),
                    getDefinitionByType: e => l.FH.elements.getConfig(e),
                    getTypeAtCell: (e, t) => l.FH.elements.getTypeAtCell(o, e, t),
                    getResolvedTypeAtCell: (e, t) => l.FH.elements.getResolvedTypeAtCell(o, e, t),
                    getResolvedTypeFromCellId: e => l.FH.elements.getResolvedTypeFromCellId(o, e),
                    getInfoAtCell: (e, t) => l.FH.elements.getInfoAtCell(o, e, t),
                    getMatterTypeAtCell: (e, t) => l.FH.elements.getMatterTypeAtCell(o, e, t),
                    isTypeAtCell: (e, t, r) => l.FH.elements.isTypeAt(o, e, t, i(r)),
                    isFreeFallingAtCell: (e, t) => null !== l.FH.elements.getResolvedTypeAtCell(o, e, t) && l.FH.elements.isFreeFalling(o, e, t),
                    createAtCell: (e, t, r, n) => {
                        l.FH.world.isCellEmpty(o, e, t) && l.FH.elements.createAt(o, e, t, i(r), w(n))
                    }
                    ,
                    replaceAtCell: (e, t, r, n) => {
                        l.FH.elements.replaceAt(o, e, t, i(r), w(n))
                    }
                    ,
                    removeAtCell: (e, t, r) => {
                        null !== l.FH.elements.getResolvedTypeAtCell(o, e, t) && l.FH.elements.removeAt(o, e, t, r)
                    }
                    ,
                    moveBetweenCells: (e, t, r, i) => l.FH.elements.move(o, e, t, r, i),
                    teleportBetweenCells: (e, t, r, i) => {
                        l.FH.elements.teleport(o, e, t, r, i)
                    }
                    ,
                    swapBetweenCells: g,
                    swapCells: g,
                    getVelocityAtCell: (e, t) => null === l.FH.elements.getResolvedTypeAtCell(o, e, t) ? null : l.FH.elements.getVelocity(o, e, t),
                    setVelocityAtCell: (e, t, r) => l.FH.elements.setVelocity(o, e, t, r),
                    addParticleVelocityAtCell: (e, t, r, i) => l.FH.elements.addParticleVelocity(o, e, t, r, i),
                    convertToParticleAtCell: (e, t, r) => l.FH.elements.convertToParticle(o, e, t, r),
                    convertFromParticleAtCell: (e, t) => l.FH.elements.convertFromParticle(o, e, t),
                    getDataFieldAtCell: (e, t, r) => null === l.FH.elements.getResolvedTypeAtCell(o, e, t) ? null : l.FH.elements.getDataField(o, e, t, r),
                    setDataFieldAtCell: (e, t, r, i) => null !== l.FH.elements.getResolvedTypeAtCell(o, e, t) && l.FH.elements.setDataField(o, e, t, r, i),
                    refreshColorAtCell: (e, t) => {
                        l.FH.elements.refreshColorAt(o, e, t)
                    }
                    ,
                    markMovementBlockedByIndex: F,
                    markMovementBlockedByElementIndex: F,
                    setPhysicsAtCell: (e, t, r) => {
                        null !== l.FH.elements.getResolvedTypeAtCell(o, e, t) && (l.FH.elements.setPhysics(o, e, t, r),
                        l.FH.world.reportActivityToChunk(o, e, t))
                    }
                    ,
                    setDurationAtCell: (e, t, r, i) => null !== l.FH.elements.getResolvedTypeAtCell(o, e, t) && l.FH.elements.setDuration(o, e, t, r, i)
                })
                  , y = L({
                    on: (e, l, o) => t.on(e, l, o, r),
                    emit: (e, r, l) => {
                        t.emit(e, r, l)
                    }
                })
                  , v = L({
                    intercept: (e, l, o) => t.intercept(e, l, o, r),
                    modify: (e, l, o) => t.modify(e, l, o, r)
                })
                  , C = L({
                    getActive: () => l.FH.maps.getActive(e)
                })
                  , h = L({
                    canBurnElementAtCell: (e, t) => l.FH.fire.canBurnElementAt(o, e, t),
                    burnElementAtCell: (e, t) => !!l.FH.fire.canBurnElementAt(o, e, t) && l.FH.fire.burnElementAt(o, e, t)
                })
                  , H = L({
                    createCircle: e => l.FH.patterns.createCircle(e),
                    excavateAtCell: (e, t, r, i, n, a) => {
                        l.FH.patterns.excavate(o, e, t, r, i, n, a)
                    }
                })
                  , f = () => l.FH.player.getPosition(o)
                  , A = L({
                    getPositionAtWorld: f,
                    getWorldPosition: f,
                    isCollidingWithCell: (e, t) => l.FH.player.isCollidingWithCell(o, e, t),
                    isWithinRadiusOfCell: (e, t, r) => l.FH.player.isWithinRadius(o, e, t, r)
                })
                  , S = L({
                    int: l.FH.random.int,
                    float: l.FH.random.float
                })
                  , T = (e, t) => l.FH.structures.processing.isEnabledAt(o, e, t)
                  , b = (e, t, r) => {
                    l.FH.structures.setData(o, e, t, r)
                }
                  , k = e => l.FH.structures.resolveTypeName(e)
                  , R = L({
                    processing: L({
                        isEnabledAtCell: T,
                        isEnabledAt: T
                    }),
                    getAtCell: (e, t) => l.FH.structures.getAtCell(o, e, t),
                    getDefinitionByType: e => l.FH.structures.getConfig(e),
                    getTypeById: k,
                    getTypeFromId: k,
                    hasBuiltAtCell: (e, t) => l.FH.structures.hasBuiltAtCell(o, e, t),
                    isType: (e, t) => l.FH.structures.isType(e, t),
                    isTypeAtCell: (e, t, r) => l.FH.structures.isTypeAt(o, e, t, r),
                    forEachOfType: (e, t) => {
                        l.FH.structures.forEachOfType(o, e, t)
                    }
                    ,
                    update: (e, t) => {
                        l.FH.structures.update(o, e, t)
                    }
                    ,
                    updateData: b,
                    setData: b,
                    setSpritesheetIndex: (e, t) => {
                        l.FH.structures.setSpritesheetIndex(o, e, t)
                    }
                    ,
                    setSpritesheetIndexAtCell: (e, t, r) => {
                        l.FH.structures.setSpritesheetIndexAt(o, e, t, r)
                    }
                    ,
                    setSpritesheetIndexByValue: (e, t, r) => {
                        l.FH.structures.setSpritesheetIndexByValue(o, e, t, r)
                    }
                    ,
                    setSpritesheetIndexByValueAtCell: (e, t, r, i) => {
                        l.FH.structures.setSpritesheetIndexByValueAt(o, e, t, r, i)
                    }
                })
                  , B = e => l.FH.terrains.getTypeByName(o, e)
                  , I = (e, t, r) => l.FH.terrains.setTerrainHP(o, e, t, r)
                  , J = L({
                    getDefinitionByType: e => l.FH.terrains.getConfig(e),
                    getTypeById: B,
                    getTypeFromId: B,
                    getIdByType: e => l.FH.terrains.getIdByType(o, e),
                    getTypeAtCell: (e, t) => l.FH.terrains.getTypeAtCell(o, e, t),
                    getDataAtCell: (e, t) => {
                        const r = l.FH.terrains.getTerrainData(o, e, t);
                        if (null === r)
                            return null;
                        const i = r;
                        return i.hitPoints = r.hp,
                        i
                    }
                    ,
                    isAtCell: (e, t) => l.FH.terrains.isAtCell(o, e, t),
                    isTypeAtCell: (e, t, r) => l.FH.terrains.isTypeAtCell(o, e, t, r),
                    isCellIdTerrain: l.FH.terrains.isCellIdTerrain,
                    createAtCell: (e, t, r, i) => {
                        l.FH.world.isCellEmpty(o, e, t) && l.FH.terrains.createAt(o, e, t, r, i)
                    }
                    ,
                    replaceAtCell: (e, t, r, i) => {
                        l.FH.terrains.replaceAt(o, e, t, r, i)
                    }
                    ,
                    removeAtCell: (e, t, r) => {
                        const i = l.FH.world.getCellId(o, e, t);
                        l.FH.terrains.isCellIdTerrain(i) && l.FH.terrains.removeAt(o, e, t, r)
                    }
                    ,
                    damageAtCell: (e, t, r) => {
                        l.FH.terrains.damageTerrain(o, e, t, r)
                    }
                    ,
                    setHitPointsAtCell: I,
                    setHpAtCell: I
                })
                  , V = L({
                    toast: (e, t) => {
                        l.FH.ui.toast(o, e, t)
                    }
                })
                  , E = L({
                    getDistance: l.FH.utils.getDistance,
                    getDirection: l.FH.utils.getDirection,
                    getAngle: l.FH.utils.getAngle,
                    getCoordinatesBetweenCells: l.FH.utils.getCoordinatesBetweenPoints,
                    getCoordinatesBetweenPoints: l.FH.utils.getCoordinatesBetweenPoints
                })
                  , M = L({
                    getDimensions: () => l.FH.world.getDimensions(o),
                    getCellIdAtCell: (e, t) => l.FH.world.getCellId(o, e, t),
                    isCellEmptyAtCell: (e, t) => l.FH.world.isCellEmpty(o, e, t),
                    isTerrainAtCell: (e, t) => l.FH.world.isTerrainAt(o, e, t),
                    reportActivityAtCell: (e, t) => {
                        l.FH.world.reportActivityToChunk(o, e, t)
                    }
                    ,
                    excavateAtCell: (e, t, r, i, n) => {
                        l.FH.world.excavate(o, e, t, r, i, n)
                    }
                })
                  , U = L({
                    require: (e, t) => {
                        const i = D(r, e)
                          , n = l.FH.workers.shared.get(o, i);
                        if (!n)
                            throw new Error(`Shared buffer "${e}" must be created by the main entry before workers load.`);
                        const a = P[t.type];
                        if (!a || n.constructor !== a || n.length !== t.length)
                            throw new Error(`Shared buffer "${e}" has a different type or length.`);
                        return n
                    }
                    ,
                    get: e => l.FH.workers.shared.get(o, D(r, e))
                })
                  , j = L({
                    buffers: U
                })
                  , x = L({
                    emitEvent: (e, r) => {
                        t.emitToMain(e, r)
                    }
                })
                  , $ = L({
                    getIndex: () => e.environment.threadMeta.startingIndex,
                    getCount: () => e.environment.threadMeta.threadCount
                });
                return L({
                    constants: O,
                    collector: n,
                    effects: c,
                    elements: m,
                    events: y,
                    fire: h,
                    grid: M,
                    hooks: v,
                    lights: u,
                    main: x,
                    maps: C,
                    patterns: H,
                    player: A,
                    random: S,
                    shared: j,
                    structures: R,
                    terrains: J,
                    ui: V,
                    utils: E,
                    worker: $,
                    world: M
                })
            }
            )(e, t, r)
              , a = L({
                api: l.FH,
                get state() {
                    return e
                }
            })
              , s = L({
                apiVersion: 1,
                get state() {
                    return e
                },
                api: n,
                engine: a,
                enums: B
            });
            return o || (o = new Map,
            J.set(e, o)),
            o.set(r, {
                adapter: t,
                facade: s
            }),
            s
        }
        ;
        var E = r(59151);
        const M = Object.freeze({
            "terrain:updated": "terrain:update",
            "worker:update:post": "update:post"
        })
          , U = Object.freeze({
            "element:move:blocked": "element:blocked",
            "element:duration:expire": "element:duration"
        })
          , j = (e, t) => {
            const r = e[t];
            return "string" == typeof r ? r : t
        }
          , x = e => e instanceof Error ? e.message : String(e)
          , $ = e => {
            const t = new Set
              , r = (e => ({
                on: (t, r, l, o) => (0,
                E.hQ)(e, j(M, t), (e, t) => {
                    r(t)
                }
                , Object.assign(Object.assign({}, l), {
                    modId: o
                })),
                emit(t, r, l) {
                    E._B.emit(e, j(M, t), r, l)
                },
                intercept: (t, r, l, o) => (0,
                E.cN)(e, j(U, t), (e, t, l) => {
                    r(t, l)
                }
                , Object.assign(Object.assign({}, l), {
                    modId: o
                })),
                modify: (t, r, l, o) => (0,
                E.cM)(e, j(U, t), (e, t) => {
                    r(t)
                }
                , Object.assign(Object.assign({}, l), {
                    modId: o
                })),
                emitToMain(t, r) {
                    (0,
                    E.QL)(e, t, r)
                }
            }))(e);
            return {
                async execute(l) {
                    const o = [];
                    for (let i = 0; i < l.length; i++) {
                        const n = l[i];
                        if (t.has(n.id))
                            o.push({
                                id: n.id,
                                version: n.version,
                                ok: !0,
                                alreadyLoaded: !0
                            });
                        else
                            try {
                                const l = V(e, r, n.id)
                                  , i = `sandkit-workshop://${n.id}/${n.entry}`.replace(/[\r\n]/g, "")
                                  , a = new Function("__sandkit",`"use strict";\nconst sandkit = __sandkit;\nreturn (async () => {\n${n.source}\n})();\n//# sourceURL=${i}`);
                                await a(l),
                                t.add(n.id),
                                o.push({
                                    id: n.id,
                                    version: n.version,
                                    ok: !0
                                })
                            } catch (e) {
                                o.push({
                                    id: n.id,
                                    version: n.version,
                                    ok: !1,
                                    error: x(e)
                                })
                            }
                    }
                    return o
                }
            }
        }
    }
}]);
