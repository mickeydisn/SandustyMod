export const iconsList = [
	{
		"title": ".ENV",
		"hex": "ECD53F",
		"source": "https://github.com/motdotla/dotenv/blob/40e75440337d1de2345dc8326d6108331f583fd8/dotenv.svg",
		"aliases": {
			"aka": [
				"Dotenv"
			]
		}
	},
	{
		"title": ".NET",
		"hex": "512BD4",
		"source": "https://github.com/dotnet/brand/blob/c7d0f51b8ec59531332d05fb27a5b758a7a3d689/logo/dotnet-logo.svg",
		"guidelines": "https://github.com/dotnet/brand/blob/c7d0f51b8ec59531332d05fb27a5b758a7a3d689/dotnet-styleGuide-2024.pdf",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "/e/",
		"hex": "000000",
		"source": "https://doc.e.foundation"
	},
	{
		"title": "1.1.1.1",
		"hex": "221E68",
		"source": "https://one.one.one.one"
	},
	{
		"title": "1&1",
		"hex": "003D8F",
		"source": "https://www.united-internet.de/en/newsroom/media-center/logos.html"
	},
	{
		"title": "1001Tracklists",
		"hex": "40AEF0",
		"source": "https://www.1001tracklists.com"
	},
	{
		"title": "1Panel",
		"hex": "0854C1",
		"source": "https://1panel.cn"
	},
	{
		"title": "1Password",
		"hex": "3B66BC",
		"source": "https://1password.com/press",
		"guidelines": "https://1password.com/press"
	},
	{
		"title": "2FAS",
		"hex": "EC1C24",
		"source": "https://2fas.com/press-kit",
		"guidelines": "https://2fas.com/press-kit"
	},
	{
		"title": "2K",
		"hex": "DD0700",
		"source": "https://support.2k.com/hc/en-us/articles/203972113-Digital-Copies-of-2K-Manuals"
	},
	{
		"title": "30 seconds of code",
		"hex": "5395FD",
		"source": "https://github.com/Chalarangelo/30-seconds-of-code/blob/44c0ba94857a7796026c6795c47e964126876d5a/logo/logo-resources/logo.svg",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "365 Data Science",
		"hex": "000C1F",
		"source": "https://365datascience.com"
	},
	{
		"title": "3M",
		"hex": "FF0000",
		"source": "https://www.3m.com"
	},
	{
		"title": "42",
		"hex": "000000",
		"source": "https://www.42network.org"
	},
	{
		"title": "4chan",
		"hex": "006600",
		"source": "https://www.4chan.org"
	},
	{
		"title": "4D",
		"hex": "004088",
		"source": "https://www.4d.com"
	},
	{
		"title": "500px",
		"hex": "222222",
		"source": "https://500px.com"
	},
	{
		"title": "7Zip",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:7ziplogo.svg"
	},
	{
		"title": "99designs",
		"hex": "FE5F50",
		"source": "https://99designs.com/branding",
		"guidelines": "https://99designs.com/branding"
	},
	{
		"title": "9GAG",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:9gag_logo.svg"
	},
	{
		"title": "A-Frame",
		"hex": "EF2D5E",
		"source": "https://aframe.io/docs"
	},
	{
		"title": "ABB RobotStudio",
		"hex": "FF9E0F",
		"source": "https://new.abb.com/products/robotics/en/robotstudio/downloads"
	},
	{
		"title": "Abbott",
		"hex": "008FC7",
		"source": "https://commons.wikimedia.org/wiki/File:Logo_Abbott_Laboratories.svg"
	},
	{
		"title": "Abbvie",
		"hex": "071D49",
		"source": "https://www.abbvie.com"
	},
	{
		"title": "About.me",
		"hex": "333333",
		"source": "https://about.me/assets",
		"guidelines": "https://about.me/assets"
	},
	{
		"title": "Abstract",
		"hex": "191A1B",
		"source": "https://www.abstract.com/about"
	},
	{
		"title": "abuse.ch",
		"hex": "00465B",
		"source": "https://abuse.ch"
	},
	{
		"title": "Academia",
		"hex": "41454A",
		"source": "https://www.academia.edu"
	},
	{
		"title": "Accenture",
		"hex": "A100FF",
		"source": "https://www.accenture.com"
	},
	{
		"title": "Accusoft",
		"hex": "A9225C",
		"source": "https://www.accusoft.com"
	},
	{
		"title": "AccuWeather",
		"hex": "FF6600",
		"source": "https://accuweather.com"
	},
	{
		"title": "Acer",
		"hex": "83B81A",
		"source": "https://www.acer.com"
	},
	{
		"title": "ACM",
		"hex": "0085CA",
		"source": "https://identitystandards.acm.org"
	},
	{
		"title": "ActiGraph",
		"hex": "0B2C4A",
		"source": "https://www.actigraphcorp.com"
	},
	{
		"title": "Activision",
		"hex": "000000",
		"source": "https://www.activision.com"
	},
	{
		"title": "ActivityPub",
		"hex": "F1007E",
		"source": "https://activitypub.rocks",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "Actix",
		"hex": "000000",
		"source": "https://github.com/actix/actix-website/issues/18#issuecomment-393581556"
	},
	{
		"title": "Actual Budget",
		"hex": "6B46C1",
		"source": "https://github.com/actualbudget/actual/blob/84af8b76be6bb6c866c32a5be6e8c7a092ab9e38/packages/desktop-client/src/icons/logo/logo.svg"
	},
	{
		"title": "Acura",
		"hex": "000000",
		"source": "https://www.acura.com",
		"guidelines": "https://www.honda.com/privacy/terms-and-conditions"
	},
	{
		"title": "Adafruit",
		"hex": "000000",
		"source": "https://www.adafruit.com"
	},
	{
		"title": "AdBlock",
		"hex": "F40D12",
		"source": "https://getadblock.com"
	},
	{
		"title": "Adblock Plus",
		"hex": "C70D2C",
		"source": "https://adblockplus.org"
	},
	{
		"title": "addy.io",
		"hex": "19216C",
		"source": "https://addy.io",
		"guidelines": "https://addy.io/brand"
	},
	{
		"title": "AdGuard",
		"hex": "68BC71",
		"source": "https://adguard.com/en/media-materials.html"
	},
	{
		"title": "Adidas",
		"hex": "000000",
		"source": "https://www.adidas.com"
	},
	{
		"title": "Adminer",
		"hex": "34567C",
		"source": "https://www.adminer.org"
	},
	{
		"title": "AdonisJS",
		"hex": "5A45FF",
		"source": "https://adonisjs.com",
		"guidelines": "https://adonisjs.notion.site/adonisjs/Welcome-to-the-AdonisJS-Brand-Assets-Guidelines-a042a6d0be7640c6bc78eb32e1bbaaa1"
	},
	{
		"title": "ADP",
		"hex": "D0271D",
		"source": "https://www.adp.com",
		"guidelines": "https://www.adp.com/legal.aspx"
	},
	{
		"title": "Adroll",
		"hex": "0DBDFF",
		"source": "https://www.adroll.com"
	},
	{
		"title": "Advent Of Code",
		"hex": "FFFF66",
		"source": "https://adventofcode.com"
	},
	{
		"title": "Adyen",
		"hex": "0ABF53",
		"source": "https://www.adyen.com/press-and-media/presskit",
		"guidelines": "https://www.adyen.com/press-and-media/presskit"
	},
	{
		"title": "Aegis Authenticator",
		"hex": "005E9D",
		"source": "https://getaegis.app/aegis.svg"
	},
	{
		"title": "Aer Lingus",
		"hex": "006272",
		"source": "https://www.aerlingus.com"
	},
	{
		"title": "Aeroflot",
		"hex": "02458D",
		"source": "https://www.aeroflot.ru/ru-en/information/onboard/press"
	},
	{
		"title": "Aeroméxico",
		"hex": "0B2343",
		"source": "https://www.aeromexico.com"
	},
	{
		"title": "Aerospike",
		"hex": "C22127",
		"source": "https://pages.aerospike.com/rs/aerospike/images/Acid_Whitepaper.pdf"
	},
	{
		"title": "AEW",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:AEW_Logo_(simplified).svg",
		"aliases": {
			"aka": [
				"All Elite Wrestling"
			]
		}
	},
	{
		"title": "AFDIAN",
		"hex": "946CE6",
		"source": "https://afdian.com/album/248b4bb2c9b111e9a9bb52540025c377/c3d32ae4b5f311eab4a952540025c377",
		"guidelines": "https://afdian.com/album/248b4bb2c9b111e9a9bb52540025c377/c3d32ae4b5f311eab4a952540025c377",
		"aliases": {
			"loc": {
				"zh-CN": "爱发电"
			}
		}
	},
	{
		"title": "AFFiNE",
		"hex": "1E96EB",
		"source": "https://affine.pro"
	},
	{
		"title": "Affinity",
		"hex": "222324",
		"source": "https://affinity.serif.com"
	},
	{
		"title": "Affinity Designer",
		"hex": "134881",
		"source": "https://affinity.serif.com/designer"
	},
	{
		"title": "Affinity Photo",
		"hex": "4E3188",
		"source": "https://affinity.serif.com/photo"
	},
	{
		"title": "Affinity Publisher",
		"hex": "891B26",
		"source": "https://affinity.serif.com/publisher"
	},
	{
		"title": "Afterpay",
		"hex": "B2FCE4",
		"source": "https://www.afterpay.com/en-AU/business/resources/marketing/logos",
		"guidelines": "https://www.afterpay.com/en-AU/business/resources/marketing/brand-tools/brand-guidelines"
	},
	{
		"title": "AfterShip",
		"hex": "FF6B2B",
		"source": "https://www.aftership.com"
	},
	{
		"title": "Agora",
		"hex": "099DFD",
		"source": "https://github.com/AgoraIO/Docs-Source/blob/849872dd0496bada0a2dceecb3f79663e3b2d323/assets/images/others/agora-logo.svg"
	},
	{
		"title": "AI Dungeon",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:AI_Dungeon_Logo.png"
	},
	{
		"title": "AIB",
		"hex": "7F2B7B",
		"source": "https://aib.ie",
		"aliases": {
			"aka": [
				"Allied Irish Banks"
			]
		}
	},
	{
		"title": "AIOHTTP",
		"hex": "2C5BB4",
		"source": "https://github.com/aio-libs/aiohttp/blob/fb5fe72b1bca3b899af579d376f5fe45745410e4/docs/aiohttp-plain.svg",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Aiqfome",
		"hex": "7A1FA2",
		"source": "https://github.com/aiqfome/aiq-design-system/blob/457a104c6cb1a42975908fdb05b2e0b83f3fabb4/public/logo.svg"
	},
	{
		"title": "Air Canada",
		"hex": "F01428",
		"source": "https://www.aircanada.com"
	},
	{
		"title": "Air China",
		"hex": "E30E17",
		"source": "https://www.airchina.com.cn/en/investor_relations"
	},
	{
		"title": "Air France",
		"hex": "002157",
		"source": "https://www.airfrance.fr"
	},
	{
		"title": "Air India",
		"hex": "DA0E29",
		"source": "https://www.airindia.com"
	},
	{
		"title": "Air Serbia",
		"hex": "0E203F",
		"source": "https://www.airserbia.com"
	},
	{
		"title": "Air Transat",
		"hex": "172B54",
		"source": "https://www.airtransat.com"
	},
	{
		"title": "AirAsia",
		"hex": "FF0000",
		"source": "https://www.airasia.com/shop"
	},
	{
		"title": "Airbnb",
		"hex": "FF5A5F",
		"source": "https://www.airbnb.com"
	},
	{
		"title": "Airbrake",
		"hex": "FFA500",
		"source": "https://github.com/airbrake/slate/blob/c116f2968bcf4dfda126511de0a2d0f0dc8b6a8e/source/images/logo.svg",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Airbus",
		"hex": "00205B",
		"source": "https://brand.airbus.com/en/asset-library/airbus-logo",
		"guidelines": "https://brand.airbus.com/en/asset-library/airbus-logo"
	},
	{
		"title": "Airbyte",
		"hex": "615EFF",
		"source": "https://airbyte.com"
	},
	{
		"title": "Aircall",
		"hex": "00B388",
		"source": "https://aircall.io"
	},
	{
		"title": "AirPlay Audio",
		"hex": "000000",
		"source": "https://developer.apple.com/design/human-interface-guidelines/airplay/overview/icons",
		"guidelines": "https://www.apple.com/legal/intellectual-property/guidelinesfor3rdparties.html"
	},
	{
		"title": "AirPlay Video",
		"hex": "000000",
		"source": "https://developer.apple.com/design/human-interface-guidelines/airplay/overview/icons/",
		"guidelines": "https://www.apple.com/legal/intellectual-property/guidelinesfor3rdparties.html"
	},
	{
		"title": "Airtable",
		"hex": "18BFFF",
		"source": "https://airtable.com/press"
	},
	{
		"title": "Airtel",
		"hex": "E40000",
		"source": "https://www.airtel.in/logo-tune"
	},
	{
		"title": "Ajv",
		"hex": "23C8D2",
		"source": "https://github.com/ajv-validator/ajv/blob/95b15b683dfb60f63c5129b0426629b968d53af8/docs/.vuepress/public/img/ajv.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Akamai",
		"hex": "0096D6",
		"source": "https://www.akamai.com"
	},
	{
		"title": "Akasa Air",
		"hex": "FF6300",
		"source": "https://www.akasaair.com"
	},
	{
		"title": "Akaunting",
		"hex": "6DA252",
		"source": "https://akaunting.com/logo",
		"license": {
			"type": "GPL-3.0-only"
		}
	},
	{
		"title": "Akiflow",
		"hex": "AF38F9",
		"source": "https://www.akiflow.com"
	},
	{
		"title": "Alacritty",
		"hex": "F46D01",
		"source": "https://github.com/alacritty/alacritty/blob/6d8db6b9dfadd6164c4be7a053f25db8ef6b7998/extra/logo/alacritty-simple.svg",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Alamy",
		"hex": "00FF7B",
		"source": "https://www.alamy.com"
	},
	{
		"title": "Albert Heijn",
		"hex": "04ACE6",
		"source": "https://www.ah.nl"
	},
	{
		"title": "Alby",
		"hex": "FFDF6F",
		"source": "https://github.com/getAlby/media/blob/c24fee4a3f76d6cd000343a972f10590d3913b25/Alby-logo-icons/Alby-logo-head/alby.svg",
		"guidelines": "https://github.com/getAlby/lightning-browser-extension/wiki/Open-Design/9e8ebe4d3e7707742d227554c4ee27b29983a1b6"
	},
	{
		"title": "Alchemy",
		"hex": "0C0C0E",
		"source": "https://www.alchemy.com"
	},
	{
		"title": "Aldi Nord",
		"hex": "2490D7",
		"source": "https://commons.wikimedia.org/wiki/File:Aldi_Nord_201x_logo.svg"
	},
	{
		"title": "Aldi Süd",
		"hex": "00005F",
		"source": "https://www.aldi-sued.de"
	},
	{
		"title": "Alfa Romeo",
		"hex": "981E32",
		"source": "https://www.fcaci.com/x/Alfa"
	},
	{
		"title": "Alfred",
		"hex": "5C1F87",
		"source": "https://www.alfredapp.com"
	},
	{
		"title": "Algolia",
		"hex": "003DFF",
		"source": "https://algolia.frontify.com/d/1AZwVNcFZiu7/style-guide"
	},
	{
		"title": "Algorand",
		"hex": "000000",
		"source": "https://www.algorand.com/about/media-kit",
		"guidelines": "https://algorand.com/about/media-kit"
	},
	{
		"title": "Alibaba Cloud",
		"hex": "FF6A00",
		"source": "https://www.alibabagroup.com/en/ir/reports"
	},
	{
		"title": "Alibaba.com",
		"hex": "FF6A00",
		"source": "https://www.alibabagroup.com/en/ir/reports"
	},
	{
		"title": "Alienware",
		"hex": "541BAE",
		"source": "https://www.dell.com/en-us/gaming/alienware"
	},
	{
		"title": "AliExpress",
		"hex": "FF4747",
		"source": "https://www.alibabagroup.com/en/ir/reports"
	},
	{
		"title": "Alipay",
		"hex": "1677FF",
		"source": "https://global.alipay.com/docs/ac/website_hk/design",
		"guidelines": "https://global.alipay.com/docs/ac/website_hk/design"
	},
	{
		"title": "Allegro",
		"hex": "FF5A00",
		"source": "https://allegro.pl"
	},
	{
		"title": "AlliedModders",
		"hex": "1578D3",
		"source": "https://forums.alliedmods.net"
	},
	{
		"title": "AlloCiné",
		"hex": "FECC00",
		"source": "https://www.allocine.fr"
	},
	{
		"title": "AllTrails",
		"hex": "142800",
		"source": "https://www.alltrails.com/press?section=press-page-kit"
	},
	{
		"title": "AlmaLinux",
		"hex": "000000",
		"source": "https://almalinux.org"
	},
	{
		"title": "Alpine Linux",
		"hex": "0D597F",
		"source": "https://alpinelinux.org"
	},
	{
		"title": "Alpine.js",
		"hex": "8BC0D0",
		"source": "https://alpinejs.dev"
	},
	{
		"title": "AlternativeTo",
		"hex": "0289D5",
		"source": "https://alternativeto.net"
	},
	{
		"title": "Alteryx",
		"hex": "0078C0",
		"source": "https://www.alteryx.com"
	},
	{
		"title": "Altium Designer",
		"hex": "A5915F",
		"source": "https://www.altium.com/altium-designer"
	},
	{
		"title": "Alwaysdata",
		"hex": "E9568E",
		"source": "https://www.alwaysdata.com"
	},
	{
		"title": "ALX",
		"hex": "002B56",
		"source": "https://www.alxafrica.com"
	},
	{
		"title": "Amazon",
		"hex": "FF9900",
		"source": "https://www.amazon.com"
	},
	{
		"title": "Amazon Alexa",
		"hex": "00CAFF",
		"source": "https://developer.amazon.com/docs/alexa-voice-service/logo-and-brand.html"
	},
	{
		"title": "Amazon API Gateway",
		"hex": "FF4F8B",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS API Gateway"
			]
		}
	},
	{
		"title": "Amazon CloudWatch",
		"hex": "FF4F8B",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS CloudWatch"
			]
		}
	},
	{
		"title": "Amazon Cognito",
		"hex": "DD344C",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS Cognito"
			]
		}
	},
	{
		"title": "Amazon DocumentDB",
		"hex": "C925D1",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS DocumentDB"
			]
		}
	},
	{
		"title": "Amazon DynamoDB",
		"hex": "4053D6",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS DynamoDB"
			]
		}
	},
	{
		"title": "Amazon EC2",
		"hex": "FF9900",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"Amazon Elastic Compute Cloud",
				"AWS EC2",
				"AWS Elastic Compute Cloud"
			]
		}
	},
	{
		"title": "Amazon ECS",
		"hex": "FF9900",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"Amazon Elastic Container Service",
				"AWS ECS",
				"AWS Elastic Container Service"
			]
		}
	},
	{
		"title": "Amazon EKS",
		"hex": "FF9900",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"Amazon Elastic Kubernetes Service",
				"AWS EKS",
				"AWS Elastic Kubernetes Service"
			]
		}
	},
	{
		"title": "Amazon ElastiCache",
		"hex": "C925D1",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS ElastiCache"
			]
		}
	},
	{
		"title": "Amazon Fire TV",
		"hex": "FC4C02",
		"source": "https://www.amazon.com/gp/help/customer/display.html?nodeId=201348270"
	},
	{
		"title": "Amazon Games",
		"hex": "FF9900",
		"source": "https://www.amazongames.com"
	},
	{
		"title": "Amazon Identity Access Management",
		"slug": "amazoniam",
		"hex": "DD344C",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons"
	},
	{
		"title": "Amazon Lumberyard",
		"hex": "66459B",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons"
	},
	{
		"title": "Amazon Luna",
		"hex": "9146FF",
		"source": "https://luna.amazon.com"
	},
	{
		"title": "Amazon Music",
		"hex": "46C3D0",
		"source": "https://music.amazon.com",
		"guidelines": "https://artists.amazonmusic.com/brand-guidelines"
	},
	{
		"title": "Amazon Pay",
		"hex": "FF9900",
		"source": "https://pay.amazon.com"
	},
	{
		"title": "Amazon Prime",
		"hex": "00A8E1",
		"source": "https://www.amazon.com/b?node=17277626011"
	},
	{
		"title": "Amazon RDS",
		"hex": "527FFF",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS RDS"
			]
		}
	},
	{
		"title": "Amazon Redshift",
		"hex": "8C4FFF",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons"
	},
	{
		"title": "Amazon Route 53",
		"hex": "8C4FFF",
		"source": "https://aws.amazon.com/architecture/icons/",
		"guidelines": "https://aws.amazon.com/architecture/icons/",
		"aliases": {
			"aka": [
				"AWS Route53"
			]
		}
	},
	{
		"title": "Amazon S3",
		"hex": "569A31",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS S3"
			]
		}
	},
	{
		"title": "Amazon Simple Email Service",
		"hex": "DD344C",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"AWS SES"
			]
		}
	},
	{
		"title": "Amazon SQS",
		"hex": "FF4F8B",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"Amazon Simple Queue Service",
				"AWS Simple Queue Service",
				"AWS SQS"
			]
		}
	},
	{
		"title": "Amazon Web Services",
		"hex": "232F3E",
		"source": "https://commons.wikimedia.org/wiki/File:Amazon_Web_Services_Logo.svg",
		"aliases": {
			"aka": [
				"AWS"
			]
		}
	},
	{
		"title": "AMD",
		"hex": "ED1C24",
		"source": "https://www.amd.com"
	},
	{
		"title": "Ameba",
		"hex": "2D8C3C",
		"source": "https://ameblo.jp",
		"aliases": {
			"aka": [
				"Ameba Blog",
				"Ameblo"
			],
			"loc": {
				"ja-JP": "アメブロ"
			}
		}
	},
	{
		"title": "American Airlines",
		"hex": "0078D2",
		"source": "https://news.aa.com"
	},
	{
		"title": "American Express",
		"hex": "2E77BC",
		"source": "https://commons.wikimedia.org/wiki/File:American_Express_logo_(2018).svg"
	},
	{
		"title": "AMG",
		"hex": "000000",
		"source": "https://www.mercedes-amg.com"
	},
	{
		"title": "AMP",
		"hex": "005AF0",
		"source": "https://amp.dev"
	},
	{
		"title": "Amul",
		"hex": "ED1D24",
		"source": "https://amul.com/classic/products/horeca.php"
	},
	{
		"title": "ANA",
		"hex": "13448F",
		"source": "https://www.ana.co.jp/en/eur/the-ana-experience/brand"
	},
	{
		"title": "Anaconda",
		"hex": "44A833",
		"source": "https://www.anaconda.com"
	},
	{
		"title": "Analogue",
		"hex": "1A1A1A",
		"source": "https://www.analogue.co"
	},
	{
		"title": "Andela",
		"hex": "173B3F",
		"source": "https://andela.com"
	},
	{
		"title": "Android",
		"hex": "3DDC84",
		"source": "https://partnermarketinghub.withgoogle.com/brands/android/visual-identity/visual-identity/logo-lock-ups",
		"guidelines": "https://developer.android.com/distribute/marketing-tools/brand-guidelines#brand-android",
		"license": {
			"type": "CC-BY-3.0"
		}
	},
	{
		"title": "Android Auto",
		"hex": "3DDC84",
		"source": "https://thepartnermarketinghub.withgoogle.com/brands/android-auto"
	},
	{
		"title": "Android Studio",
		"hex": "3DDC84",
		"source": "https://developer.android.com/studio"
	},
	{
		"title": "Angular",
		"hex": "0F0F11",
		"source": "https://angular.dev/press-kit",
		"guidelines": "https://angular.dev/press-kit",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "AniList",
		"hex": "02A9FF",
		"source": "https://anilist.co"
	},
	{
		"title": "Animal Planet",
		"hex": "0073FF",
		"source": "https://www.animalplanet.com"
	},
	{
		"title": "AnkerMake",
		"hex": "88F387",
		"source": "https://www.ankermake.com"
	},
	{
		"title": "Anki",
		"hex": "80C2EE",
		"source": "https://commons.wikimedia.org/wiki/File:Anki-icon.svg",
		"guidelines": "https://github.com/ankitects/anki/blob/4ab0db3127af8508317f84174aff9d20faedc41a/LICENSE",
		"license": {
			"type": "AGPL-3.0-only"
		}
	},
	{
		"title": "Ansible",
		"hex": "EE0000",
		"source": "https://www.ansible.com/logos"
	},
	{
		"title": "Answer",
		"hex": "0033FF",
		"source": "https://answer.dev"
	},
	{
		"title": "Ansys",
		"hex": "FFB71B",
		"source": "https://www.ansys.com/about-ansys/brand"
	},
	{
		"title": "Ant Design",
		"hex": "0170FE",
		"source": "https://ant.design"
	},
	{
		"title": "Anta",
		"hex": "D70010",
		"source": "https://www.anta.com"
	},
	{
		"title": "Antena 3",
		"hex": "FF7328",
		"source": "https://www.antena3.com"
	},
	{
		"title": "Anthropic",
		"hex": "191919",
		"source": "https://www.anthropic.com"
	},
	{
		"title": "AntV",
		"hex": "8B5DFF",
		"source": "https://antv.vision"
	},
	{
		"title": "Anycubic",
		"hex": "476695",
		"source": "https://store.anycubic.com/pages/firmware-software"
	},
	{
		"title": "AnyDesk",
		"hex": "EF443B",
		"source": "https://anydesk.com"
	},
	{
		"title": "Anytype",
		"hex": "FF6A7B",
		"source": "https://github.com/anyproto/anytype-ts/blob/544498296ceb4b6ed2970414de493f7f72bd0fcf/src/img/logo/symbol.svg"
	},
	{
		"title": "AOL",
		"hex": "3399FF",
		"source": "https://www.aol.com"
	},
	{
		"title": "Apache",
		"hex": "D22128",
		"source": "https://www.apache.org/foundation/press/kit",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Airflow",
		"hex": "017CEE",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Ant",
		"hex": "A81C7D",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Cassandra",
		"hex": "1287B1",
		"source": "https://www.apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache CloudStack",
		"hex": "2AA5DC",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Cordova",
		"hex": "E8E8E8",
		"source": "https://cordova.apache.org/artwork",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache CouchDB",
		"hex": "E42528",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache DolphinScheduler",
		"hex": "85CDF0",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Druid",
		"hex": "29F1FB",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache ECharts",
		"hex": "AA344D",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Flink",
		"hex": "E6526F",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache FreeMarker",
		"hex": "326CAC",
		"source": "https://www.apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Groovy",
		"hex": "4298B8",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Guacamole",
		"hex": "578B34",
		"source": "https://apache.org/logos",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Hadoop",
		"hex": "66CCFF",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache HBase",
		"hex": "BE160C",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Hive",
		"hex": "FDEE21",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache JMeter",
		"hex": "D22128",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Kafka",
		"hex": "231F20",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Kylin",
		"hex": "F09D13",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Lucene",
		"hex": "019B8F",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Maven",
		"hex": "C71A36",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache NetBeans IDE",
		"hex": "1B6AC6",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache NiFi",
		"hex": "728E9B",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache OpenOffice",
		"hex": "0E85CD",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Parquet",
		"hex": "50ABF1",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Pulsar",
		"hex": "188FFF",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache RocketMQ",
		"hex": "D77310",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Solr",
		"hex": "D9411E",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Spark",
		"hex": "E25A1C",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Storm",
		"hex": "225593",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Superset",
		"hex": "20A6C9",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks/",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Apache Tomcat",
		"hex": "F8DC75",
		"source": "https://apache.org/logos",
		"guidelines": "https://www.apache.org/foundation/marks",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Aparat",
		"hex": "ED145B",
		"source": "https://www.aparat.com/logo"
	},
	{
		"title": "Apifox",
		"hex": "F44A53",
		"source": "https://apifox.com"
	},
	{
		"title": "APM Terminals",
		"hex": "FF6441",
		"source": "https://www.apmterminals.com"
	},
	{
		"title": "Apollo GraphQL",
		"hex": "311C87",
		"source": "https://www.apollographql.com"
	},
	{
		"title": "Apostrophe",
		"hex": "6236FF",
		"source": "https://github.com/apostrophecms/apostrophe/blob/a7fcc6b13831302e27f79a6fcaaf58e3a40517df/logo.svg"
	},
	{
		"title": "App Store",
		"hex": "0D96F6",
		"source": "https://developer.apple.com/app-store"
	},
	{
		"title": "AppGallery",
		"hex": "FF0000",
		"source": "https://appgallery.huawei.com",
		"aliases": {
			"aka": [
				"HUAWEI AppGallery"
			]
		}
	},
	{
		"title": "Appian",
		"hex": "2322F0",
		"source": "https://appian.com",
		"guidelines": "https://assets.appian.com/uploads/assets/Appian_BrandGuidelines_Newsroom.pdf"
	},
	{
		"title": "Appium",
		"hex": "EE376D",
		"source": "https://github.com/openjs-foundation/artwork/blob/270575392800eb17a02612203f6f0d5868c634a7/projects/appium/appium-icon-mono.svg",
		"guidelines": "https://github.com/openjs-foundation/artwork/tree/270575392800eb17a02612203f6f0d5868c634a7/projects/appium"
	},
	{
		"title": "Apple",
		"hex": "000000",
		"source": "https://www.apple.com"
	},
	{
		"title": "Apple Arcade",
		"hex": "000000",
		"source": "https://www.apple.com/apple-arcade"
	},
	{
		"title": "Apple Music",
		"hex": "FA243C",
		"source": "https://www.apple.com/itunes/marketing-on-music/identity-guidelines.html#apple-music-icon"
	},
	{
		"title": "Apple News",
		"hex": "FD415E",
		"source": "https://www.apple.com/apple-news"
	},
	{
		"title": "Apple Pay",
		"hex": "000000",
		"source": "https://developer.apple.com/apple-pay/marketing"
	},
	{
		"title": "Apple Podcasts",
		"hex": "9933CC",
		"source": "https://www.apple.com/itunes/marketing-on-podcasts/identity-guidelines.html#apple-podcasts-icon"
	},
	{
		"title": "Apple TV",
		"hex": "000000",
		"source": "https://en.wikipedia.org/wiki/File:Apple_TV_(logo).svg"
	},
	{
		"title": "AppSignal",
		"hex": "21375A",
		"source": "https://appsignal.com"
	},
	{
		"title": "Appsmith",
		"hex": "2A2F3D",
		"source": "https://www.appsmith.com"
	},
	{
		"title": "AppVeyor",
		"hex": "00B3E0",
		"source": "https://www.appveyor.com"
	},
	{
		"title": "Appwrite",
		"hex": "FD366E",
		"source": "https://appwrite.io/assets",
		"guidelines": "https://appwrite.io/assets"
	},
	{
		"title": "Aqua",
		"hex": "1904DA",
		"source": "https://www.aquasec.com/brand",
		"guidelines": "https://www.aquasec.com/brand"
	},
	{
		"title": "ARAL",
		"hex": "0063CB",
		"source": "https://commons.wikimedia.org/wiki/File:Aral_Logo.svg"
	},
	{
		"title": "ArangoDB",
		"hex": "DDE072",
		"source": "https://www.arangodb.com/resources/logos",
		"guidelines": "https://www.arangodb.com/resources/logos"
	},
	{
		"title": "Arc",
		"hex": "FCBFBD",
		"source": "https://arc.net"
	},
	{
		"title": "ArcGIS",
		"hex": "2C7AC3",
		"source": "https://www.esri.com/en-us/arcgis/products/arcgis-pro/overview"
	},
	{
		"title": "Arch Linux",
		"hex": "1793D1",
		"source": "https://www.archlinux.org/art",
		"guidelines": "https://wiki.archlinux.org/index.php/DeveloperWiki:TrademarkPolicy#Logo_Usage_Guidelines"
	},
	{
		"title": "Archicad",
		"hex": "2D50A5",
		"source": "https://graphisoft.com/contact-us/press-relations#/documents/archicad-logo-98604"
	},
	{
		"title": "Archive of Our Own",
		"hex": "990000",
		"source": "https://archiveofourown.org"
	},
	{
		"title": "Ardour",
		"hex": "C61C3E",
		"source": "https://github.com/Ardour/ardour/blob/c5a0c0f6e0fc1ed0b94f94af38d5b55d49882add/tools/misc_resources/ardour_bw.svg"
	},
	{
		"title": "Arduino",
		"hex": "00878F",
		"source": "https://www.arduino.cc",
		"guidelines": "https://www.arduino.cc/en/trademark"
	},
	{
		"title": "Argo",
		"hex": "EF7B4D",
		"source": "https://github.com/cncf/artwork/blob/c2e619cdf85e8bac090ceca7c0834c5cfedf9426/projects/argo/icon/black/argo-icon-black.svg"
	},
	{
		"title": "Argos",
		"hex": "DA291C",
		"source": "https://www.argos.co.uk"
	},
	{
		"title": "Ariakit",
		"hex": "007ACC",
		"source": "https://github.com/ariakit/ariakit/blob/a739913ab1c3919c4353f0e0e3573ec6eda99549/logo/icon.svg"
	},
	{
		"title": "ARK Ecosystem",
		"hex": "C9292C",
		"source": "https://ark.io"
	},
	{
		"title": "Arlo",
		"hex": "49B48A",
		"source": "https://www.arlo.com"
	},
	{
		"title": "Arm",
		"hex": "0091BD",
		"source": "https://www.arm.com",
		"guidelines": "https://www.arm.com/company/policies/trademarks/guidelines-corporate-logo"
	},
	{
		"title": "Arm Keil",
		"hex": "394049",
		"source": "https://www.keil.arm.com"
	},
	{
		"title": "Ars Technica",
		"hex": "FF4E00",
		"source": "https://arstechnica.com"
	},
	{
		"title": "Artifact Hub",
		"hex": "417598",
		"source": "https://github.com/artifacthub/hub/blob/b7df64e044687e5788d6e7e809539679eb9fe45a/web/public/static/media/logo/artifacthub-brand-white.svg"
	},
	{
		"title": "Artix Linux",
		"hex": "10A0CC",
		"source": "https://gitea.artixlinux.org/artix/artwork/src/commit/256432e3d06b3e9024bfd6912768e80281ea3746/icons/logo-gray.svg"
	},
	{
		"title": "ArtStation",
		"hex": "13AFF0",
		"source": "https://www.artstation.com/about/logo"
	},
	{
		"title": "arXiv",
		"hex": "B31B1B",
		"source": "https://arxiv.org",
		"guidelines": "https://arxiv.org/about/brand"
	},
	{
		"title": "Asahi Linux",
		"hex": "A61200",
		"source": "https://github.com/AsahiLinux/artwork/blob/292637c9658c1491ddc1128fb6134aec01d904dd/logos/svg/AsahiLinux_logomark_mono.svg"
	},
	{
		"title": "Asana",
		"hex": "F06A6A",
		"source": "https://asana.com/brand",
		"guidelines": "https://asana.com/brand"
	},
	{
		"title": "Asciidoctor",
		"hex": "E40046",
		"source": "https://github.com/asciidoctor/brand/blob/b9cf5e276616f4770c4f1227e646e7daee0cbf24/logo/logo-fill-bw.svg"
	},
	{
		"title": "asciinema",
		"hex": "D40000",
		"source": "https://github.com/asciinema/asciinema-logo/blob/1c743621830c0d8c92fd0076b4f15f75b4cf79f4/logo-red.svg"
	},
	{
		"title": "ASDA",
		"hex": "68A51C",
		"source": "https://www.asda.com"
	},
	{
		"title": "Aseprite",
		"hex": "7D929E",
		"source": "https://www.aseprite.org"
	},
	{
		"title": "AssemblyScript",
		"hex": "007AAC",
		"source": "https://www.assemblyscript.org"
	},
	{
		"title": "Asterisk",
		"hex": "F68F1E",
		"source": "https://commons.wikimedia.org/wiki/File:Asterisk_logo.svg"
	},
	{
		"title": "Aston Martin",
		"hex": "00665E",
		"source": "https://www.astonmartin.com"
	},
	{
		"title": "Astra",
		"hex": "5C2EDE",
		"source": "https://wpastra.com/brand-assets"
	},
	{
		"title": "Astral",
		"hex": "261230",
		"source": "https://brandpad.io/astral",
		"guidelines": "https://brandpad.io/astral"
	},
	{
		"title": "Astro",
		"hex": "BC52EE",
		"source": "https://astro.build/press"
	},
	{
		"title": "ASUS",
		"hex": "000000",
		"source": "https://www.asus.com"
	},
	{
		"title": "AT&T",
		"hex": "009FDB",
		"source": "https://www.att.com"
	},
	{
		"title": "Atari",
		"hex": "E4202E",
		"source": "https://atarivcs.com"
	},
	{
		"title": "AtlasOS",
		"hex": "1A91FF",
		"source": "https://docs.atlasos.net/branding",
		"guidelines": "https://docs.atlasos.net/branding"
	},
	{
		"title": "Atlassian",
		"hex": "0052CC",
		"source": "https://atlassian.design/resources/logo-library",
		"guidelines": "https://atlassian.design/foundations/logos"
	},
	{
		"title": "Auchan",
		"hex": "D6180B",
		"source": "https://www.auchan.fr"
	},
	{
		"title": "Audacity",
		"hex": "0000CC",
		"source": "https://github.com/audacity/audacity/blob/c818449c69193f5311b430fbf600d8d6cbe49047/images/audacity.svg"
	},
	{
		"title": "Audi",
		"hex": "BB0A30",
		"source": "https://www.audi.com/ci/en/intro/basics/rings.html",
		"guidelines": "https://www.audi.com/ci/en/intro/basics/rings.html"
	},
	{
		"title": "Audible",
		"hex": "F8991C",
		"source": "https://commons.wikimedia.org/wiki/File:Audible_logo.svg"
	},
	{
		"title": "Audio-Technica",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:Audio-technica.svg"
	},
	{
		"title": "Audiobookshelf",
		"hex": "82612C",
		"source": "https://github.com/advplyr/audiobookshelf/blob/0d9d2fa4be9b642f0948e52ddff71ff370fd524d/images/banner.svg"
	},
	{
		"title": "Audioboom",
		"hex": "007CE2",
		"source": "https://audioboom.com/about/brand-guidelines"
	},
	{
		"title": "Audiomack",
		"hex": "FFA200",
		"source": "https://styleguide.audiomack.com"
	},
	{
		"title": "Aurelia",
		"hex": "ED2B88",
		"source": "https://aurelia.io"
	},
	{
		"title": "Auth0",
		"hex": "EB5424",
		"source": "https://auth0.com"
	},
	{
		"title": "Authelia",
		"hex": "113155",
		"source": "https://github.com/authelia/authelia/blob/8316cd4eb7a6f0778c8f480c61ad76a88416fc3a/docs/static/images/branding/logo.svg"
	},
	{
		"title": "Authentik",
		"hex": "FD4B2D",
		"source": "https://github.com/goauthentik/authentik/blob/2c64f72ebc57dad9789c1fb799dd7cd39003d043/web/icons/icon.svg"
	},
	{
		"title": "Authy",
		"hex": "EC1C24",
		"source": "https://authy.com"
	},
	{
		"title": "AutoCAD",
		"hex": "E51050",
		"source": "https://www.autodesk.com/blogs/autocad"
	},
	{
		"title": "AutoCannon",
		"hex": "3BA4B7",
		"source": "https://github.com/mcollina/autocannon/blob/feeec71a7483153bd382de1c7ce5dfc31fa3c16f/autocannon-logo-icon-1000px.png"
	},
	{
		"title": "Autodesk",
		"hex": "000000",
		"source": "https://brand.autodesk.com/brand-system/logo",
		"guidelines": "https://brand.autodesk.com/brand-system/logo"
	},
	{
		"title": "Autodesk Maya",
		"hex": "37A5CC",
		"source": "https://area.autodesk.com/learn/courses/maya-intro"
	},
	{
		"title": "Autodesk Revit",
		"hex": "186BFF",
		"source": "https://www.autodesk.com/products/revit"
	},
	{
		"title": "AutoHotkey",
		"hex": "334455",
		"source": "https://www.autohotkey.com"
	},
	{
		"title": "AutoIt",
		"hex": "5D83AC",
		"source": "https://www.autoitscript.com"
	},
	{
		"title": "Automattic",
		"hex": "3499CD",
		"source": "https://automattic.com/press/brand-materials"
	},
	{
		"title": "Autoprefixer",
		"hex": "DD3735",
		"source": "https://github.com/postcss/autoprefixer/blob/1341747bc8142a147342f55eea5ed4286a3ca318/logo.svg"
	},
	{
		"title": "AutoZone",
		"hex": "D52B1E",
		"source": "https://www.autozone.com"
	},
	{
		"title": "avajs",
		"hex": "4B4B77",
		"source": "https://github.com/avajs/ava/blob/6f8e30c94626238a5b26deadac319089fa43d333/media/logo.svg"
	},
	{
		"title": "Avast",
		"hex": "FF7800",
		"source": "https://press.avast.com/media-materials#logos-and-brand-guidelines",
		"guidelines": "https://press.avast.com/media-materials#logos-and-brand-guidelines"
	},
	{
		"title": "avianca",
		"hex": "FF0000",
		"source": "https://www.avianca.com"
	},
	{
		"title": "Avira",
		"hex": "E02027",
		"source": "https://www.avira.com/en/media-library",
		"guidelines": "https://www.avira.com/en/media-library"
	},
	{
		"title": "Awesome Lists",
		"hex": "FC60A8",
		"source": "https://github.com/sindresorhus/awesome/tree/52b6dbacde01c2595f2133a5378cb8d2f89906fa/media/logo.svg"
	},
	{
		"title": "awesomeWM",
		"hex": "535D6C",
		"source": "https://awesomewm.org"
	},
	{
		"title": "AWS Amplify",
		"hex": "FF9900",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons"
	},
	{
		"title": "AWS Elastic Load Balancing",
		"hex": "8C4FFF",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"Amazon Elastic Load Balancing",
				"Amazon ELB",
				"AWS ELB"
			]
		}
	},
	{
		"title": "AWS Fargate",
		"hex": "FF9900",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons"
	},
	{
		"title": "AWS Lambda",
		"hex": "FF9900",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons"
	},
	{
		"title": "AWS Organizations",
		"hex": "E7157B",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons"
	},
	{
		"title": "AWS Secrets Manager",
		"hex": "DD344C",
		"source": "https://aws.amazon.com/architecture/icons",
		"guidelines": "https://aws.amazon.com/architecture/icons",
		"aliases": {
			"aka": [
				"Amazon Secrets Manager"
			]
		}
	},
	{
		"title": "Awwwards",
		"hex": "222222",
		"source": "https://www.awwwards.com"
	},
	{
		"title": "Axios",
		"hex": "5A29E4",
		"source": "https://github.com/axios/axios-docs/blob/ba35d67160f94419c1b0292831cd1a4b378adb42/assets/logo.svg"
	},
	{
		"title": "B&R Automation",
		"hex": "FF8800",
		"source": "https://www.br-automation.com"
	},
	{
		"title": "Babel",
		"hex": "F9DC3E",
		"source": "https://github.com/babel/website/blob/93330158b6ecca1ab88d3be8dbf661f5c2da6c76/website/static/img/babel-black.svg"
	},
	{
		"title": "Babelio",
		"hex": "FBB91E",
		"source": "https://www.babelio.com"
	},
	{
		"title": "Babylon.js",
		"hex": "BB464B",
		"source": "https://github.com/BabylonJS/Brand-Toolkit/blob/8583d4d9bf252a233fa480fa02ac6f367d5207a1/babylon_logo/monochrome/babylon_logo_monochrome_dark.svg"
	},
	{
		"title": "Backblaze",
		"hex": "E21E29",
		"source": "https://www.backblaze.com/company/news.html",
		"guidelines": "https://www.backblaze.com/company/news.html"
	},
	{
		"title": "Backbone",
		"hex": "000000",
		"source": "https://backbone.com/press",
		"guidelines": "https://backbone.com/press"
	},
	{
		"title": "Backbone.js",
		"hex": "0071B5",
		"source": "https://commons.wikimedia.org/wiki/File:Backbone.js_logo.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Backendless",
		"hex": "1D77BD",
		"source": "https://backendless.com"
	},
	{
		"title": "Backstage",
		"hex": "9BF0E1",
		"source": "https://github.com/backstage/backstage/blob/862f2517188849dd7467d059edeb8692e6933c35/microsite/static/logo_assets/svg/Icon_Teal.svg",
		"guidelines": "https://backstage.io/logo_assets/Backstage_Identity_Assets_Overview.pdf"
	},
	{
		"title": "Badoo",
		"hex": "783BF9",
		"source": "https://badoo.com"
	},
	{
		"title": "Baidu",
		"hex": "2932E1",
		"source": "https://www.baidu.com"
	},
	{
		"title": "Bakaláři",
		"hex": "00A2E2",
		"source": "https://konference.bakalari.cz"
	},
	{
		"title": "Bamboo",
		"hex": "0052CC",
		"source": "https://www.atlassian.design/guidelines/marketing/resources/logo-files"
	},
	{
		"title": "Bambu Lab",
		"hex": "00AE42",
		"source": "https://bambulab.com"
	},
	{
		"title": "Bandcamp",
		"hex": "408294",
		"source": "https://bandcamp.com/buttons"
	},
	{
		"title": "BandLab",
		"hex": "F12C18",
		"source": "https://www.bandlab.com"
	},
	{
		"title": "Bandsintown",
		"hex": "00CEC8",
		"source": "https://www.company.bandsintown.com/brand-assets"
	},
	{
		"title": "Bank of America",
		"hex": "012169",
		"source": "https://www.bankofamerica.com"
	},
	{
		"title": "Barclays",
		"hex": "00AEEF",
		"source": "https://home.barclays"
	},
	{
		"title": "Baremetrics",
		"hex": "6078FF",
		"source": "https://baremetrics.com"
	},
	{
		"title": "Barmenia",
		"hex": "009FE3",
		"source": "https://barmenia.de"
	},
	{
		"title": "Basecamp",
		"hex": "1D2D35",
		"source": "https://basecamp.com/about/press"
	},
	{
		"title": "Baserow",
		"hex": "5190EF",
		"source": "https://baserow.io"
	},
	{
		"title": "Basic Attention Token",
		"hex": "80247B",
		"source": "https://brave.com/media-assets",
		"aliases": {
			"aka": [
				"BAT"
			]
		}
	},
	{
		"title": "Bastyon",
		"hex": "00A4FF",
		"source": "https://github.com/pocketnetteam/pocketnet.gui/blob/978201dca0d63bc87c4c66513a67f085f2f51d83/img/logo.svg",
		"aliases": {
			"aka": [
				"pocketnet"
			]
		}
	},
	{
		"title": "bat",
		"hex": "31369E",
		"source": "https://github.com/sharkdp/bat/blob/018a4826211b8b486883b720a5daa65eca2d4604/doc/logo-header.svg"
	},
	{
		"title": "Bata",
		"hex": "DD282E",
		"source": "https://www.bata.com"
	},
	{
		"title": "Battle.net",
		"hex": "4381C3",
		"source": "https://battle.net"
	},
	{
		"title": "Bazel",
		"hex": "43A047",
		"source": "https://bazel.build"
	},
	{
		"title": "Beatport",
		"hex": "01FF95",
		"source": "https://www.beatport.com",
		"guidelines": "https://support.beatport.com/hc/en-us/articles/4412316336404-Beatport-Logos-and-Images"
	},
	{
		"title": "Beats",
		"hex": "005571",
		"source": "https://www.elastic.co/beats",
		"guidelines": "https://www.elastic.co/legal/trademarks"
	},
	{
		"title": "Beats by Dre",
		"hex": "E01F3D",
		"source": "https://www.beatsbydre.com"
	},
	{
		"title": "BeatStars",
		"hex": "EB0000",
		"source": "https://beatstars.world/brand-guidelines",
		"guidelines": "https://beatstars.world/brand-guidelines"
	},
	{
		"title": "Beekeeper Studio",
		"hex": "FAD83B",
		"source": "https://www.beekeeperstudio.io/press",
		"guidelines": "https://www.beekeeperstudio.io/legal/trademark"
	},
	{
		"title": "Behance",
		"hex": "1769FF",
		"source": "https://www.behance.net"
	},
	{
		"title": "Beijing Subway",
		"hex": "004A9D",
		"source": "https://zh.wikipedia.org/wiki/File:Beijing_Subway_Logo.svg"
	},
	{
		"title": "BEM",
		"hex": "000000",
		"source": "https://en.bem.info"
	},
	{
		"title": "Bentley",
		"hex": "333333",
		"source": "https://en.wikipedia.org/wiki/File:Bentley_logo_2.svg"
	},
	{
		"title": "Bento",
		"hex": "768CFF",
		"source": "https://bento.me"
	},
	{
		"title": "BentoBox",
		"hex": "F15541",
		"source": "https://www.getbento.com"
	},
	{
		"title": "BentoML",
		"hex": "000000",
		"source": "https://github.com/bentoml/BentoML/blob/2169ebe9bc74e3d89ceba5dda8f8e1b85f08efa5/docs/source/_static/img/logo-light.svg"
	},
	{
		"title": "BeReal",
		"hex": "000000",
		"source": "https://bereal.com"
	},
	{
		"title": "Betfair",
		"hex": "FFB80B",
		"source": "https://www.betfair.com"
	},
	{
		"title": "Better Stack",
		"hex": "000000",
		"source": "https://betterstack.com"
	},
	{
		"title": "BetterDiscord",
		"hex": "3E82E5",
		"source": "https://github.com/BetterDiscord/docs/blob/a6ba3a369c7149bdce099eca1df6330cc09ac472/static/branding/logo_small.svg"
	},
	{
		"title": "Bevy",
		"hex": "232326",
		"source": "https://github.com/bevyengine/bevy/blob/371c90f6faecf318ff66e3c6efa6f9f48781f63f/assets/branding/bevy_bird_simpleicons.svg"
	},
	{
		"title": "Big Cartel",
		"hex": "222222",
		"source": "https://www.bigcartel.com"
	},
	{
		"title": "bigbasket",
		"hex": "A5CD39",
		"source": "https://www.bigbasket.com"
	},
	{
		"title": "BigBlueButton",
		"hex": "283274",
		"source": "https://github.com/bigbluebutton/bbb-app-rooms/blob/0fcf9636a3ba683296326f46354265917c4f0ea4/app/assets/images/icon.svg",
		"guidelines": "https://bigbluebutton.org/trademark"
	},
	{
		"title": "BigCommerce",
		"hex": "121118",
		"source": "https://www.bigcommerce.co.uk/press",
		"guidelines": "https://www.elastic.co/legal/trademarks"
	},
	{
		"title": "Bilibili",
		"hex": "00A1D6",
		"source": "https://www.bilibili.com"
	},
	{
		"title": "Billboard",
		"hex": "000000",
		"source": "https://www.billboard.com"
	},
	{
		"title": "BIM",
		"hex": "EB1928",
		"source": "https://commons.wikimedia.org/wiki/File:Bim_(company)_logo.svg"
	},
	{
		"title": "Binance",
		"hex": "F0B90B",
		"source": "https://binance.com"
	},
	{
		"title": "Bio Link",
		"hex": "000000",
		"source": "https://bio.link"
	},
	{
		"title": "Biome",
		"hex": "60A5FA",
		"source": "https://github.com/biomejs/resources/blob/551f36498dfe34b24bc7755fcdd0fa501b757cf4/svg/icon-light-mono.svg",
		"aliases": {
			"old": [
				"Rome"
			]
		}
	},
	{
		"title": "BisectHosting",
		"hex": "0D1129",
		"source": "https://www.bisecthosting.com"
	},
	{
		"title": "Bit",
		"hex": "592EC1",
		"source": "https://bit.dev"
	},
	{
		"title": "Bitbucket",
		"hex": "0052CC",
		"source": "https://atlassian.design/resources/logo-library",
		"guidelines": "https://atlassian.design/foundations/logos"
	},
	{
		"title": "Bitcoin",
		"hex": "F7931A",
		"source": "https://bitcoin.org"
	},
	{
		"title": "Bitcoin Cash",
		"hex": "0AC18E",
		"source": "https://www.bitcoincash.org/graphics"
	},
	{
		"title": "Bitcoin SV",
		"hex": "EAB300",
		"source": "https://bitcoinsv.com"
	},
	{
		"title": "BitComet",
		"hex": "F49923",
		"source": "https://en.wikipedia.org/wiki/File:BitComet_logo.svg"
	},
	{
		"title": "Bitdefender",
		"hex": "ED1C24",
		"source": "https://brand.bitdefender.com"
	},
	{
		"title": "Bitly",
		"hex": "EE6123",
		"source": "https://bitly.com/pages/press"
	},
	{
		"title": "Bitrise",
		"hex": "683D87",
		"source": "https://www.bitrise.io/presskit"
	},
	{
		"title": "BitTorrent",
		"hex": "050505",
		"source": "https://www.bittorrent.com/products",
		"guidelines": "https://www.bittorrent.com/pressroom"
	},
	{
		"title": "Bitwarden",
		"hex": "175DDC",
		"source": "https://bitwarden.com/brand",
		"guidelines": "https://bitwarden.com/brand"
	},
	{
		"title": "Bitwig",
		"hex": "FF5A00",
		"source": "https://www.bitwig.com"
	},
	{
		"title": "Blackberry",
		"hex": "000000",
		"source": "https://www.blackberry.com"
	},
	{
		"title": "Blackmagic Design",
		"hex": "FFA200",
		"source": "https://www.blackmagicdesign.com"
	},
	{
		"title": "Blazemeter",
		"hex": "CA2133",
		"source": "https://www.blazemeter.com"
	},
	{
		"title": "Blazor",
		"hex": "512BD4",
		"source": "https://commons.wikimedia.org/wiki/File:Blazor.png"
	},
	{
		"title": "Blender",
		"hex": "E87D0D",
		"source": "https://www.blender.org/about/logo",
		"guidelines": "https://www.blender.org/about/logo"
	},
	{
		"title": "Blockbench",
		"hex": "1E93D9",
		"source": "https://www.blockbench.net/wiki/blockbench/logos",
		"guidelines": "https://www.blockbench.net/wiki/blockbench/logos"
	},
	{
		"title": "Blockchain.com",
		"hex": "121D33",
		"source": "https://www.blockchain.com/en/press",
		"guidelines": "https://www.blockchain.com/en/press"
	},
	{
		"title": "Blogger",
		"hex": "FF5722",
		"source": "https://www.blogger.com"
	},
	{
		"title": "Bloglovin",
		"hex": "000000",
		"source": "https://www.bloglovin.com/widgets"
	},
	{
		"title": "Blueprint",
		"hex": "137CBD",
		"source": "https://blueprintjs.com/docs"
	},
	{
		"title": "Bluesky",
		"hex": "0285FF",
		"source": "https://github.com/FortAwesome/Font-Awesome/issues/19810#issuecomment-1854999604",
		"aliases": {
			"aka": [
				"bsky"
			]
		}
	},
	{
		"title": "Bluesound",
		"hex": "0F131E",
		"source": "https://www.bluesound.com/products/node-x"
	},
	{
		"title": "Bluetooth",
		"hex": "0082FC",
		"source": "https://www.bluetooth.com/develop-with-bluetooth/marketing-branding",
		"guidelines": "https://www.bluetooth.com/develop-with-bluetooth/marketing-branding"
	},
	{
		"title": "BMC Software",
		"hex": "FE5000",
		"source": "https://www.bmc.com"
	},
	{
		"title": "BMW",
		"hex": "0066B1",
		"source": "https://bmw.com"
	},
	{
		"title": "BNB Chain",
		"hex": "F0B90B",
		"source": "https://www.bnbchain.org"
	},
	{
		"title": "BoardGameGeek",
		"hex": "FF5100",
		"source": "https://boardgamegeek.com"
	},
	{
		"title": "boAt",
		"hex": "E20722",
		"source": "https://www.boat-lifestyle.com"
	},
	{
		"title": "Boehringer Ingelheim",
		"hex": "00E47C",
		"source": "https://www.boehringer-ingelheim.com",
		"guidelines": "https://brand.boehringer-ingelheim.com"
	},
	{
		"title": "Boeing",
		"hex": "1D439C",
		"source": "https://commons.wikimedia.org/wiki/File:Boeing_full_logo.svg"
	},
	{
		"title": "Bombardier",
		"hex": "000000",
		"source": "https://bombardier.com",
		"guidelines": "https://bombardier.com/en/trademarks"
	},
	{
		"title": "Bookalope",
		"hex": "DC2829",
		"source": "https://bookalope.net"
	},
	{
		"title": "BookBub",
		"hex": "F44336",
		"source": "https://insights.bookbub.com/bookbub-follow-bookmark-buttons-for-authors-websites"
	},
	{
		"title": "Bookmeter",
		"hex": "64BC4B",
		"source": "https://bookmeter.com"
	},
	{
		"title": "BookMyShow",
		"hex": "C4242B",
		"source": "https://in.bookmyshow.com"
	},
	{
		"title": "BookStack",
		"hex": "0288D1",
		"source": "https://www.bookstackapp.com"
	},
	{
		"title": "Boost",
		"hex": "F7901E",
		"source": "https://www.boostmobile.com"
	},
	{
		"title": "Boosty",
		"hex": "F15F2C",
		"source": "https://boosty.to/app/brand",
		"guidelines": "https://boosty.to/app/brand"
	},
	{
		"title": "Boots",
		"hex": "05054B",
		"source": "https://www.boots-uk.com"
	},
	{
		"title": "Bootstrap",
		"hex": "7952B3",
		"source": "https://getbootstrap.com/docs/5.3/about/brand",
		"guidelines": "https://getbootstrap.com/docs/5.3/about/brand",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "BorgBackup",
		"hex": "00DD00",
		"source": "https://www.borgbackup.org"
	},
	{
		"title": "Bosch",
		"hex": "EA0016",
		"source": "https://www.bosch.de"
	},
	{
		"title": "Bose",
		"hex": "000000",
		"source": "https://www.bose.com",
		"guidelines": "https://www.bose.com/legal/terms-of-use"
	},
	{
		"title": "Botble CMS",
		"hex": "205081",
		"source": "https://botble.com"
	},
	{
		"title": "boulanger",
		"hex": "FD5300",
		"source": "https://www.boulanger.com"
	},
	{
		"title": "Bower",
		"hex": "EF5734",
		"source": "https://bower.io/docs/about/#brand"
	},
	{
		"title": "Box",
		"hex": "0061D5",
		"source": "https://www.box.com/en-gb/about-us/press",
		"guidelines": "https://www.box.com/en-gb/about-us/press"
	},
	{
		"title": "Boxy SVG",
		"hex": "3584E3",
		"source": "https://boxy-svg.com/ideas/7/app-icon-redesign#comment-1953"
	},
	{
		"title": "Braintree",
		"hex": "000000",
		"source": "https://www.braintreepayments.com/press"
	},
	{
		"title": "Brandfolder",
		"hex": "40D1F5",
		"source": "https://brandfolder.com/brandfolder"
	},
	{
		"title": "Brave",
		"hex": "FB542B",
		"source": "https://brave.com/brave-branding-assets"
	},
	{
		"title": "Breaker",
		"hex": "003DAD",
		"source": "https://www.breaker.audio/i/brand"
	},
	{
		"title": "Brenntag",
		"hex": "1A0033",
		"source": "https://www.brenntag.com"
	},
	{
		"title": "Brevo",
		"hex": "0B996E",
		"source": "https://www.brevo.com"
	},
	{
		"title": "Brex",
		"hex": "212121",
		"source": "https://www.brex.com/journal/press"
	},
	{
		"title": "Bricks",
		"hex": "FFD54D",
		"source": "https://bricksbuilder.io"
	},
	{
		"title": "British Airways",
		"hex": "2E5C99",
		"source": "https://www.britishairways.com"
	},
	{
		"title": "Broadcom",
		"hex": "E31837",
		"source": "https://www.broadcom.com/support",
		"license": {
			"type": "custom",
			"url": "https://logorequest.broadcom.com/Home.aspx"
		}
	},
	{
		"title": "Bruno",
		"hex": "F4AA41",
		"source": "https://www.usebruno.com"
	},
	{
		"title": "BSD",
		"hex": "AB2B28",
		"source": "https://freebsdfoundation.org/about-us/about-the-foundation/project",
		"guidelines": "https://freebsdfoundation.org/about-us/about-the-foundation/project"
	},
	{
		"title": "bspwm",
		"hex": "2E2E2E",
		"source": "https://github.com/baskerville/bspwm/blob/8fc2269fe0f29a785885bcd9122812eae7226d7b/artworks/bspwm_logo.svg"
	},
	{
		"title": "BT",
		"hex": "6400AA",
		"source": "https://www.bt.com"
	},
	{
		"title": "Buddy",
		"hex": "1A86FD",
		"source": "https://buddy.works/about"
	},
	{
		"title": "Budibase",
		"hex": "000000",
		"source": "https://github.com/Budibase/budibase/blob/6137ffd9a278ecb3e4dbb42af804c9652741699e/packages/builder/assets/bb-emblem.svg"
	},
	{
		"title": "Buefy",
		"hex": "7957D5",
		"source": "https://github.com/buefy/buefy/blob/a9a724efca0b531e6a64ab734889b00bf4507a9d/static/img/icons/safari-pinned-tab.svg"
	},
	{
		"title": "Buffer",
		"hex": "231F20",
		"source": "https://buffer.com"
	},
	{
		"title": "Bugatti",
		"hex": "000000",
		"source": "https://newsroom.bugatti.com"
	},
	{
		"title": "Bugcrowd",
		"hex": "F26822",
		"source": "https://www.bugcrowd.com/about/press-kit",
		"guidelines": "https://www.bugcrowd.com/about/press-kit"
	},
	{
		"title": "Bugsnag",
		"hex": "4949E4",
		"source": "https://www.bugsnag.com"
	},
	{
		"title": "Buhl",
		"hex": "023E84",
		"source": "https://buhl.de"
	},
	{
		"title": "Buildkite",
		"hex": "14CC80",
		"source": "https://buildkite.com/brand-assets",
		"guidelines": "https://buildkite.com/brand-assets"
	},
	{
		"title": "BuiltByBit",
		"hex": "2D87C3",
		"source": "https://builtbybit.com/wiki/branding",
		"guidelines": "https://builtbybit.com/wiki/branding"
	},
	{
		"title": "Bukalapak",
		"hex": "E31E52",
		"source": "https://www.bukalapak.com",
		"guidelines": "https://brand.bukalapak.design/brand-elements#logo-overview"
	},
	{
		"title": "Bulma",
		"hex": "00D1B2",
		"source": "https://bulma.io/brand"
	},
	{
		"title": "Bun",
		"hex": "000000",
		"source": "https://bun.sh/press-kit"
	},
	{
		"title": "Bungie",
		"hex": "0075BB",
		"source": "https://www.bungie.net/7/en/Destiny"
	},
	{
		"title": "bunq",
		"hex": "3394D7",
		"source": "https://press.bunq.com/media_kits"
	},
	{
		"title": "Burger King",
		"hex": "D62300",
		"source": "https://www.bk.com",
		"guidelines": "https://www.bk.com/trademarks"
	},
	{
		"title": "Burp Suite",
		"hex": "FF6633",
		"source": "https://portswigger.net"
	},
	{
		"title": "Burton",
		"hex": "000000",
		"source": "https://brand.burton.com/logo",
		"guidelines": "https://brand.burton.com/logo"
	},
	{
		"title": "Buy Me A Coffee",
		"hex": "FFDD00",
		"source": "https://www.buymeacoffee.com/brand"
	},
	{
		"title": "BuySellAds",
		"hex": "EB4714",
		"source": "https://docs.buysellads.com"
	},
	{
		"title": "BuzzFeed",
		"hex": "EE3322",
		"source": "https://www.buzzfeed.com/press/assets"
	},
	{
		"title": "BVG",
		"hex": "F0D722",
		"source": "https://www.bvg.de",
		"aliases": {
			"aka": [
				"Berliner Verkehrsbetriebe"
			]
		}
	},
	{
		"title": "Byju's",
		"hex": "813588",
		"source": "https://byjus.com/byjus-the-learning-app"
	},
	{
		"title": "ByteDance",
		"hex": "3C8CFF",
		"source": "https://www.bytedance.com"
	},
	{
		"title": "C",
		"hex": "A8B9CC",
		"source": "https://commons.wikimedia.org/wiki/File:The_C_Programming_Language_logo.svg"
	},
	{
		"title": "C++",
		"hex": "00599C",
		"source": "https://github.com/isocpp/logos/tree/64ef037049f87ac74875dbe72695e59118b52186"
	},
	{
		"title": "C++ Builder",
		"hex": "E62431",
		"source": "https://www.embarcadero.com/news/logo",
		"guidelines": "https://www.ideracorp.com/legal/embarcadero"
	},
	{
		"title": "Cachet",
		"hex": "7ED321",
		"source": "https://cachethq.io/press"
	},
	{
		"title": "Caddy",
		"hex": "1F88C0",
		"source": "https://caddyserver.com"
	},
	{
		"title": "Cadillac",
		"hex": "000000",
		"source": "https://www.cadillac.com",
		"guidelines": "https://www.gm.com/copyright-trademark"
	},
	{
		"title": "CafePress",
		"hex": "58A616",
		"source": "https://en.wikipedia.org/wiki/CafePress#/media/File:CafePress_logo.svg"
	},
	{
		"title": "Cairo Graphics",
		"hex": "F39914",
		"source": "https://github.com/freedesktop/cairo/blob/44f808fce9f437e14f2b0ef4e1583def8ab578ae/doc/tutorial/slides/cairo-title.svg"
	},
	{
		"title": "Cairo Metro",
		"hex": "C10C0C",
		"source": "https://en.wikipedia.org/wiki/File:Cairo_metro_logo2012.svg"
	},
	{
		"title": "CaixaBank",
		"hex": "007EAE",
		"source": "https://www.caixabank.es/deployedfiles/particulares/Estaticos/Imagenes/Geolocalizador_CXB.svg"
	},
	{
		"title": "CakePHP",
		"hex": "D33C43",
		"source": "https://cakephp.org/logos"
	},
	{
		"title": "Cal.com",
		"hex": "292929",
		"source": "https://design.cal.com/assets/logos"
	},
	{
		"title": "Calendly",
		"hex": "006BFF",
		"source": "https://calendly.com/newsroom",
		"guidelines": "https://calendly.com/newsroom"
	},
	{
		"title": "Calibre-Web",
		"hex": "45B29D",
		"source": "https://github.com/janeczku/calibre-web/blob/ab11919c0bff5ddea1eed2bfd80fd7ea26f05710/cps/static/icon.svg"
	},
	{
		"title": "Campaign Monitor",
		"hex": "111324",
		"source": "https://www.campaignmonitor.com/company/brand/"
	},
	{
		"title": "Camunda",
		"hex": "FC5D0D",
		"source": "https://camunda.com/brand",
		"guidelines": "https://camunda.com/brand"
	},
	{
		"title": "Canonical",
		"hex": "E95420",
		"source": "https://design.ubuntu.com/resources",
		"guidelines": "https://design.ubuntu.com/brand/",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "Canva",
		"hex": "00C4CC",
		"source": "https://www.canva.com"
	},
	{
		"title": "Canvas",
		"hex": "E72429",
		"source": "https://www.instructure.com/about/brand-guide/media-resources",
		"guidelines": "https://www.instructure.com/about/brand-guide/media-resources"
	},
	{
		"title": "Capacitor",
		"hex": "119EFF",
		"source": "https://github.com/ionic-team/ionicons-site/blob/b0c97018d737b763301154231b34e1b882c0c84d/docs/ionicons/svg/logo-capacitor.svg"
	},
	{
		"title": "CapRover",
		"hex": "ED5B26",
		"source": "https://github.com/caprover/caprover-website/blob/3ddf18f00923a89639193c578a8f25418b30c0b6/graphics/logo.svg"
	},
	{
		"title": "Car Throttle",
		"hex": "FF9C42",
		"source": "https://www.carthrottle.com"
	},
	{
		"title": "Cardano",
		"hex": "0133AD",
		"source": "https://cardano.org/brand-assets/"
	},
	{
		"title": "Carlsberg Group",
		"hex": "00321E",
		"source": "https://www.carlsberggroup.com/who-we-are/about-the-carlsberg-group/design-guide",
		"guidelines": "https://www.carlsberggroup.com/who-we-are/about-the-carlsberg-group/design-guide"
	},
	{
		"title": "Carrd",
		"hex": "596CAF",
		"source": "https://carrd.co/docs/general/brand-assets"
	},
	{
		"title": "Carrefour",
		"hex": "004E9F",
		"source": "https://en.wikipedia.org/wiki/File:Carrefour_logo_no_tag.svg"
	},
	{
		"title": "Carto",
		"hex": "EB1510",
		"source": "https://carto.com/brand/"
	},
	{
		"title": "Cash App",
		"hex": "00C244",
		"source": "https://cash.app/press"
	},
	{
		"title": "Castbox",
		"hex": "F55B23",
		"source": "https://castbox.fm/newsroom/"
	},
	{
		"title": "Castorama",
		"hex": "0078D7",
		"source": "https://www.castorama.fr"
	},
	{
		"title": "Castro",
		"hex": "00B265",
		"source": "https://supertop.co/castro/press/"
	},
	{
		"title": "Caterpillar",
		"hex": "FFCD11",
		"source": "https://commons.wikimedia.org/wiki/File:Caterpillar_logo.svg"
	},
	{
		"title": "CBC",
		"hex": "E60505",
		"source": "https://www.cbc.ca",
		"aliases": {
			"aka": [
				"Canadian Broadcasting Company"
			],
			"dup": [
				{
					"title": "Radio Canada",
					"hex": "FF0000",
					"source": "https://radio-canada.ca"
				}
			],
			"loc": {
				"fr-CA": "Société Radio-Canada"
			}
		}
	},
	{
		"title": "CBS",
		"hex": "033963",
		"source": "https://www.cbs.com"
	},
	{
		"title": "CCC",
		"hex": "000000",
		"source": "https://www.cqc.com.cn/www/chinese/c/2018-03-20/553293.shtml",
		"guidelines": "https://www.cqc.com.cn/www/chinese/c/2018-11-15/553292.shtml",
		"aliases": {
			"aka": [
				"China Compulsory Certificate"
			]
		}
	},
	{
		"title": "CCleaner",
		"hex": "CB2D29",
		"source": "https://www.ccleaner.com"
	},
	{
		"title": "CD Projekt",
		"hex": "DC0D15",
		"source": "https://www.cdprojekt.com/en/media/logotypes/"
	},
	{
		"title": "CE",
		"hex": "000000",
		"source": "https://single-market-economy.ec.europa.eu/single-market/ce-marking_en",
		"guidelines": "https://single-market-economy.ec.europa.eu/single-market/ce-marking_en"
	},
	{
		"title": "Celery",
		"hex": "37814A",
		"source": "https://github.com/celery/celery/blob/4d77ddddb10797011dc10dd2e4e1e7a7467b8431/docs/images/favicon.ico"
	},
	{
		"title": "Celestron",
		"hex": "F47216",
		"source": "https://www.celestron.com"
	},
	{
		"title": "CentOS",
		"hex": "262577",
		"source": "https://wiki.centos.org/ArtWork/Brand/Logo"
	},
	{
		"title": "Ceph",
		"hex": "EF5C55",
		"source": "https://github.com/ceph/ceph/blob/b106a03dcddaee80493825e85bc5e399ab4d8746/src/pybind/mgr/dashboard/frontend/src/assets/Ceph_Logo.svg"
	},
	{
		"title": "Cesium",
		"hex": "6CADDF",
		"source": "https://cesium.com/press/"
	},
	{
		"title": "Chai",
		"hex": "A30701",
		"source": "https://github.com/simple-icons/simple-icons/issues/4983#issuecomment-796736373"
	},
	{
		"title": "Chainguard",
		"hex": "4445E7",
		"source": "https://www.chainguard.dev"
	},
	{
		"title": "Chainlink",
		"hex": "375BD2",
		"source": "https://chain.link/brand-assets"
	},
	{
		"title": "Chakra UI",
		"hex": "319795",
		"source": "https://github.com/chakra-ui/chakra-ui/blob/327e1624d22936abb43068e1f57054e43c9c6819/logo/logomark-colored.svg"
	},
	{
		"title": "Channel 4",
		"hex": "AAFF89",
		"source": "https://mediaassets.channel4.com/guidelines/guide/34286b7b-ea25-404d-a43b-e912fc85b0e0/page/8a2dd59a-51df-4f47-aa37-c235a761455e",
		"guidelines": "https://mediaassets.channel4.com/guidelines/guide/34286b7b-ea25-404d-a43b-e912fc85b0e0"
	},
	{
		"title": "Charles",
		"hex": "F3F5F5",
		"source": "https://www.charlesproxy.com"
	},
	{
		"title": "Chart.js",
		"hex": "FF6384",
		"source": "https://www.chartjs.org"
	},
	{
		"title": "ChartMogul",
		"hex": "13324B",
		"source": "https://chartmogul.com/company/"
	},
	{
		"title": "Chase",
		"hex": "117ACA",
		"source": "https://commons.wikimedia.org/wiki/File:Chase_logo_2007.svg"
	},
	{
		"title": "ChatBot",
		"hex": "0066FF",
		"source": "https://chatbot.design",
		"guidelines": "https://chatbot.design"
	},
	{
		"title": "Chatwoot",
		"hex": "1F93FF",
		"source": "https://www.chatwoot.com"
	},
	{
		"title": "CheckiO",
		"hex": "008DB6",
		"source": "https://py.checkio.org/blog/"
	},
	{
		"title": "Checkmarx",
		"hex": "54B848",
		"source": "https://www.checkmarx.com/resources/datasheets/"
	},
	{
		"title": "Checkmk",
		"hex": "15D1A0",
		"source": "https://checkmk.com"
	},
	{
		"title": "Chedraui",
		"hex": "E0832F",
		"source": "https://www.chedraui.com.mx"
	},
	{
		"title": "Cheerio",
		"hex": "E88C1F",
		"source": "https://github.com/cheeriojs/cheerio/blob/60b538772c34f2dd93e9c62e410b2751d0a69ff3/website/static/img/orange-c.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Chef",
		"hex": "F09820",
		"source": "https://www.chef.io"
	},
	{
		"title": "Chemex",
		"hex": "4D2B1A",
		"source": "https://vtlogo.com/chemex-coffeemaker-vector-logo-svg/"
	},
	{
		"title": "Chess.com",
		"hex": "81B64C",
		"source": "https://www.chess.com/article/view/chess-com-brand-resources",
		"guidelines": "https://www.chess.com/article/view/chess-com-brand-resources"
	},
	{
		"title": "Chevrolet",
		"hex": "CD9834",
		"source": "https://www.chevrolet.com/content/dam/chevrolet/na/us/english/index/shopping-tools/download-catalog/02-pdf/2019-chevrolet-corvette-catalog.pdf"
	},
	{
		"title": "Chia Network",
		"hex": "5ECE71",
		"source": "https://www.chia.net/branding/",
		"guidelines": "https://www.chia.net/wp-content/uploads/2022/08/Guidelines-for-Using-Chia-Network.pdf",
		"license": {
			"type": "custom",
			"url": "https://www.chia.net/wp-content/uploads/2022/08/Chia-Trademark-Policy.pdf"
		}
	},
	{
		"title": "China Eastern Airlines",
		"hex": "1A2477",
		"source": "https://uk.ceair.com/newCMS/uk/en/content/en_Footer/Support/201904/t20190404_5763.html"
	},
	{
		"title": "China Southern Airlines",
		"hex": "008BCB",
		"source": "https://www.csair.com/en/about/investor/yejibaogao/2020/"
	},
	{
		"title": "Chocolatey",
		"hex": "80B5E3",
		"source": "https://chocolatey.org/media-kit"
	},
	{
		"title": "Chromatic",
		"hex": "FC521F",
		"source": "https://www.chromatic.com"
	},
	{
		"title": "Chrome Web Store",
		"hex": "4285F4",
		"source": "https://chromewebstore.google.com"
	},
	{
		"title": "Chromecast",
		"hex": "999999",
		"source": "https://www.google.com/intl/en_us/chromecast/built-in/",
		"aliases": {
			"aka": [
				"Google Cast"
			]
		}
	},
	{
		"title": "Chrysler",
		"hex": "000000",
		"source": "https://www.stellantis.com/en/brands/chrysler"
	},
	{
		"title": "Chupa Chups",
		"hex": "CF103E",
		"source": "https://www.chupachups.co.uk"
	},
	{
		"title": "Cilium",
		"hex": "F8C517",
		"source": "https://github.com/cilium/cilium/blob/774a91f0e7497d9c9085234005ec81f1065c3783/Documentation/images/logo-solo.svg"
	},
	{
		"title": "Cinema 4D",
		"hex": "011A6A",
		"source": "https://www.maxon.net/en/about-maxon/branding"
	},
	{
		"title": "Cinnamon",
		"hex": "DC682E",
		"source": "https://projects.linuxmint.com/cinnamon"
	},
	{
		"title": "Circle",
		"hex": "8669AE",
		"source": "https://www.circle.com"
	},
	{
		"title": "CircleCI",
		"hex": "343434",
		"source": "https://circleci.com/press"
	},
	{
		"title": "CircuitVerse",
		"hex": "42B883",
		"source": "https://circuitverse.org"
	},
	{
		"title": "Cirrus CI",
		"hex": "4051B5",
		"source": "https://cirrus-ci.org"
	},
	{
		"title": "Cisco",
		"hex": "1BA0D7",
		"source": "https://www.cisco.com"
	},
	{
		"title": "Citrix",
		"hex": "452170",
		"source": "https://brand.citrix.com"
	},
	{
		"title": "Citroën",
		"hex": "DA291C",
		"source": "https://www.stellantis.com/en/brands/citroen"
	},
	{
		"title": "CiviCRM",
		"hex": "81C459",
		"source": "https://civicrm.org/trademark"
	},
	{
		"title": "Civo",
		"hex": "239DFF",
		"source": "https://www.civo.com/brand-assets",
		"guidelines": "https://www.civo.com/brand-assets"
	},
	{
		"title": "Clarifai",
		"hex": "1955FF",
		"source": "https://www.clarifai.com"
	},
	{
		"title": "Claris",
		"hex": "000000",
		"source": "https://www.claris.com"
	},
	{
		"title": "Clarivate",
		"hex": "93FF9E",
		"source": "https://clarivate.com"
	},
	{
		"title": "Claude",
		"hex": "D97757",
		"source": "https://claude.ai"
	},
	{
		"title": "Clerk",
		"hex": "6C47FF",
		"source": "https://clerk.com"
	},
	{
		"title": "Clever Cloud",
		"hex": "171C36",
		"source": "https://www.clever-cloud.com"
	},
	{
		"title": "ClickHouse",
		"hex": "FFCC01",
		"source": "https://github.com/ClickHouse/ClickHouse/blob/12bd453a43819176d25ecf247033f6cb1af54beb/website/images/logo-clickhouse.svg"
	},
	{
		"title": "ClickUp",
		"hex": "7B68EE",
		"source": "https://clickup.com/brand"
	},
	{
		"title": "CLion",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "Clockify",
		"hex": "03A9F4",
		"source": "https://clockify.me/brand-assets"
	},
	{
		"title": "Clojure",
		"hex": "5881D8",
		"source": "https://commons.wikimedia.org/wiki/File:Clojure_logo.svg"
	},
	{
		"title": "Cloud 66",
		"hex": "3C72B9",
		"source": "https://www.cloud66.com"
	},
	{
		"title": "Cloud Foundry",
		"hex": "0C9ED5",
		"source": "https://www.cloudfoundry.org",
		"guidelines": "https://www.cloudfoundry.org/logo/"
	},
	{
		"title": "CloudBees",
		"hex": "1997B5",
		"source": "https://www.cloudbees.com"
	},
	{
		"title": "CloudCannon",
		"hex": "407AFC",
		"source": "https://cloudcannon.com"
	},
	{
		"title": "Cloudera",
		"hex": "F96702",
		"source": "https://www.cloudera.com"
	},
	{
		"title": "Cloudflare",
		"hex": "F38020",
		"source": "https://www.cloudflare.com/logo/",
		"guidelines": "https://www.cloudflare.com/trademark/"
	},
	{
		"title": "Cloudflare Pages",
		"hex": "F38020",
		"source": "https://pages.cloudflare.com",
		"guidelines": "https://www.cloudflare.com/trademark/"
	},
	{
		"title": "Cloudflare Workers",
		"hex": "F38020",
		"source": "https://www.cloudflare.com/developer-platform/products/",
		"guidelines": "https://www.cloudflare.com/trademark/"
	},
	{
		"title": "Cloudinary",
		"hex": "3448C5",
		"source": "https://cloudinary.com"
	},
	{
		"title": "Cloudron",
		"hex": "03A9F4",
		"source": "https://www.cloudron.io/brand-assets.html"
	},
	{
		"title": "Cloudsmith",
		"hex": "2A6FE1",
		"source": "https://cloudsmith.com/company/brand/",
		"guidelines": "https://cloudsmith.com/company/brand/"
	},
	{
		"title": "Cloudways",
		"hex": "2C39BD",
		"source": "https://www.cloudways.com/en/media-kit.php"
	},
	{
		"title": "Clubforce",
		"hex": "191176",
		"source": "https://clubforce.com/media-centre",
		"guidelines": "https://clubforce.com/media-centre"
	},
	{
		"title": "Clubhouse",
		"hex": "FFE450",
		"source": "https://www.clubhouse.com/press"
	},
	{
		"title": "Clyp",
		"hex": "3CBDB1",
		"source": "https://clyp.it"
	},
	{
		"title": "CMake",
		"hex": "064F8C",
		"source": "https://www.kitware.com/platforms/"
	},
	{
		"title": "CNCF",
		"hex": "231F20",
		"source": "https://github.com/cncf/artwork/blob/d2ed716cc0769e6c65d2e58f9a503fca02b60a56/examples/other.md#cncf-logos",
		"guidelines": "https://www.cncf.io/brand-guidelines/"
	},
	{
		"title": "CNES",
		"hex": "204F8C",
		"source": "https://fr.m.wikipedia.org/wiki/Fichier:Logo_CNES_2017_triangulaire_bleu.png"
	},
	{
		"title": "CNET",
		"hex": "E71D1D",
		"source": "https://www.cnet.com"
	},
	{
		"title": "CNN",
		"hex": "CC0000",
		"source": "https://edition.cnn.com"
	},
	{
		"title": "Co-op",
		"hex": "00B1E7",
		"source": "https://www.co-operative.coop/media/assets"
	},
	{
		"title": "Coca-Cola",
		"hex": "D00013",
		"source": "https://commons.wikimedia.org/wiki/File:Coca-Cola_logo.svg"
	},
	{
		"title": "Cockpit",
		"hex": "0066CC",
		"source": "https://github.com/cockpit-project/cockpit-project.github.io/blob/b851b3477d90017961ac9b252401c9a6cb6239f1/images/site/cockpit-logo.svg"
	},
	{
		"title": "Cockroach Labs",
		"hex": "6933FF",
		"source": "https://www.cockroachlabs.com"
	},
	{
		"title": "CocoaPods",
		"hex": "EE3322",
		"source": "https://github.com/CocoaPods/shared_resources/tree/3125baf19976bd240c86459645f45b68d2facd10",
		"license": {
			"type": "CC-BY-NC-4.0"
		}
	},
	{
		"title": "Cocos",
		"hex": "55C2E1",
		"source": "https://www.cocos.com/en/"
	},
	{
		"title": "Coda",
		"hex": "F46A54",
		"source": "https://coda.io"
	},
	{
		"title": "Codacy",
		"hex": "222F29",
		"source": "https://www.codacy.com/blog/"
	},
	{
		"title": "Code Climate",
		"hex": "000000",
		"source": "https://codeclimate.com/github/codeclimate/python-test-reporter/badges/"
	},
	{
		"title": "Code::Blocks",
		"hex": "41AD48",
		"source": "https://wiki.codeblocks.org/index.php/Main_Page"
	},
	{
		"title": "Codeberg",
		"hex": "2185D0",
		"source": "https://codeberg.org"
	},
	{
		"title": "Codecademy",
		"hex": "1F4056",
		"source": "https://www.codecademy.com"
	},
	{
		"title": "CodeceptJS",
		"hex": "F6E05E",
		"source": "https://github.com/codeceptjs/codeceptjs.github.io/blob/c7917445b9a70a9daacf20986c403c3299f5c960/favicon/safari-pinned-tab.svg"
	},
	{
		"title": "CodeChef",
		"hex": "5B4638",
		"source": "https://www.codechef.com"
	},
	{
		"title": "Codecov",
		"hex": "F01F7A",
		"source": "https://codecov.io"
	},
	{
		"title": "CodeCrafters",
		"hex": "171920",
		"source": "https://github.com/codecrafters-io/frontend/blob/2f15115b73843fea57a412ce243ff1cedb5e69f7/public/assets/images/logo/logomark-color.svg"
	},
	{
		"title": "CodeFactor",
		"hex": "F44A6A",
		"source": "https://www.codefactor.io"
	},
	{
		"title": "Codeforces",
		"hex": "1F8ACB",
		"source": "https://codeforces.com"
	},
	{
		"title": "Codefresh",
		"hex": "08B1AB",
		"source": "https://codefresh.io"
	},
	{
		"title": "CodeIgniter",
		"hex": "EF4223",
		"source": "https://www.codeigniter.com/help/legal"
	},
	{
		"title": "Codeium",
		"hex": "09B6A2",
		"source": "https://github.com/Exafunction/codeium.vim/blob/e03c410a7673dbbe7f64afbc9a08f423363ded81/codeium-simple-logo.svg",
		"aliases": {
			"aka": [
				"Exafunction"
			]
		}
	},
	{
		"title": "Codemagic",
		"hex": "F45E3F",
		"source": "https://codemagic.io"
	},
	{
		"title": "Codementor",
		"hex": "003648",
		"source": "https://www.codementor.io"
	},
	{
		"title": "CodeMirror",
		"hex": "D30707",
		"source": "https://github.com/codemirror/CodeMirror/blob/6e7aa65a8bfb64837ae9d082b674b2f5ee056d2c/doc/logo.svg"
	},
	{
		"title": "CodeNewbie",
		"hex": "9013FE",
		"source": "https://community.codenewbie.org"
	},
	{
		"title": "CodePen",
		"hex": "000000",
		"source": "https://blog.codepen.io/documentation/brand-assets/logos/"
	},
	{
		"title": "CodeProject",
		"hex": "FF9900",
		"source": "https://www.codeproject.com"
	},
	{
		"title": "Coder",
		"hex": "000000",
		"source": "https://github.com/coder/presskit/blob/f9dccc00b062cf130ba237bfcefd1fcda4d253c8/logos/coder_logo_transparent_black.svg",
		"guidelines": "https://github.com/coder/presskit"
	},
	{
		"title": "CodersRank",
		"hex": "67A4AC",
		"source": "https://codersrank.io"
	},
	{
		"title": "Coderwall",
		"hex": "3E8DCC",
		"source": "https://github.com/twolfson/coderwall-svg/tree/e87fb90eab5e401210a174f9418b5af0a246758e"
	},
	{
		"title": "CodeSandbox",
		"hex": "151515",
		"source": "https://codesandbox.io/CodeSandbox-Press-Kit.zip"
	},
	{
		"title": "Codeship",
		"hex": "004466",
		"source": "https://app.codeship.com"
	},
	{
		"title": "CodeSignal",
		"hex": "1062FB",
		"source": "https://codesignal.com"
	},
	{
		"title": "CodeStream",
		"hex": "008C99",
		"source": "https://www.codestream.com"
	},
	{
		"title": "Codewars",
		"hex": "B1361E",
		"source": "https://github.com/codewars/branding/tree/1ff0d44db52ac4a5e3a1c43277dc35f228eb6983"
	},
	{
		"title": "Coding Ninjas",
		"hex": "DD6620",
		"source": "https://www.codingninjas.com/press-release"
	},
	{
		"title": "CodinGame",
		"hex": "F2BB13",
		"source": "https://www.codingame.com/work/press/press-kit/"
	},
	{
		"title": "Codio",
		"hex": "4574E0",
		"source": "https://codio.com"
	},
	{
		"title": "CoffeeScript",
		"hex": "2F2625",
		"source": "https://coffeescript.org"
	},
	{
		"title": "Coggle",
		"hex": "9ED56B",
		"source": "https://coggle.it/press"
	},
	{
		"title": "Cognizant",
		"hex": "1A4CA1",
		"source": "https://www.cognizant.com"
	},
	{
		"title": "cohost",
		"hex": "83254F",
		"source": "https://cohost.org"
	},
	{
		"title": "Coinbase",
		"hex": "0052FF",
		"source": "https://www.coinbase.com/press"
	},
	{
		"title": "CoinMarketCap",
		"hex": "17181B",
		"source": "https://www.coinmarketcap.com"
	},
	{
		"title": "Collabora Online",
		"hex": "5C2983",
		"source": "https://www.collaboraonline.com/branding-guidelines",
		"guidelines": "https://www.collaboraonline.com/branding-guidelines",
		"aliases": {
			"aka": [
				"Collabora Office",
				"Collabora Productivity"
			]
		}
	},
	{
		"title": "ComicFury",
		"hex": "79BD42",
		"source": "https://comicfury.com/images/gator-icon-black.png"
	},
	{
		"title": "comma",
		"hex": "51FF00",
		"source": "https://comma.ai"
	},
	{
		"title": "Commerzbank",
		"hex": "FFCC33",
		"source": "https://commons.wikimedia.org/wiki/Category:Commerzbank_logos"
	},
	{
		"title": "commitlint",
		"hex": "000000",
		"source": "https://github.com/conventional-changelog/commitlint/blob/0b177635472214faac5a5800ced970bf4d2e6012/docs/assets/icon.svg"
	},
	{
		"title": "Commodore",
		"hex": "1E2A4E",
		"source": "https://commodore.inc"
	},
	{
		"title": "Common Lisp",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:Lisp_logo.svg"
	},
	{
		"title": "Common Workflow Language",
		"hex": "B5314C",
		"source": "https://github.com/common-workflow-language/logo/blob/54b1624bc88df6730fa7b6c928a05fc9c939e47e/CWL-Logo-nofonts.svg"
	},
	{
		"title": "Compiler Explorer",
		"hex": "67C52A",
		"source": "https://github.com/compiler-explorer/infra/blob/8d362efe7ddc24e6a625f7db671d0a6e7600e3c9/logo/icon/CompilerExplorer%20Logo%20Icon%20SVG.svg"
	},
	{
		"title": "Composer",
		"hex": "885630",
		"source": "https://getcomposer.org"
	},
	{
		"title": "CompTIA",
		"hex": "C8202F",
		"source": "https://www.comptia.org",
		"guidelines": "https://www.comptia.org/newsroom/media-library"
	},
	{
		"title": "Comsol",
		"hex": "368CCB",
		"source": "https://cdn.comsol.com/company/comsol-brand-guide-November2019.pdf"
	},
	{
		"title": "Conan",
		"hex": "6699CB",
		"source": "https://conan.io"
	},
	{
		"title": "Concourse",
		"hex": "3398DC",
		"source": "https://concourse-ci.org"
	},
	{
		"title": "Conda-Forge",
		"hex": "000000",
		"source": "https://github.com/conda-forge/conda-forge.github.io/blob/34adb68298ca266af13c3d615f7af8b6c232f6fb/img/anvil.svg"
	},
	{
		"title": "Conekta",
		"hex": "0A1837",
		"source": "https://www.conekta.com"
	},
	{
		"title": "Confluence",
		"hex": "172B4D",
		"source": "https://www.atlassian.com/company/news/press-kit"
	},
	{
		"title": "Construct 3",
		"hex": "00FFDA",
		"source": "https://www.construct.net",
		"guidelines": "https://www.construct.net"
	},
	{
		"title": "Consul",
		"hex": "F24C53",
		"source": "https://www.hashicorp.com/brand",
		"guidelines": "https://www.hashicorp.com/brand"
	},
	{
		"title": "Contabo",
		"hex": "00AAEB",
		"source": "https://contabo.com"
	},
	{
		"title": "Contactless Payment",
		"hex": "000000",
		"source": "https://en.wikipedia.org/wiki/Contactless_payment"
	},
	{
		"title": "containerd",
		"hex": "575757",
		"source": "https://cncf-branding.netlify.app/projects/containerd/"
	},
	{
		"title": "Contao",
		"hex": "F47C00",
		"source": "https://contao.org",
		"guidelines": "https://contao.org/en/media"
	},
	{
		"title": "Contentful",
		"hex": "2478CC",
		"source": "https://press.contentful.com/media_kits"
	},
	{
		"title": "Contentstack",
		"hex": "E74C3D",
		"source": "https://www.contentstack.com",
		"license": {
			"type": "custom",
			"url": "https://www.contentstack.com/legal/terms-of-service"
		}
	},
	{
		"title": "Continente",
		"hex": "E31E24",
		"source": "https://www.continente.pt"
	},
	{
		"title": "Contributor Covenant",
		"hex": "5E0D73",
		"source": "https://www.contributor-covenant.org"
	},
	{
		"title": "Conventional Commits",
		"hex": "FE5196",
		"source": "https://www.conventionalcommits.org",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Convertio",
		"hex": "FF3333",
		"source": "https://convertio.co"
	},
	{
		"title": "Cookiecutter",
		"hex": "D4AA00",
		"source": "https://github.com/cookiecutter/cookiecutter/blob/52dd18513bbab7f0fbfcb2938c9644d9092247cf/logo/cookiecutter-logo.svg"
	},
	{
		"title": "Cooler Master",
		"hex": "1E1E28",
		"source": "https://www.coolermaster.com/branding",
		"guidelines": "https://www.coolermaster.com/branding"
	},
	{
		"title": "Copa Airlines",
		"hex": "0032A0",
		"source": "https://www.copaair.com"
	},
	{
		"title": "Coppel",
		"hex": "0266AE",
		"source": "https://www.coppel.com"
	},
	{
		"title": "Cora",
		"hex": "E61845",
		"source": "https://www.cora.fr"
	},
	{
		"title": "CorelDRAW",
		"hex": "000000",
		"source": "https://www.coreldraw.com/en/learn/webinars/ebook-embroidery"
	},
	{
		"title": "Corona Engine",
		"hex": "F96F29",
		"source": "https://coronalabs.com",
		"guidelines": "https://coronalabs.com/presskit.pdf"
	},
	{
		"title": "Corona Renderer",
		"hex": "E6502A",
		"source": "https://corona-renderer.com/about"
	},
	{
		"title": "Corsair",
		"hex": "000000",
		"source": "https://www.corsair.com",
		"guidelines": "https://www.corsair.com/press"
	},
	{
		"title": "Couchbase",
		"hex": "EA2328",
		"source": "https://www.couchbase.com"
	},
	{
		"title": "Counter-Strike",
		"hex": "000000",
		"source": "https://www.counter-strike.net"
	},
	{
		"title": "CountingWorks PRO",
		"hex": "2E3084",
		"source": "https://www.countingworks.com/blog"
	},
	{
		"title": "Coursera",
		"hex": "0056D2",
		"source": "https://about.coursera.org/press"
	},
	{
		"title": "Coveralls",
		"hex": "3F5767",
		"source": "https://coveralls.io"
	},
	{
		"title": "Coze",
		"hex": "4D53E8",
		"source": "https://www.coze.com/home"
	},
	{
		"title": "cPanel",
		"hex": "FF6C2C",
		"source": "https://cpanel.net/company/cpanel-brand-guide/"
	},
	{
		"title": "Craft CMS",
		"hex": "E5422B",
		"source": "https://craftcms.com/brand-resources"
	},
	{
		"title": "Craftsman",
		"hex": "D6001C",
		"source": "https://www.craftsman.com"
	},
	{
		"title": "CrateDB",
		"hex": "009DC7",
		"source": "https://github.com/crate/crate-docs-theme/blob/cbd734b3617489ca937f35e30f37f3f6c1870e1f/src/crate/theme/rtd/crate/static/images/crate-logo.svg"
	},
	{
		"title": "Crayon",
		"hex": "FF6A4C",
		"source": "https://www.crayon.com"
	},
	{
		"title": "Creality",
		"hex": "000000",
		"source": "https://www.creality.com"
	},
	{
		"title": "Create React App",
		"hex": "09D3AC",
		"source": "https://github.com/facebook/create-react-app/blob/9d0369b1fe3260e620b08effcf85f1edefc5d1ea/docusaurus/website/static/img/logo.svg"
	},
	{
		"title": "Creative Commons",
		"hex": "ED592F",
		"source": "https://creativecommons.org/mission/downloads",
		"guidelines": "https://creativecommons.org/mission/downloads"
	},
	{
		"title": "Creative Technology",
		"hex": "000000",
		"source": "https://creative.com"
	},
	{
		"title": "Credly",
		"hex": "FF6B00",
		"source": "https://cdn.credly.com/assets/structure/logo-78b59f8114817c758ca965ed8f1a58a76a39b6fd70d031f771a9bbc581fcde65.svg"
	},
	{
		"title": "Crehana",
		"hex": "4B22F4",
		"source": "https://www.crehana.com"
	},
	{
		"title": "Crew United",
		"hex": "000000",
		"source": "https://www.crew-united.com"
	},
	{
		"title": "CrewAI",
		"hex": "FF5A50",
		"source": "https://github.com/crewAIInc/crewAI/blob/a7696d5aed7a85333735dde370fd9f0547aaabf5/docs/favicon.svg"
	},
	{
		"title": "Critical Role",
		"hex": "000000",
		"source": "https://critrole.com"
	},
	{
		"title": "Crowdin",
		"hex": "2E3340",
		"source": "https://support.crowdin.com/using-logo/"
	},
	{
		"title": "Crowdsource",
		"hex": "4285F4",
		"source": "https://crowdsource.google.com/about/"
	},
	{
		"title": "Crunchbase",
		"hex": "0288D1",
		"source": "https://crunchbase.com"
	},
	{
		"title": "Crunchyroll",
		"hex": "F47521",
		"source": "https://www.crunchyroll.com"
	},
	{
		"title": "CRYENGINE",
		"hex": "000000",
		"source": "https://www.cryengine.com/brand"
	},
	{
		"title": "Cryptomator",
		"hex": "49B04A",
		"source": "https://github.com/cryptomator/docs/blob/795a5a414b7e848cbfd4502a4ff63cfdb3adfb15/source/img/logo-mono-white.svg"
	},
	{
		"title": "CryptPad",
		"hex": "0087FF",
		"source": "https://cryptpad.org"
	},
	{
		"title": "Crystal",
		"hex": "000000",
		"source": "https://crystal-lang.org/media/"
	},
	{
		"title": "CSDN",
		"hex": "FC5531",
		"source": "https://www.csdn.net/company/index.html"
	},
	{
		"title": "CSS",
		"hex": "663399",
		"source": "https://github.com/CSS-Next/logo.css/blob/bacc20878227204b283c68a6b935f8279e06b0cd/css.svg",
		"guidelines": "https://github.com/CSS-Next/logo.css"
	},
	{
		"title": "CSS Design Awards",
		"hex": "280FEE",
		"source": "https://www.cssdesignawards.com"
	},
	{
		"title": "CSS Modules",
		"hex": "000000",
		"source": "https://github.com/css-modules/logos/blob/32e4717062e4328ed861fa92d5d9cfd47859362f/css-modules-logo.svg"
	},
	{
		"title": "CSS Wizardry",
		"hex": "F43059",
		"source": "https://csswizardry.com"
	},
	{
		"title": "CSS3",
		"hex": "1572B6",
		"source": "https://www.w3.org/html/logo/"
	},
	{
		"title": "CTS",
		"hex": "E53236",
		"source": "https://commons.wikimedia.org/wiki/File:Logo_Compagnie_des_transports_strasbourgeois.svg",
		"aliases": {
			"aka": [
				"Compagnie des Transports Strasbourgeois"
			]
		}
	},
	{
		"title": "Cucumber",
		"hex": "23D96C",
		"source": "https://cucumber.io"
	},
	{
		"title": "Cultura",
		"hex": "1D2C54",
		"source": "https://www.cultura.com"
	},
	{
		"title": "curl",
		"hex": "073551",
		"source": "https://curl.haxx.se/logo/"
	},
	{
		"title": "CurseForge",
		"hex": "F16436",
		"source": "https://www.curseforge.com"
	},
	{
		"title": "Custom Ink",
		"hex": "FA3C00",
		"source": "https://www.customink.com"
	},
	{
		"title": "CyberDefenders",
		"hex": "335EEA",
		"source": "https://cyberdefenders.org"
	},
	{
		"title": "Cycling '74",
		"hex": "111111",
		"source": "https://cycling74.com"
	},
	{
		"title": "Cypress",
		"hex": "69D3A7",
		"source": "https://www.cypress.io/press-kit"
	},
	{
		"title": "Cytoscape.js",
		"hex": "F7DF1E",
		"source": "https://github.com/cytoscape/cytoscape.js/blob/97c27700feefe2f7b79fca248763049e9a0b38c6/documentation/img/cytoscape-logo.svg"
	},
	{
		"title": "D",
		"hex": "B03931",
		"source": "https://github.com/dlang/dlang.org/blob/6d0e2e5f6a8249031cfd010e389b99ff014cd320/images/dlogo.svg"
	},
	{
		"title": "D-EDGE",
		"hex": "432975",
		"source": "https://github.com/d-edge/JoinUs/blob/4d8b5cf7145db26649fe9f1587194e44dbbe3565/d-edge.svg"
	},
	{
		"title": "D-Wave Systems",
		"hex": "008CD7",
		"source": "https://www.dwavesys.com"
	},
	{
		"title": "D3",
		"hex": "F9A03C",
		"source": "https://github.com/d3/d3-logo/tree/6d9c471aa852033501d00ca63fe73d9f8be82d1d",
		"aliases": {
			"aka": [
				"D3.js"
			]
		}
	},
	{
		"title": "Dacia",
		"hex": "646B52",
		"source": "https://commons.wikimedia.org/wiki/File:Dacia-Logo-2021.svg"
	},
	{
		"title": "DAF",
		"hex": "00529B",
		"source": "https://www.daf.com/en"
	},
	{
		"title": "daily.dev",
		"hex": "CE3DF3",
		"source": "https://brand.daily.dev/d/4gCtbahXkzKk/guidelines",
		"guidelines": "https://brand.daily.dev"
	},
	{
		"title": "Dailymotion",
		"hex": "0A0A0A",
		"source": "https://careers.dailymotion.com"
	},
	{
		"title": "DaisyUI",
		"hex": "1AD1A5",
		"source": "https://daisyui.com"
	},
	{
		"title": "Dapr",
		"hex": "0D2192",
		"source": "https://github.com/dapr/dapr/blob/18575823c74318c811d6cd6f57ffac76d5debe93/img/dapr_logo.svg"
	},
	{
		"title": "Dark Reader",
		"hex": "141E24",
		"source": "https://github.com/simple-icons/simple-icons/pull/3348#issuecomment-667090608"
	},
	{
		"title": "Dart",
		"hex": "0175C2",
		"source": "https://github.com/dart-lang/site-shared/tree/18458ff440afd3d06f04e5cb871c4c5eda29c9d5/src/_assets/image/dart/logo"
	},
	{
		"title": "Darty",
		"hex": "EB1B23",
		"source": "https://www.darty.com"
	},
	{
		"title": "Das Erste",
		"hex": "001A4B",
		"source": "https://commons.wikimedia.org/wiki/File:Das_Erste_2014.svg"
	},
	{
		"title": "Dash",
		"hex": "008DE4",
		"source": "https://www.dash.org/brand-assets/",
		"guidelines": "https://www.dash.org/brand-guidelines/"
	},
	{
		"title": "Dashlane",
		"hex": "0E353D",
		"source": "https://brandfolder.com/dashlane/brandkitpartners"
	},
	{
		"title": "Dask",
		"hex": "FC6E6B",
		"source": "https://github.com/dask/dask/blob/67e648922512615f94f8a90726423e721d0e3eb2/docs/source/images/dask_icon_black.svg"
	},
	{
		"title": "Dassault Systèmes",
		"hex": "005386",
		"source": "https://www.3ds.com",
		"aliases": {
			"dup": [
				{
					"title": "SolidWorks",
					"hex": "D81E1A"
				}
			]
		}
	},
	{
		"title": "data.ai",
		"hex": "000000",
		"source": "https://www.data.ai/en/about/press/"
	},
	{
		"title": "Databricks",
		"hex": "FF3621",
		"source": "https://www.databricks.com",
		"guidelines": "https://brand.databricks.com/Styleguide/Guide/"
	},
	{
		"title": "DataCamp",
		"hex": "03EF62",
		"source": "https://www.datacamp.com"
	},
	{
		"title": "Datadog",
		"hex": "632CA6",
		"source": "https://www.datadoghq.com/about/resources",
		"guidelines": "https://www.datadoghq.com/about/resources/"
	},
	{
		"title": "DataGrip",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "Dataiku",
		"hex": "2AB1AC",
		"source": "https://www.dataiku.com/company/media-kit/"
	},
	{
		"title": "DataStax",
		"hex": "000000",
		"source": "https://docs.datastax.com/en/astra/astra-db-vector",
		"guidelines": "https://www.datastax.com/brand-resources"
	},
	{
		"title": "date-fns",
		"hex": "770C56",
		"source": "https://date-fns.org"
	},
	{
		"title": "DATEV",
		"hex": "9BD547",
		"source": "https://commons.wikimedia.org/wiki/File:Datev.svg"
	},
	{
		"title": "DatoCMS",
		"hex": "FF7751",
		"source": "https://www.datocms.com/company/brand-assets",
		"guidelines": "https://www.datocms.com/company/brand-assets"
	},
	{
		"title": "Datto",
		"hex": "199ED9",
		"source": "https://www.datto.com/brand/logos",
		"guidelines": "https://www.datto.com/brand"
	},
	{
		"title": "DaVinci Resolve",
		"hex": "233A51",
		"source": "https://www.blackmagicdesign.com/media/images/davinci-resolve-logo-square"
	},
	{
		"title": "Dazhong Dianping",
		"hex": "FF6633",
		"source": "https://www.meituan.com/media",
		"aliases": {
			"loc": {
				"zh-CN": "大众点评"
			}
		}
	},
	{
		"title": "DAZN",
		"hex": "F8F8F5",
		"source": "https://media.dazn.com/en/assets/"
	},
	{
		"title": "DBeaver",
		"hex": "382923",
		"source": "https://dbeaver.com"
	},
	{
		"title": "dblp",
		"hex": "004F9F",
		"source": "https://dblp.org"
	},
	{
		"title": "dbt",
		"hex": "FF694B",
		"source": "https://github.com/fishtown-analytics/dbt-styleguide/blob/a2895e005457eda531880dfde62f31959d42f18b/_includes/icons/logo.svg"
	},
	{
		"title": "DC Entertainment",
		"hex": "0078F0",
		"source": "https://www.readdc.com"
	},
	{
		"title": "De'Longhi",
		"hex": "072240",
		"source": "https://www.delonghi.com"
	},
	{
		"title": "Debian",
		"hex": "A81D33",
		"source": "https://www.debian.org/logos",
		"guidelines": "https://www.debian.org/logos/",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "Debrid-Link",
		"hex": "264E70",
		"source": "https://debrid-link.com/brand",
		"guidelines": "https://debrid-link.com/brand"
	},
	{
		"title": "Decap CMS",
		"hex": "FF0082",
		"source": "https://github.com/decaporg/decap-cms/blob/ba158f4a56d6d79869811971bc1bb0ef15197d30/website/static/img/decap-logo.svg"
	},
	{
		"title": "Decentraland",
		"hex": "FF2D55",
		"source": "https://github.com/decentraland/catalyst/issues/1726#issuecomment-2078585173",
		"guidelines": "https://decentraland.org/brand"
	},
	{
		"title": "DeepCool",
		"hex": "068584",
		"source": "https://www.deepcool.com"
	},
	{
		"title": "Deepgram",
		"hex": "13EF93",
		"source": "https://deepgram.com/company/newsroom",
		"guidelines": "https://deepgram.com/company/newsroom"
	},
	{
		"title": "deepin",
		"hex": "007CFF",
		"source": "https://commons.wikimedia.org/wiki/File:Deepin_logo.svg"
	},
	{
		"title": "DeepL",
		"hex": "0F2B46",
		"source": "https://www.deepl.com/press.html"
	},
	{
		"title": "Deepnote",
		"hex": "3793EF",
		"source": "https://deepnote.com"
	},
	{
		"title": "Deliveroo",
		"hex": "00CCBC",
		"source": "https://deliveroo.com"
	},
	{
		"title": "Dell",
		"hex": "007DB8",
		"source": "https://www.dell.com",
		"guidelines": "https://brand.delltechnologies.com/logos/"
	},
	{
		"title": "Delphi",
		"hex": "E62431",
		"source": "https://www.embarcadero.com/news/logo",
		"guidelines": "https://www.ideracorp.com/legal/embarcadero"
	},
	{
		"title": "Delta",
		"hex": "003366",
		"source": "https://news.delta.com/delta-air-lines-logos-brand-guidelines"
	},
	{
		"title": "Deluge",
		"hex": "094491",
		"source": "https://github.com/deluge-torrent/deluge/blob/0b5f45b486e8e974ba8a0b1d6e8edcd124fca62a/deluge/ui/data/pixmaps/deluge.svg",
		"license": {
			"type": "GPL-3.0-only"
		}
	},
	{
		"title": "Deno",
		"hex": "70FFAF",
		"source": "https://github.com/denoland/docs/blob/5dee713844c7447f80acd4093caa9d350d80bf36/static/img/logo.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Denon",
		"hex": "0B131A",
		"source": "https://www.denon.com",
		"guidelines": "https://www.denon.com/en-us/support/termsofuse.html"
	},
	{
		"title": "Dependabot",
		"hex": "025E8C",
		"source": "https://dependabot.com"
	},
	{
		"title": "Depositphotos",
		"hex": "000000",
		"source": "https://blog.depositphotos.com"
	},
	{
		"title": "Der Spiegel",
		"hex": "E64415",
		"source": "https://www.spiegel.de"
	},
	{
		"title": "Deutsche Bahn",
		"hex": "F01414",
		"source": "https://www.bahn.de"
	},
	{
		"title": "Deutsche Bank",
		"hex": "0018A8",
		"source": "https://www.db.com"
	},
	{
		"title": "Deutsche Post",
		"hex": "FFCC00",
		"source": "https://www.deutschepost.de",
		"guidelines": "https://www.dpdhl-brands.com/de/dp/logo"
	},
	{
		"title": "Deutsche Telekom",
		"hex": "E20074",
		"source": "https://tmap.t-mobile.com/portals/pro74u7a/EXTBrandPortal",
		"guidelines": "https://tmap.t-mobile.com/portals/pro74u7a/EXTBrandPortal",
		"aliases": {
			"aka": [
				"T-Mobile"
			],
			"loc": {
				"de-AT": "Magenta Telekom",
				"mk-MK": "Македонски Телеком"
			}
		}
	},
	{
		"title": "Deutsche Welle",
		"hex": "05B2FC",
		"source": "https://www.dw.com"
	},
	{
		"title": "dev.to",
		"hex": "0A0A0A",
		"source": "https://dev.to"
	},
	{
		"title": "Devbox",
		"hex": "280459",
		"source": "https://github.com/jetify-com/devbox/blob/c3cab01d7375726f0121a25fc0f5c838484246f7/docs/app/static/img/devbox_logo_light.svg"
	},
	{
		"title": "DevExpress",
		"hex": "FF7200",
		"source": "https://www.devexpress.com/aboutus/"
	},
	{
		"title": "DeviantArt",
		"hex": "05CC47",
		"source": "https://help.deviantart.com/21"
	},
	{
		"title": "Devpost",
		"hex": "003E54",
		"source": "https://github.com/challengepost/supportcenter/blob/e40066cde2ed25dc14c0541edb746ff8c6933114/images/devpost-icon-rgb.svg"
	},
	{
		"title": "devRant",
		"hex": "F99A66",
		"source": "https://devrant.com"
	},
	{
		"title": "Dgraph",
		"hex": "E50695",
		"source": "https://dgraph.io"
	},
	{
		"title": "DHL",
		"hex": "FFCC00",
		"source": "https://www.dpdhl-brands.com/dhl/en/guides/design-basics/logo-and-claim.html",
		"guidelines": "https://www.dpdhl-brands.com/dhl/en/guides/design-basics/logo-and-claim.html"
	},
	{
		"title": "diagrams.net",
		"hex": "F08705",
		"source": "https://github.com/jgraph/drawio/blob/4743eba8d5eaa497dc003df7bf7295b695c59bea/src/main/webapp/images/drawlogo.svg",
		"aliases": {
			"aka": [
				"draw.io"
			]
		}
	},
	{
		"title": "Dialogflow",
		"hex": "FF9800",
		"source": "https://dialogflow.cloud.google.com"
	},
	{
		"title": "Diaspora",
		"hex": "000000",
		"source": "https://wiki.diasporafoundation.org/Branding"
	},
	{
		"title": "Dictionary.com",
		"hex": "0049D7",
		"source": "https://www.dictionary.com"
	},
	{
		"title": "Digg",
		"hex": "000000",
		"source": "https://digg.com"
	},
	{
		"title": "Digi-Key Electronics",
		"hex": "CC0000",
		"source": "https://www.digikey.com"
	},
	{
		"title": "DigitalOcean",
		"hex": "0080FF",
		"source": "https://www.digitalocean.com/press/",
		"guidelines": "https://www.digitalocean.com/press/"
	},
	{
		"title": "Diners Club",
		"hex": "004C97",
		"source": "https://www.dinersclub.com/about-us/press"
	},
	{
		"title": "Dior",
		"hex": "000000",
		"source": "https://www.dior.com"
	},
	{
		"title": "Directus",
		"hex": "263238",
		"source": "https://directus.io"
	},
	{
		"title": "Discogs",
		"hex": "333333",
		"source": "https://www.discogs.com/brand"
	},
	{
		"title": "Discord",
		"hex": "5865F2",
		"source": "https://discord.com/branding",
		"guidelines": "https://discord.com/branding"
	},
	{
		"title": "Discourse",
		"hex": "000000",
		"source": "https://www.discourse.org"
	},
	{
		"title": "Discover",
		"hex": "FF6000",
		"source": "https://www.discovernetwork.com/en-us/business-resources/free-signage-logos"
	},
	{
		"title": "Disqus",
		"hex": "2E9FFF",
		"source": "https://disqus.com/brand"
	},
	{
		"title": "Disroot",
		"hex": "50162D",
		"source": "https://disroot.org/en"
	},
	{
		"title": "Distrokid",
		"hex": "231F20",
		"source": "https://distrokid.com/logo"
	},
	{
		"title": "Django",
		"hex": "092E20",
		"source": "https://www.djangoproject.com/community/logos/"
	},
	{
		"title": "DJI",
		"hex": "000000",
		"source": "https://www.dji.com"
	},
	{
		"title": "Dlib",
		"hex": "008000",
		"source": "https://github.com/davisking/dlib/blob/8a2c7442074339ac9ffceff6ef5a49e0114222b9/docs/docs/dlib-logo-and-icons.svg"
	},
	{
		"title": "DLNA",
		"hex": "48A842",
		"source": "https://commons.wikimedia.org/wiki/File:DLNA_logo.svg"
	},
	{
		"title": "dm",
		"hex": "002878",
		"source": "https://www.dm.de",
		"aliases": {
			"aka": [
				"dm-drogerie markt"
			]
		}
	},
	{
		"title": "Docker",
		"hex": "2496ED",
		"source": "https://www.docker.com/company/newsroom/media-resources"
	},
	{
		"title": "Docs.rs",
		"hex": "000000",
		"source": "https://docs.rs"
	},
	{
		"title": "Docsify",
		"hex": "2ECE53",
		"source": "https://github.com/docsifyjs/docsify/blob/d01841fd9d829adeeae6cde1d5818ce8798c7e58/docs/_media/icon.svg"
	},
	{
		"title": "Doctrine",
		"hex": "FC6A31",
		"source": "https://www.doctrine-project.org"
	},
	{
		"title": "Docusaurus",
		"hex": "3ECC5F",
		"source": "https://github.com/facebook/docusaurus/blob/67c40069d1062b5aae530b696e6f66bf9618a696/website/static/img/docusaurus.svg"
	},
	{
		"title": "Dogecoin",
		"hex": "C2A633",
		"source": "https://cryptologos.cc/dogecoin"
	},
	{
		"title": "DOI",
		"hex": "FAB70C",
		"source": "https://www.doi.org/images/logos/header_logo_cropped.svg",
		"guidelines": "https://www.doi.org/resources/130718-trademark-policy.pdf"
	},
	{
		"title": "Dolby",
		"hex": "000000",
		"source": "https://www.dolby.com"
	},
	{
		"title": "DoorDash",
		"hex": "FF3008",
		"source": "https://www.doordash.com/about/"
	},
	{
		"title": "Dota 2",
		"hex": "BF2E1A",
		"source": "https://commons.wikimedia.org/wiki/File:Dota_logo.svg"
	},
	{
		"title": "Douban",
		"hex": "2D963D",
		"source": "https://www.douban.com/about",
		"license": {
			"type": "custom",
			"url": "https://www.douban.com/about/legal#info_data"
		}
	},
	{
		"title": "Douban Read",
		"hex": "389EAC",
		"source": "https://read.douban.com",
		"license": {
			"type": "custom",
			"url": "https://www.douban.com/about/legal#info_data"
		}
	},
	{
		"title": "Dovecot",
		"hex": "54BCAB",
		"source": "https://commons.wikimedia.org/wiki/File:Dovecot_logo.svg"
	},
	{
		"title": "Dovetail",
		"hex": "190041",
		"source": "https://dovetail.com/help/press-kit",
		"guidelines": "https://dovetail.com/help/press-kit"
	},
	{
		"title": "Downdetector",
		"hex": "FF160A",
		"source": "https://downdetector.com"
	},
	{
		"title": "Doxygen",
		"hex": "2C4AA8",
		"source": "https://github.com/doxygen/doxygen/blob/2e73e6a53abe00a57b7eb0ea5ed6474baf4ebab7/templates/html/doxygen.svg"
	},
	{
		"title": "DPD",
		"hex": "DC0032",
		"source": "https://www.dpd.com"
	},
	{
		"title": "Dragonframe",
		"hex": "D4911E",
		"source": "https://dragonframe.com"
	},
	{
		"title": "Draugiem.lv",
		"hex": "FF6600",
		"source": "https://www.frype.com/applications/dev/docs/logos/"
	},
	{
		"title": "Dreamstime",
		"hex": "50A901",
		"source": "https://www.dreamstime.com"
	},
	{
		"title": "Dribbble",
		"hex": "EA4C89",
		"source": "https://dribbble.com/branding"
	},
	{
		"title": "Drizzle",
		"hex": "C5F74F",
		"source": "https://orm.drizzle.team"
	},
	{
		"title": "Drone",
		"hex": "212121",
		"source": "https://github.com/drone/brand/tree/f3ba7a1ad3c35abfe9571ea9c3ea93dff9912955"
	},
	{
		"title": "Drooble",
		"hex": "19C4BE",
		"source": "https://blog.drooble.com/press/"
	},
	{
		"title": "Dropbox",
		"hex": "0061FF",
		"source": "https://www.dropbox.com/branding"
	},
	{
		"title": "Drupal",
		"hex": "0678BE",
		"source": "https://www.drupal.org/about/media-kit/logos"
	},
	{
		"title": "DS Automobiles",
		"hex": "1D1717",
		"source": "https://www.stellantis.com/en/brands/ds"
	},
	{
		"title": "DTS",
		"hex": "F98B2B",
		"source": "https://xperi.com/brands/dts/",
		"guidelines": "https://xperi.com/terms-conditions/"
	},
	{
		"title": "DTube",
		"hex": "F01A30",
		"source": "https://github.com/dtube/about/blob/bb688ac6588bb6e664f61c0e10f03c51f577444b/img/kit/Logo_Black_D.svg"
	},
	{
		"title": "Ducati",
		"hex": "CC0000",
		"source": "https://brandlogos.net/ducati-logo-vector-svg-92931.html"
	},
	{
		"title": "DuckDB",
		"hex": "FFF000",
		"source": "https://duckdb.org"
	},
	{
		"title": "DuckDuckGo",
		"hex": "DE5833",
		"source": "https://github.com/duckduckgo/duckduckgo-privacy-extension/blob/5c6ac8d6a07421adbfb97ee2ff855dd7655f8d71/shared/img/logo-small-grayscale.svg",
		"guidelines": "https://duckduckgo.com/press#press-materials"
	},
	{
		"title": "Dungeons & Dragons",
		"hex": "ED1C24",
		"source": "https://dnd.wizards.com/articles/features/basicrules",
		"guidelines": "https://dnd.wizards.com/articles/features/fan-site-kit",
		"aliases": {
			"aka": [
				"D&D"
			]
		}
	},
	{
		"title": "Dunked",
		"hex": "2DA9D7",
		"source": "https://dunked.com"
	},
	{
		"title": "Dunzo",
		"hex": "00D290",
		"source": "https://www.dunzo.com"
	},
	{
		"title": "Duolingo",
		"hex": "58CC02",
		"source": "https://design.duolingo.com",
		"guidelines": "https://design.duolingo.com"
	},
	{
		"title": "Duplicati",
		"hex": "1E3A8A",
		"source": "https://duplicati.com"
	},
	{
		"title": "DVC",
		"hex": "13ADC7",
		"source": "https://iterative.ai/brand/",
		"guidelines": "https://iterative.ai/brand/",
		"aliases": {
			"aka": [
				"Data Version Control"
			]
		}
	},
	{
		"title": "dwm",
		"hex": "1177AA",
		"source": "https://dwm.suckless.org"
	},
	{
		"title": "Dynatrace",
		"hex": "1496FF",
		"source": "https://www.dynatrace.com/company/press-kit/"
	},
	{
		"title": "E.Leclerc",
		"hex": "0066CC",
		"source": "https://www.e.leclerc/assets/images/sue-logo.svg"
	},
	{
		"title": "E3",
		"hex": "E73D2F",
		"source": "https://commons.wikimedia.org/wiki/File:E3_Logo.svg",
		"aliases": {
			"aka": [
				"Electronic Entertainment Expo"
			]
		}
	},
	{
		"title": "EA",
		"hex": "000000",
		"source": "https://www.ea.com"
	},
	{
		"title": "EAC",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:EAC-black-on-white.svg",
		"aliases": {
			"aka": [
				"Eurasian Conformity"
			]
		}
	},
	{
		"title": "Eagle",
		"hex": "0072EF",
		"source": "https://en.eagle.cool"
	},
	{
		"title": "EasyEDA",
		"hex": "1765F6",
		"source": "https://easyeda.com",
		"aliases": {
			"loc": {
				"zh-CN": "嘉立创EDA"
			}
		}
	},
	{
		"title": "easyJet",
		"hex": "FF6600",
		"source": "https://www.easyjet.com"
	},
	{
		"title": "eBay",
		"hex": "E53238",
		"source": "https://go.developer.ebay.com/logos"
	},
	{
		"title": "EBOX",
		"hex": "BE2323",
		"source": "https://www.ebox.ca"
	},
	{
		"title": "Eclipse Adoptium",
		"hex": "FF1464",
		"source": "https://www.eclipse.org/org/artwork/",
		"guidelines": "https://www.eclipse.org/legal/logo_guidelines.php"
	},
	{
		"title": "Eclipse Che",
		"hex": "525C86",
		"source": "https://www.eclipse.org/che/"
	},
	{
		"title": "Eclipse IDE",
		"hex": "2C2255",
		"source": "https://www.eclipse.org/artwork/"
	},
	{
		"title": "Eclipse Jetty",
		"hex": "FC390E",
		"source": "https://github.com/eclipse/jetty.project/blob/dab26c601d08d350cd830c1007bb196c5196f0f6/logos/jetty-avatar.svg"
	},
	{
		"title": "Eclipse Mosquitto",
		"hex": "3C5280",
		"source": "https://github.com/eclipse/mosquitto/blob/75fc908bba90d4bd06e85efc1c4ed77952ec842c/logo/mosquitto-logo-only.svg"
	},
	{
		"title": "Eclipse Vert.x",
		"hex": "782A90",
		"source": "https://github.com/vert-x3/.github/blob/1ad6612d87f35665e50a00fc32eb9c542556385d/workflow-templates/vertx-favicon.svg"
	},
	{
		"title": "Ecosia",
		"hex": "008009",
		"source": "https://www.ecosia.org/imprint",
		"guidelines": "https://www.ecosia.org/imprint"
	},
	{
		"title": "Ecovacs",
		"hex": "1E384B",
		"source": "https://www.ecovacs.com"
	},
	{
		"title": "EDEKA",
		"hex": "1B66B3",
		"source": "https://www.edeka.de"
	},
	{
		"title": "Edge Impulse",
		"hex": "3B47C2",
		"source": "https://edgeimpulse.com/branding",
		"guidelines": "https://edgeimpulse.com/branding"
	},
	{
		"title": "EditorConfig",
		"hex": "FEFEFE",
		"source": "https://editorconfig.org"
	},
	{
		"title": "Educative",
		"hex": "4951F5",
		"source": "https://www.educative.io"
	},
	{
		"title": "edX",
		"hex": "02262B",
		"source": "https://www.edx.org"
	},
	{
		"title": "egghead",
		"hex": "FCFBFA",
		"source": "https://egghead.io"
	},
	{
		"title": "Egnyte",
		"hex": "00968F",
		"source": "https://www.egnyte.com/presskit.html"
	},
	{
		"title": "Eight",
		"hex": "0054FF",
		"source": "https://8card.net/en"
	},
	{
		"title": "Eight Sleep",
		"hex": "262729",
		"source": "https://www.eightsleep.com/press/"
	},
	{
		"title": "EJS",
		"hex": "B4CA65",
		"source": "https://github.com/mde/ejs-site/blob/dd845093a46b373df42108b888a0ad80085a5c94/ejs.svg"
	},
	{
		"title": "Elastic",
		"hex": "005571",
		"source": "https://www.elastic.co/brand"
	},
	{
		"title": "Elastic Cloud",
		"hex": "005571",
		"source": "https://www.elastic.co/brand"
	},
	{
		"title": "Elastic Stack",
		"hex": "005571",
		"source": "https://www.elastic.co/brand"
	},
	{
		"title": "Elasticsearch",
		"hex": "005571",
		"source": "https://www.elastic.co/brand"
	},
	{
		"title": "Elavon",
		"hex": "0C2074",
		"source": "https://www.elavon.com"
	},
	{
		"title": "Electron",
		"hex": "47848F",
		"source": "https://www.electronjs.org"
	},
	{
		"title": "Electron Fiddle",
		"hex": "E79537",
		"source": "https://github.com/electron/fiddle/blob/19360ade76354240630e5660469b082128e1e57e/assets/icons/fiddle.svg"
	},
	{
		"title": "electron-builder",
		"hex": "000000",
		"source": "https://www.electron.build"
	},
	{
		"title": "Elegoo",
		"hex": "2C3A83",
		"source": "https://www.elegoo.com/pages/download"
	},
	{
		"title": "Element",
		"hex": "0DBD8B",
		"source": "https://element.io"
	},
	{
		"title": "elementary",
		"hex": "64BAFF",
		"source": "https://elementary.io/brand"
	},
	{
		"title": "Elementor",
		"hex": "92003B",
		"source": "https://elementor.com/logos/",
		"guidelines": "https://elementor.com/logos/"
	},
	{
		"title": "ElevenLabs",
		"hex": "000000",
		"source": "https://elevenlabs.io/brand",
		"guidelines": "https://elevenlabs.io/brand"
	},
	{
		"title": "Eleventy",
		"hex": "222222",
		"source": "https://www.11ty.dev",
		"aliases": {
			"aka": [
				"11ty"
			]
		}
	},
	{
		"title": "Elgato",
		"hex": "101010",
		"source": "https://www.elgato.com/en/media-room"
	},
	{
		"title": "Elixir",
		"hex": "4B275F",
		"source": "https://github.com/elixir-lang/elixir-lang.github.com/tree/031746384ee23b9be19298c92a9699c56cc05845/images/logo"
	},
	{
		"title": "Elm",
		"hex": "1293D8",
		"source": "https://github.com/elm/foundation.elm-lang.org/blob/2d097b317d8af2aaeab49284830260a32d817305/assets/elm_logo.svg"
	},
	{
		"title": "Elsevier",
		"hex": "FF6C00",
		"source": "https://www.elsevier.com"
	},
	{
		"title": "Embarcadero",
		"hex": "ED1F35",
		"source": "https://www.embarcadero.com/news/logo"
	},
	{
		"title": "Embark",
		"hex": "000000",
		"source": "https://www.embark-studios.com/press"
	},
	{
		"title": "Ember.js",
		"hex": "E04E39",
		"source": "https://emberjs.com/logos/",
		"guidelines": "https://emberjs.com/logos/"
	},
	{
		"title": "Emby",
		"hex": "52B54B",
		"source": "https://emby.media"
	},
	{
		"title": "Emirates",
		"hex": "D71921",
		"source": "https://www.emirates.com/ie/english/"
	},
	{
		"title": "Emlakjet",
		"hex": "0AE524",
		"source": "https://www.emlakjet.com/kurumsal-materyaller/"
	},
	{
		"title": "Empire Kred",
		"hex": "72BE50",
		"source": "https://www.empire.kred"
	},
	{
		"title": "EndeavourOS",
		"hex": "7F7FFF",
		"source": "https://github.com/endeavouros-team/endeavouros-theming/blob/135f642c980ed8d8fc212783eb478f96226f6c72/endeavouros-logo-text.svg"
	},
	{
		"title": "Engadget",
		"hex": "000000",
		"source": "https://www.engadget.com",
		"guidelines": "https://o.aolcdn.com/engadget/brand-kit/eng-logo-guidelines.pdf"
	},
	{
		"title": "Enpass",
		"hex": "0D47A1",
		"source": "https://www.enpass.io/press/"
	},
	{
		"title": "EnterpriseDB",
		"hex": "FF3E00",
		"source": "https://www.enterprisedb.com"
	},
	{
		"title": "Envato",
		"hex": "87E64B",
		"source": "https://envato.com"
	},
	{
		"title": "Envoy Proxy",
		"hex": "AC6199",
		"source": "https://d33wubrfki0l68.cloudfront.net/6f16455dae972425b77c7e31642269b375ec250e/3bd11/img/envoy-logo.svg"
	},
	{
		"title": "EPEL",
		"hex": "FC0000",
		"source": "https://fedoraproject.org/wiki/EPEL"
	},
	{
		"title": "Epic Games",
		"hex": "313131",
		"source": "https://dev.epicgames.com/docs/services/en-US/EpicAccountServices/DesignGuidelines/index.html#epicgamesbrandguidelines",
		"guidelines": "https://dev.epicgames.com/docs/services/en-US/EpicAccountServices/DesignGuidelines/index.html#epicgamesbrandguidelines"
	},
	{
		"title": "Epson",
		"hex": "003399",
		"source": "https://global.epson.com/IR/library/"
	},
	{
		"title": "Equinix Metal",
		"hex": "ED2224",
		"source": "https://metal.equinix.com"
	},
	{
		"title": "Eraser",
		"hex": "EC2C40",
		"source": "https://www.eraser.io"
	},
	{
		"title": "Ericsson",
		"hex": "0082F0",
		"source": "https://www.ericsson.com/en/newsroom/media-kits/logo",
		"guidelines": "https://mediabank.ericsson.net/admin/mb/?h=dbeb87a1bcb16fa379c0020bdf713872"
	},
	{
		"title": "Erlang",
		"hex": "A90533",
		"source": "https://github.com/erlang/erlide_eclipse/blob/99d1d61fde8e32ef1630ca0e1b05a6822b3d6489/meta/media/erlang-logo.svg"
	},
	{
		"title": "ERPNext",
		"hex": "0089FF",
		"source": "https://github.com/frappe/erpnext/blob/924911e74317f95a59f29e9410d4f141020a0411/erpnext/public/images/erpnext-logo.svg"
	},
	{
		"title": "esbuild",
		"hex": "FFCF00",
		"source": "https://github.com/evanw/esbuild/blob/ac542f913908d7326b65eb2e01f0559ed135a40e/images/logo.svg"
	},
	{
		"title": "ESEA",
		"hex": "0E9648",
		"source": "https://play.esea.net"
	},
	{
		"title": "ESLGaming",
		"hex": "FFFF09",
		"source": "https://brand.eslgaming.com",
		"guidelines": "https://brand.eslgaming.com"
	},
	{
		"title": "ESLint",
		"hex": "4B32C3",
		"source": "https://eslint.org"
	},
	{
		"title": "Esoteric Software",
		"hex": "3FA9F5",
		"source": "https://esotericsoftware.com/forum/d/25405-sheildsio-branding",
		"guidelines": "https://esotericsoftware.com/branding"
	},
	{
		"title": "ESPHome",
		"hex": "000000",
		"source": "https://esphome.io"
	},
	{
		"title": "Espressif",
		"hex": "E7352C",
		"source": "https://www.espressif.com"
	},
	{
		"title": "ESRI",
		"hex": "000000",
		"source": "https://www.esri.com/en-us/arcgis/products/arcgis-pro/overview"
	},
	{
		"title": "etcd",
		"hex": "419EDA",
		"source": "https://cncf-branding.netlify.app/projects/etcd/"
	},
	{
		"title": "Ethereum",
		"hex": "3C3C3D",
		"source": "https://ethereum.org/en/assets/"
	},
	{
		"title": "Ethers",
		"hex": "2535A0",
		"source": "https://docs.ethers.org/v6"
	},
	{
		"title": "Ethiopian Airlines",
		"hex": "648B1A",
		"source": "https://corporate.ethiopianairlines.com/media/Ethiopian-Factsheet"
	},
	{
		"title": "Etihad Airways",
		"hex": "BD8B13",
		"source": "https://www.etihad.com/en-ie/manage/duty-free"
	},
	{
		"title": "Etsy",
		"hex": "F16521",
		"source": "https://www.etsy.com/uk/press"
	},
	{
		"title": "European Union",
		"hex": "003399",
		"source": "https://europa.eu",
		"aliases": {
			"aka": [
				"EU"
			]
		}
	},
	{
		"title": "Event Store",
		"hex": "5AB552",
		"source": "https://github.com/EventStore/Brand/tree/319d6f8dadc2881062917ea5a6dafa675775ea85"
	},
	{
		"title": "Eventbrite",
		"hex": "F05537",
		"source": "https://www.eventbrite.com/signin/"
	},
	{
		"title": "Evernote",
		"hex": "00A82D",
		"source": "https://evernote.com/about-us",
		"guidelines": "https://evernote.com/about-us"
	},
	{
		"title": "Excalidraw",
		"hex": "6965DB",
		"source": "https://excalidraw.com"
	},
	{
		"title": "Exercism",
		"hex": "009CAB",
		"source": "https://github.com/exercism/website-icons/blob/2ad12baa465acfaa74efc5da27a6a12f8b05e3d0/exercism/logo-icon.svg",
		"license": {
			"type": "CC-BY-3.0"
		}
	},
	{
		"title": "Exordo",
		"hex": "DAA449",
		"source": "https://www.exordo.com"
	},
	{
		"title": "Exoscale",
		"hex": "DA291C",
		"source": "https://www.exoscale.com/press/",
		"guidelines": "https://www.exoscale.com/press/"
	},
	{
		"title": "Expedia",
		"hex": "191E3B",
		"source": "https://brandfolder.com/portals/brand-expedia",
		"guidelines": "https://brandfolder.com/portals/brand-expedia"
	},
	{
		"title": "Expensify",
		"hex": "0185FF",
		"source": "https://use.expensify.com/press-kit",
		"guidelines": "https://use.expensify.com/press-kit"
	},
	{
		"title": "Experts Exchange",
		"hex": "00AAE7",
		"source": "https://www.experts-exchange.com"
	},
	{
		"title": "Expo",
		"hex": "1C2024",
		"source": "https://expo.dev/brand/",
		"guidelines": "https://expo.dev/brand/"
	},
	{
		"title": "Express",
		"hex": "000000",
		"source": "https://github.com/openjs-foundation/artwork/blob/ac43961d1157f973c54f210cf5e0c9c45e3d3f10/projects/express/express-icon-black.svg"
	},
	{
		"title": "Express.com",
		"hex": "000000",
		"source": "https://www.express.com"
	},
	{
		"title": "ExpressVPN",
		"hex": "DA3940",
		"source": "https://www.expressvpn.com/press",
		"guidelines": "https://www.expressvpn.com/press"
	},
	{
		"title": "EyeEm",
		"hex": "000000",
		"source": "https://www.eyeem.com"
	},
	{
		"title": "F-Droid",
		"hex": "1976D2",
		"source": "https://f-droid.org",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "F-Secure",
		"hex": "00BAFF",
		"source": "https://vip.f-secure.com/en/marketing/logos"
	},
	{
		"title": "F#",
		"slug": "fsharp",
		"hex": "378BBA",
		"source": "https://foundation.fsharp.org/logo",
		"guidelines": "https://foundation.fsharp.org/logo",
		"aliases": {
			"aka": [
				"F sharp"
			]
		}
	},
	{
		"title": "F1",
		"hex": "E10600",
		"source": "https://www.formula1.com"
	},
	{
		"title": "F5",
		"hex": "E4002B",
		"source": "https://www.f5.com/company/news/press-kit"
	},
	{
		"title": "Facebook",
		"hex": "0866FF",
		"source": "https://about.meta.com/brand/resources/facebook/logo",
		"guidelines": "https://about.meta.com/brand/resources/facebook/logo"
	},
	{
		"title": "Facebook Gaming",
		"hex": "005FED",
		"source": "https://www.facebook.com/fbgaminghome/"
	},
	{
		"title": "Facebook Live",
		"hex": "ED4242",
		"source": "https://en.facebookbrand.com"
	},
	{
		"title": "FACEIT",
		"hex": "FF5500",
		"source": "https://corporate.faceit.com/branding/"
	},
	{
		"title": "Facepunch",
		"hex": "EC1C24",
		"source": "https://sbox.facepunch.com/news"
	},
	{
		"title": "Fairphone",
		"hex": "4495D1",
		"source": "https://www.fairphone.com"
	},
	{
		"title": "Falco",
		"hex": "00AEC7",
		"source": "https://falco.org/community/falco-brand",
		"guidelines": "https://falco.org/community/falco-brand"
	},
	{
		"title": "Falcon",
		"hex": "F0AD4E",
		"source": "https://falconframework.org"
	},
	{
		"title": "FamPay",
		"hex": "FFAD00",
		"source": "https://fampay.in"
	},
	{
		"title": "Fandango",
		"hex": "FF7300",
		"source": "https://www.fandango.com"
	},
	{
		"title": "Fandom",
		"hex": "FA005A",
		"source": "https://fandomdesignsystem.com"
	},
	{
		"title": "Fanfou",
		"hex": "00CCFF",
		"source": "https://fanfou.com"
	},
	{
		"title": "Fantom",
		"hex": "0928FF",
		"source": "https://fantom.foundation"
	},
	{
		"title": "Farcaster",
		"hex": "855DCD",
		"source": "https://www.farcaster.xyz"
	},
	{
		"title": "FareHarbor",
		"hex": "0A6ECE",
		"source": "https://help.fareharbor.com/about/logo",
		"guidelines": "https://help.fareharbor.com/about/logo"
	},
	{
		"title": "FARFETCH",
		"hex": "000000",
		"source": "https://www.farfetch.com"
	},
	{
		"title": "FastAPI",
		"hex": "009688",
		"source": "https://github.com/tiangolo/fastapi/blob/ffb4f77a11f83132b521ba0aac6c95792c19e797/docs/en/docs/img/icon-white.svg"
	},
	{
		"title": "Fastify",
		"hex": "000000",
		"source": "https://github.com/fastify/graphics/blob/91e8a3d4754807de3b69440f66c72a737a5fde94/fastify-1000px-square-02.svg"
	},
	{
		"title": "Fastlane",
		"hex": "00F200",
		"source": "https://github.com/fastlane/fastlane.tools/blob/19ff41a6c0f27510a7a7879e6944809d40ab382e/assets/img/logo-mobile.svg"
	},
	{
		"title": "Fastly",
		"hex": "FF282D",
		"source": "https://assets.fastly.com/style-guide/docs/"
	},
	{
		"title": "Fathom",
		"hex": "9187FF",
		"source": "https://usefathom.com/brand"
	},
	{
		"title": "Fauna",
		"hex": "3A1AB6",
		"source": "https://fauna.com"
	},
	{
		"title": "Favro",
		"hex": "512DA8",
		"source": "https://favro.com/login"
	},
	{
		"title": "FCC",
		"hex": "1C3664",
		"source": "https://www.fcc.gov/logos",
		"guidelines": "https://apps.fcc.gov/oetcf/kdb/forms/FTSSearchResultPage.cfm?id=27980&switch=P",
		"license": {
			"type": "custom",
			"url": "https://www.fcc.gov/licensing"
		},
		"aliases": {
			"aka": [
				"Federal Communications Commission"
			]
		}
	},
	{
		"title": "FedEx",
		"hex": "4D148C",
		"source": "https://newsroom.fedex.com"
	},
	{
		"title": "Fedora",
		"hex": "51A2DA",
		"source": "https://docs.fedoraproject.org/en-US/project/brand/",
		"guidelines": "https://fedoraproject.org/wiki/Legal:Trademark_guidelines",
		"license": {
			"type": "custom",
			"url": "https://docs.fedoraproject.org/en-US/project/brand/"
		}
	},
	{
		"title": "Feedly",
		"hex": "2BB24C",
		"source": "https://blog.feedly.com"
	},
	{
		"title": "Ferrari",
		"hex": "D40000",
		"source": "https://www.ferrari.com"
	},
	{
		"title": "Ferrari N.V.",
		"slug": "ferrarinv",
		"hex": "EB2E2C",
		"source": "https://corporate.ferrari.com"
	},
	{
		"title": "FerretDB",
		"hex": "042133",
		"source": "https://github.com/FerretDB/FerretDB/blob/1176606075dfe52225ce0cd1bbd0cd06128f8599/website/static/img/logo.svg"
	},
	{
		"title": "FFmpeg",
		"hex": "007808",
		"source": "https://commons.wikimedia.org/wiki/File:FFmpeg_Logo_new.svg"
	},
	{
		"title": "Fi",
		"hex": "00B899",
		"source": "https://fi.money",
		"aliases": {
			"aka": [
				"epiFi",
				"Fi.Money"
			]
		}
	},
	{
		"title": "Fiat",
		"hex": "941711",
		"source": "https://www.fcaci.com/x/FIATv15"
	},
	{
		"title": "Fido Alliance",
		"hex": "FFBF3B",
		"source": "https://fidoalliance.org/overview/legal/logo-usage/",
		"guidelines": "https://fidoalliance.org/overview/legal/fido-trademark-and-service-mark-usage-agreement-for-websites/"
	},
	{
		"title": "FIFA",
		"hex": "326295",
		"source": "https://en.wikipedia.org/wiki/FIFA"
	},
	{
		"title": "Fig",
		"hex": "000000",
		"source": "https://fig.io/icons/fig.svg"
	},
	{
		"title": "Figma",
		"hex": "F24E1E",
		"source": "https://www.figma.com/using-the-figma-brand/",
		"guidelines": "https://www.figma.com/using-the-figma-brand/"
	},
	{
		"title": "figshare",
		"hex": "556472",
		"source": "https://en.wikipedia.org/wiki/Figshare"
	},
	{
		"title": "Fila",
		"hex": "002D62",
		"source": "https://www.fila.com"
	},
	{
		"title": "Filament",
		"hex": "FDAE4B",
		"source": "https://filamentphp.com"
	},
	{
		"title": "File.io",
		"hex": "3D3C9D",
		"source": "https://www.file.io"
	},
	{
		"title": "Filen",
		"hex": "000000",
		"source": "https://github.com/FilenCloudDienste/filen-drive-legacy/issues/166#issue-2139393162"
	},
	{
		"title": "Files",
		"hex": "4285F4",
		"source": "https://files.google.com"
	},
	{
		"title": "FileZilla",
		"hex": "BF0000",
		"source": "https://commons.wikimedia.org/wiki/File:FileZilla_logo.svg"
	},
	{
		"title": "Fineco",
		"hex": "00549F",
		"source": "https://finecobank.com"
	},
	{
		"title": "Fing",
		"hex": "009AEE",
		"source": "https://www.fing.com"
	},
	{
		"title": "Firebase",
		"hex": "DD2C00",
		"source": "https://firebase.google.com/brand-guidelines",
		"guidelines": "https://firebase.google.com/brand-guidelines"
	},
	{
		"title": "Firefish",
		"hex": "F07A5B",
		"source": "https://joinfirefish.org/about/#brand",
		"guidelines": "https://joinfirefish.org/about/#brand"
	},
	{
		"title": "Firefly III",
		"hex": "CD5029",
		"source": "https://docs.firefly-iii.org/explanation/more-information/logo"
	},
	{
		"title": "Firefox",
		"hex": "FF7139",
		"source": "https://mozilla.design/firefox/logos-usage/",
		"guidelines": "https://mozilla.design/firefox/logos-usage/"
	},
	{
		"title": "Firefox Browser",
		"hex": "FF7139",
		"source": "https://mozilla.design/firefox/logos-usage/"
	},
	{
		"title": "Fireship",
		"hex": "EB844E",
		"source": "https://github.com/fireship-io/fireship.io/blob/987da97305a5968b99347aa748f928a4667336f8/hugo/layouts/partials/svg/logo.svg"
	},
	{
		"title": "Firewalla",
		"hex": "C8332D",
		"source": "https://github.com/firewalla/firewalla/blob/97f7463fe07b85b979a8f0738fdf14c1af0249a8/extension/diag/static/firewalla.svg"
	},
	{
		"title": "FIRST",
		"hex": "0066B3",
		"source": "https://www.firstinspires.org/brand",
		"guidelines": "https://www.firstinspires.org/brand"
	},
	{
		"title": "fish shell",
		"hex": "34C534",
		"source": "https://github.com/fish-shell/fish-site/blob/1364b2e794c9aba7492c8962bae0f7fbe4886317/artwork/ascii%20fish.eps",
		"license": {
			"type": "GPL-2.0-only"
		}
	},
	{
		"title": "Fitbit",
		"hex": "00B0B9",
		"source": "https://www.fitbit.com/uk/home"
	},
	{
		"title": "FiveM",
		"hex": "F40552",
		"source": "https://fivem.net"
	},
	{
		"title": "Fiverr",
		"hex": "1DBF73",
		"source": "https://www.fiverr.com/press-kit"
	},
	{
		"title": "Fizz",
		"hex": "00D672",
		"source": "https://fizz.ca"
	},
	{
		"title": "Flashforge",
		"hex": "000000",
		"source": "https://www.flashforge.com"
	},
	{
		"title": "Flask",
		"hex": "000000",
		"source": "https://github.com/pallets/flask/blob/e6e75e55470a0682ee8370e6d68062e515a248b9/artwork/logo-full.svg",
		"license": {
			"type": "custom",
			"url": "https://github.com/pallets/flask/blob/master/artwork/LICENSE.rst"
		}
	},
	{
		"title": "Flat",
		"hex": "3481FE",
		"source": "https://github.com/netless-io/flat/blob/525b2247f36e96ae2f9e6a39b4fe0967152305f2/desktop/renderer-app/src/assets/image/logo.svg"
	},
	{
		"title": "Flathub",
		"hex": "000000",
		"source": "https://flathub.org"
	},
	{
		"title": "Flatpak",
		"hex": "4A90D9",
		"source": "https://flatpak.org/press",
		"guidelines": "https://flatpak.org/press",
		"license": {
			"type": "CC-BY-3.0"
		}
	},
	{
		"title": "Flickr",
		"hex": "0063DC",
		"source": "https://www.flickr.com"
	},
	{
		"title": "Flightaware",
		"hex": "19315B",
		"source": "https://flightaware.com/about/logo"
	},
	{
		"title": "Flipboard",
		"hex": "E12828",
		"source": "https://about.flipboard.com/brand-guidelines"
	},
	{
		"title": "Flipkart",
		"hex": "2874F0",
		"source": "https://www.flipkart.com"
	},
	{
		"title": "Floatplane",
		"hex": "00AEEF",
		"source": "https://www.floatplane.com"
	},
	{
		"title": "Flood",
		"hex": "4285F4",
		"source": "https://flood.io"
	},
	{
		"title": "Fluent Bit",
		"hex": "49BDA5",
		"source": "https://github.com/fluent/fluent-bit/blob/cdb35721d06242d66a729656282831ccd1589ca2/snap/fluent-bit.svg"
	},
	{
		"title": "Fluentd",
		"hex": "0E83C8",
		"source": "https://docs.fluentd.org/quickstart/logo",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Fluke",
		"hex": "FFC20E",
		"source": "https://www.fluke.com",
		"guidelines": "https://www.fluke.com/en-us/fluke/fluke-terms-of-use"
	},
	{
		"title": "Flutter",
		"hex": "02569B",
		"source": "https://flutter.dev/brand",
		"guidelines": "https://flutter.dev/brand"
	},
	{
		"title": "Flux",
		"hex": "5468FF",
		"source": "https://github.com/cncf/artwork/blob/c2e619cdf85e8bac090ceca7c0834c5cfedf9426/projects/flux/icon/black/flux-icon-black.svg",
		"guidelines": "https://www.cncf.io/brand-guidelines/",
		"license": {
			"type": "custom",
			"url": "https://www.linuxfoundation.org/legal/trademark-usage"
		}
	},
	{
		"title": "Fly.io",
		"hex": "24175B",
		"source": "https://fly.io/docs/about/brand",
		"guidelines": "https://fly.io/docs/about/brand"
	},
	{
		"title": "Flyway",
		"hex": "CC0200",
		"source": "https://github.com/flyway/flywaydb.org/blob/8a7923cb9ead016442d4c5caf2e8ba5a9bfad5cf/assets/logo/flyway-logo.png"
	},
	{
		"title": "FMOD",
		"hex": "000000",
		"source": "https://www.fmod.com/attribution",
		"guidelines": "https://www.fmod.com/attribution"
	},
	{
		"title": "Fnac",
		"hex": "E1A925",
		"source": "https://www.fnac.com"
	},
	{
		"title": "Folium",
		"hex": "77B829",
		"source": "https://python-visualization.github.io/folium/"
	},
	{
		"title": "Fonoma",
		"hex": "02B78F",
		"source": "https://en.fonoma.com"
	},
	{
		"title": "Font Awesome",
		"hex": "538DD7",
		"source": "https://fontawesome.com"
	},
	{
		"title": "FontBase",
		"hex": "3D03A7",
		"source": "https://fontba.se"
	},
	{
		"title": "FontForge",
		"hex": "F2712B",
		"source": "https://fontforge.org"
	},
	{
		"title": "foobar2000",
		"hex": "000000",
		"source": "https://hydrogenaud.io/index.php?topic=55604.0"
	},
	{
		"title": "foodpanda",
		"hex": "D70F64",
		"source": "https://www.foodpanda.com"
	},
	{
		"title": "Ford",
		"hex": "00274E",
		"source": "https://secure.ford.com/brochures/"
	},
	{
		"title": "Forgejo",
		"hex": "FB923C",
		"source": "https://codeberg.org/forgejo/meta/raw/branch/readme/branding/logo/forgejo-monochrome.svg",
		"guidelines": "https://codeberg.org/forgejo/meta/src/branch/readme/branding/README.md#logo",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Formik",
		"hex": "2563EB",
		"source": "https://formik.org"
	},
	{
		"title": "Formspree",
		"hex": "E5122E",
		"source": "https://formspree.io"
	},
	{
		"title": "Formstack",
		"hex": "21B573",
		"source": "https://www.formstack.com/brand/guidelines"
	},
	{
		"title": "Fortinet",
		"hex": "EE3124",
		"source": "https://www.fortinet.com"
	},
	{
		"title": "Fortnite",
		"hex": "000000",
		"source": "https://www.fortnite.com"
	},
	{
		"title": "Fortran",
		"hex": "734F96",
		"source": "https://github.com/fortran-lang/fortran-lang.org/blob/5469465d08d3fcbf16d048e651ca5c9ba050839c/assets/img/fortran-logo.svg"
	},
	{
		"title": "Fossa",
		"hex": "289E6D",
		"source": "https://fossa.com/press/"
	},
	{
		"title": "Fossil SCM",
		"hex": "548294",
		"source": "https://fossil-scm.org"
	},
	{
		"title": "Foundry Virtual Tabletop",
		"hex": "FE6A1F",
		"source": "https://github.com/simple-icons/simple-icons/issues/5828#issuecomment-1977557112"
	},
	{
		"title": "Foursquare",
		"hex": "3333FF",
		"source": "https://foursquare.com/brand/",
		"guidelines": "https://foursquare.com/brand/"
	},
	{
		"title": "FOX",
		"hex": "000000",
		"source": "https://www.fox.com"
	},
	{
		"title": "Foxtel",
		"hex": "EB5205",
		"source": "https://www.foxtel.com.au"
	},
	{
		"title": "Fozzy",
		"hex": "F15B29",
		"source": "https://fozzy.com/partners.shtml?tab=materials"
	},
	{
		"title": "Framer",
		"hex": "0055FF",
		"source": "https://framer.com"
	},
	{
		"title": "Framework",
		"hex": "000000",
		"source": "https://frame.work"
	},
	{
		"title": "Framework7",
		"hex": "EE350F",
		"source": "https://github.com/framework7io/framework7-website/blob/2a1e32290c795c2070ffc7019ba7276614e00de0/public/i/logo.svg"
	},
	{
		"title": "Franprix",
		"hex": "EC6237",
		"source": "https://www.franprix.fr"
	},
	{
		"title": "Frappe",
		"hex": "0089FF",
		"source": "https://github.com/frappe/frappe/blob/1331fa6f721122805d15894fa3bd9eb90dccdca2/frappe/public/images/frappe-framework-logo.svg"
	},
	{
		"title": "Fraunhofer-Gesellschaft",
		"hex": "179C7D",
		"source": "https://www.fraunhofer.de"
	},
	{
		"title": "FreeBSD",
		"hex": "AB2B28",
		"source": "https://www.freebsdfoundation.org/about/project/"
	},
	{
		"title": "FreeCAD",
		"hex": "418FDE",
		"source": "https://fpa.freecad.org/handbook/process/logo.html",
		"guidelines": "https://fpa.freecad.org/handbook/process/logo.html"
	},
	{
		"title": "freeCodeCamp",
		"hex": "0A0A23",
		"source": "https://design-style-guide.freecodecamp.org",
		"guidelines": "https://design-style-guide.freecodecamp.org",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "freedesktop.org",
		"hex": "3B80AE",
		"source": "https://commons.wikimedia.org/wiki/File:Freedesktop-logo.svg",
		"license": {
			"type": "GPL-2.0-or-later"
		}
	},
	{
		"title": "Freelancer",
		"hex": "29B2FE",
		"source": "https://www.freelancer.com"
	},
	{
		"title": "freelancermap",
		"hex": "00CFD6",
		"source": "https://freelancermap.de"
	},
	{
		"title": "FreeNAS",
		"hex": "343434",
		"source": "https://github.com/freenas/webui/blob/fd668f4c5920fe864fd98fa98e20fd333336c609/src/assets/images/logo.svg"
	},
	{
		"title": "freenet",
		"hex": "84BC34",
		"source": "https://www.freenet.ag"
	},
	{
		"title": "Freepik",
		"hex": "1273EB",
		"source": "https://commons.wikimedia.org/wiki/File:Freepik.svg"
	},
	{
		"title": "Fresh",
		"hex": "FFDB1E",
		"source": "https://github.com/denoland/fresh/blob/7e4a22f7af55192a53d90ec6e6bfeacd213c169d/www/static/logo.svg"
	},
	{
		"title": "Frontend Mentor",
		"hex": "3F54A3",
		"source": "https://www.frontendmentor.io"
	},
	{
		"title": "Frontify",
		"hex": "2D3232",
		"source": "https://brand.frontify.com",
		"guidelines": "https://brand.frontify.com"
	},
	{
		"title": "Fubo",
		"hex": "C83D1E",
		"source": "https://www.fubo.tv",
		"guidelines": "https://www.fubo.tv/press-inquiries"
	},
	{
		"title": "Fueler",
		"hex": "09C9E3",
		"source": "https://fueler.io"
	},
	{
		"title": "Fuga Cloud",
		"hex": "242F4B",
		"source": "https://fuga.cloud",
		"guidelines": "https://fuga.cloud/media/"
	},
	{
		"title": "Fujifilm",
		"hex": "FB0020",
		"source": "https://www.fujifilm.com",
		"guidelines": "https://www.fujifilm.com/us/en/terms"
	},
	{
		"title": "Fujitsu",
		"hex": "FF0000",
		"source": "https://www.fujitsu.com/global/about/brandmanagement/logo/"
	},
	{
		"title": "Fur Affinity",
		"hex": "36566F",
		"source": "https://www.furaffinity.net"
	},
	{
		"title": "Furry Network",
		"hex": "2E75B4",
		"source": "https://furrynetwork.com"
	},
	{
		"title": "FusionAuth",
		"hex": "F58320",
		"source": "https://fusionauth.io/brand-logo-guidelines",
		"guidelines": "https://fusionauth.io/brand-logo-guidelines"
	},
	{
		"title": "FutureLearn",
		"hex": "DE00A5",
		"source": "https://www.futurelearn.com"
	},
	{
		"title": "Fyle",
		"hex": "FF2E63",
		"source": "https://www.fylehq.com"
	},
	{
		"title": "G2",
		"hex": "FF492C",
		"source": "https://www.g2.com",
		"guidelines": "https://company.g2.com/brand-resources"
	},
	{
		"title": "G2A",
		"hex": "F05F00",
		"source": "https://www.g2a.co/documents/",
		"guidelines": "https://www.g2a.co/documents/"
	},
	{
		"title": "G2G",
		"hex": "ED1C24",
		"source": "https://hydron.holdings/media/media_kit"
	},
	{
		"title": "Galaxus",
		"hex": "000000",
		"source": "https://www.galaxus.de"
	},
	{
		"title": "Game Developer",
		"hex": "E60012",
		"source": "https://www.gamedeveloper.com",
		"aliases": {
			"aka": [
				"Gamasutra"
			]
		}
	},
	{
		"title": "Game Jolt",
		"hex": "CCFF00",
		"source": "https://gamejolt.com/about",
		"guidelines": "https://gamejolt.com/about"
	},
	{
		"title": "Game Science",
		"hex": "000000",
		"source": "https://gamesci.com.cn"
	},
	{
		"title": "GameBanana",
		"hex": "FCEF40",
		"source": "https://gamebanana.com/tools/3474",
		"license": {
			"type": "CC-BY-NC-ND-4.0"
		}
	},
	{
		"title": "Gameloft",
		"hex": "000000",
		"source": "https://www.gameloft.com"
	},
	{
		"title": "Gamemaker",
		"hex": "000000",
		"source": "https://gamemaker.io/en/legal/brand",
		"guidelines": "https://gamemaker.io/en/legal/brand"
	},
	{
		"title": "Gandi",
		"hex": "6640FE",
		"source": "https://news.gandi.net/en/presskit/"
	},
	{
		"title": "Garmin",
		"hex": "000000",
		"source": "https://creative.garmin.com/styleguide/logo/",
		"guidelines": "https://creative.garmin.com/styleguide/brand/"
	},
	{
		"title": "Gatling",
		"hex": "FF9E2A",
		"source": "https://gatling.io"
	},
	{
		"title": "Gatsby",
		"hex": "663399",
		"source": "https://www.gatsbyjs.com/guidelines/logo",
		"guidelines": "https://www.gatsbyjs.com/guidelines/logo"
	},
	{
		"title": "Gcore",
		"hex": "FF4C00",
		"source": "https://gcore.com"
	},
	{
		"title": "GDAL",
		"hex": "5CAE58",
		"source": "https://www.osgeo.org/projects/gdal/"
	},
	{
		"title": "GeeksforGeeks",
		"hex": "2F8D46",
		"source": "https://www.geeksforgeeks.org"
	},
	{
		"title": "General Electric",
		"hex": "0870D8",
		"source": "https://www.ge.com/brand/"
	},
	{
		"title": "General Motors",
		"hex": "0170CE",
		"source": "https://www.gm.com"
	},
	{
		"title": "Genius",
		"hex": "FFFF64",
		"source": "https://genius.com"
	},
	{
		"title": "Gentoo",
		"hex": "54487A",
		"source": "https://wiki.gentoo.org/wiki/Project:Artwork/Artwork#Variations_of_the_.22g.22_logo",
		"guidelines": "https://www.gentoo.org/inside-gentoo/foundation/name-logo-guidelines.html",
		"license": {
			"type": "CC-BY-SA-2.5"
		}
	},
	{
		"title": "Geocaching",
		"hex": "00874D",
		"source": "https://www.geocaching.com/about/logousage.aspx",
		"guidelines": "https://www.geocaching.com/about/logousage.aspx"
	},
	{
		"title": "Geode",
		"hex": "8D7ACF",
		"source": "https://github.com/geode-sdk/website/blob/a6a6aa7eaad8ce699d0e050b2b0c1c0119f3624a/media/geode_logos.zip"
	},
	{
		"title": "GeoPandas",
		"hex": "139C5A",
		"source": "https://geopandas.org",
		"guidelines": "https://geopandas.org/en/stable/about/logo.html"
	},
	{
		"title": "Gerrit",
		"hex": "EEEEEE",
		"source": "https://gerrit-review.googlesource.com/c/75842/"
	},
	{
		"title": "GetX",
		"hex": "8A2BE2",
		"source": "https://github.com/simple-icons/simple-icons/issues/5940#issuecomment-1821561714"
	},
	{
		"title": "Ghost",
		"hex": "15171A",
		"source": "https://github.com/TryGhost/Admin/blob/e3e1fa3353767c3729b1658ad42cc35f883470c5/public/assets/icons/icon.svg",
		"guidelines": "https://ghost.org/docs/logos/"
	},
	{
		"title": "Ghostery",
		"hex": "00AEF0",
		"source": "https://www.ghostery.com",
		"guidelines": "https://www.ghostery.com/press/"
	},
	{
		"title": "GIMP",
		"hex": "5C5543",
		"source": "https://www.gimp.org/about/linking.html#wilber-the-gimp-mascot",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "Gin",
		"hex": "008ECF",
		"source": "https://github.com/gin-gonic/logo/blob/eecb3150aa7ce5a77b97fd834276b2b6958eaa9d/wb.svg",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "GIPHY",
		"hex": "FF6666",
		"source": "https://support.giphy.com/hc/en-us/articles/360022283772-GIPHY-Brand-Guidelines",
		"guidelines": "https://support.giphy.com/hc/en-us/articles/360022283772-GIPHY-Brand-Guidelines"
	},
	{
		"title": "Git",
		"hex": "F05032",
		"source": "https://git-scm.com/downloads/logos",
		"license": {
			"type": "CC-BY-3.0"
		}
	},
	{
		"title": "Git Extensions",
		"hex": "212121",
		"source": "https://github.com/gitextensions/gitextensions/blob/273a0f6fd3e07858f837cdc19d50827871e32319/Logo/Artwork/git-extensions-logo.svg"
	},
	{
		"title": "Git for Windows",
		"hex": "80B3FF",
		"source": "https://github.com/git-for-windows/git-for-windows.github.io/blob/db9a134ed0fd484568124c1f79cb011eddb9a21d/img/gwindows_logo.svg"
	},
	{
		"title": "Git LFS",
		"hex": "F64935",
		"source": "https://git-lfs.github.com"
	},
	{
		"title": "GitBook",
		"hex": "BBDDE5",
		"source": "https://www.gitbook.com"
	},
	{
		"title": "Gitconnected",
		"hex": "2E69AE",
		"source": "https://gitconnected.com/richard-hendricks-demo/resume"
	},
	{
		"title": "Gitea",
		"hex": "609926",
		"source": "https://github.com/go-gitea/gitea/blob/e0c753e770a64cda5e3900aa1da3d7e1f3263c9a/assets/logo.svg"
	},
	{
		"title": "Gitee",
		"hex": "C71D23",
		"source": "https://gitee.com/about_us"
	},
	{
		"title": "GitHub",
		"hex": "181717",
		"source": "https://github.com/logos",
		"guidelines": "https://github.com/logos"
	},
	{
		"title": "GitHub Actions",
		"hex": "2088FF",
		"source": "https://github.com/features/actions"
	},
	{
		"title": "GitHub Copilot",
		"hex": "000000",
		"source": "https://primer.style/foundations/icons/copilot-24",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "GitHub Pages",
		"hex": "222222",
		"source": "https://pages.github.com"
	},
	{
		"title": "GitHub Sponsors",
		"hex": "EA4AAA",
		"source": "https://github.com/sponsors"
	},
	{
		"title": "gitignore.io",
		"hex": "204ECF",
		"source": "https://docs.gitignore.io/design/logo"
	},
	{
		"title": "GitKraken",
		"hex": "179287",
		"source": "https://www.gitkraken.com"
	},
	{
		"title": "GitLab",
		"hex": "FC6D26",
		"source": "https://about.gitlab.com/press/press-kit/",
		"guidelines": "https://about.gitlab.com/handbook/marketing/corporate-marketing/brand-activation/trademark-guidelines/"
	},
	{
		"title": "Gitpod",
		"hex": "FFAE33",
		"source": "https://www.gitpod.io"
	},
	{
		"title": "Gitter",
		"hex": "ED1965",
		"source": "https://gitter.im"
	},
	{
		"title": "GL.iNet",
		"hex": "636363",
		"source": "https://www.gl-inet.com/press/"
	},
	{
		"title": "Glassdoor",
		"hex": "00A162",
		"source": "https://www.glassdoor.com/about/newsroom",
		"guidelines": "https://www.glassdoor.com/about/newsroom"
	},
	{
		"title": "Gleam",
		"hex": "FFAFF3",
		"source": "https://gleam.run",
		"guidelines": "https://gleam.run/branding",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Glide",
		"hex": "18BED4",
		"source": "https://brand.glide.page/dl/brand-assets",
		"guidelines": "https://brand.glide.page/dl/brand-assets"
	},
	{
		"title": "Glitch",
		"hex": "3333FF",
		"source": "https://glitch.com/about/press/"
	},
	{
		"title": "Globus",
		"hex": "CA6201",
		"source": "https://www.globus.de"
	},
	{
		"title": "Glovo",
		"hex": "F2CC38",
		"source": "https://about.glovoapp.com/press"
	},
	{
		"title": "glTF",
		"hex": "87C540",
		"source": "https://www.khronos.org/legal/trademarks",
		"guidelines": "https://www.khronos.org/files/legal/Khronos-Logo-Usage-Guide.pdf"
	},
	{
		"title": "Gmail",
		"hex": "EA4335",
		"source": "https://fonts.gstatic.com/s/i/productlogos/gmail_2020q4/v8/192px.svg"
	},
	{
		"title": "GMX",
		"hex": "1C449B",
		"source": "https://www.united-internet.de/en/newsroom/media-center/logos.html"
	},
	{
		"title": "GNOME",
		"hex": "4A86CF",
		"source": "https://wiki.gnome.org/Engagement/BrandGuidelines",
		"guidelines": "https://gitlab.gnome.org/Teams/Design/brand/-/blob/master/brand-book.pdf"
	},
	{
		"title": "GNOME Terminal",
		"hex": "241F31",
		"source": "https://gitlab.gnome.org/GNOME/gnome-terminal/-/blob/9c32e039bfb7902c136dc7aed3308e027325776c/data/icons/hicolor_apps_scalable_org.gnome.Terminal.svg",
		"guidelines": "https://gitlab.gnome.org/Teams/Design/brand/-/blob/master/brand-book.pdf"
	},
	{
		"title": "GNU",
		"hex": "A42E2B",
		"source": "https://gnu.org",
		"license": {
			"type": "CC-BY-SA-2.0"
		}
	},
	{
		"title": "GNU Bash",
		"hex": "4EAA25",
		"source": "https://github.com/odb/official-bash-logo/tree/61eff022f2dad3c7468f5deb4f06652d15f2c143",
		"guidelines": "https://github.com/odb/official-bash-logo",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "GNU Emacs",
		"hex": "7F5AB6",
		"source": "https://git.savannah.gnu.org/cgit/emacs.git/tree/etc/images/icons/hicolor/scalable/apps/emacs.svg",
		"license": {
			"type": "GPL-2.0-or-later"
		}
	},
	{
		"title": "GNU IceCat",
		"hex": "002F5B",
		"source": "https://git.savannah.gnu.org/cgit/gnuzilla.git/plain/artwork/simple.svg"
	},
	{
		"title": "GNU Privacy Guard",
		"hex": "0093DD",
		"source": "https://git.gnupg.org/cgi-bin/gitweb.cgi?p=gnupg.git;a=tree;f=artwork/icons",
		"license": {
			"type": "GPL-3.0-or-later"
		}
	},
	{
		"title": "GNU social",
		"hex": "A22430",
		"source": "https://www.gnu.org/graphics/social.html",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "Go",
		"hex": "00ADD8",
		"source": "https://blog.golang.org/go-brand",
		"guidelines": "https://blog.golang.org/go-brand"
	},
	{
		"title": "GoCD",
		"hex": "94399E",
		"source": "https://www.gocd.org",
		"guidelines": "https://www.gocd.org"
	},
	{
		"title": "GoDaddy",
		"hex": "1BDBDB",
		"source": "https://aboutus.godaddy.net/newsroom/media-resources/",
		"guidelines": "https://aboutus.godaddy.net/newsroom/media-resources/"
	},
	{
		"title": "Godot Engine",
		"hex": "478CBF",
		"source": "https://godotengine.org/press",
		"guidelines": "https://godotengine.org/press",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "GoFundMe",
		"hex": "00B964",
		"source": "https://www.gofundme.com"
	},
	{
		"title": "GOG.com",
		"hex": "86328A",
		"source": "https://www.cdprojekt.com/en/media/logotypes/"
	},
	{
		"title": "Gojek",
		"hex": "00AA13",
		"source": "https://gojek.com",
		"guidelines": "https://gojek.design"
	},
	{
		"title": "GoLand",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/#logos-and-icons-jetbrains-logos",
		"guidelines": "https://www.jetbrains.com/company/brand/#brand-guidelines"
	},
	{
		"title": "GoldenLine",
		"hex": "FFE005",
		"source": "https://www.goldenline.pl"
	},
	{
		"title": "Goldman Sachs",
		"hex": "7399C6",
		"source": "https://design.gs.com/brand/goldman-sachs-logo",
		"guidelines": "https://design.gs.com/brand/goldman-sachs-logo"
	},
	{
		"title": "Goodreads",
		"hex": "372213",
		"source": "https://www.goodreads.com/about/press"
	},
	{
		"title": "Google",
		"hex": "4285F4",
		"source": "https://partnermarketinghub.withgoogle.com",
		"guidelines": "https://about.google/brand-resource-center/brand-elements/",
		"aliases": {
			"loc": {
				"ko-KR": "구글"
			}
		}
	},
	{
		"title": "Google AdMob",
		"hex": "EA4335",
		"source": "https://commons.wikimedia.org/wiki/File:Google_AdMob_logo.svg"
	},
	{
		"title": "Google Ads",
		"hex": "4285F4",
		"source": "https://ads.google.com/home/"
	},
	{
		"title": "Google AdSense",
		"hex": "4285F4",
		"source": "https://www.google.com/adsense/"
	},
	{
		"title": "Google Analytics",
		"hex": "E37400",
		"source": "https://marketingplatform.google.com/intl/en_uk/about/analytics/"
	},
	{
		"title": "Google Apps Script",
		"hex": "4285F4",
		"source": "https://github.com/simple-icons/simple-icons/issues/3556#issuecomment-800482267"
	},
	{
		"title": "Google Assistant",
		"hex": "4285F4",
		"source": "https://assistant.google.com"
	},
	{
		"title": "Google Authenticator",
		"hex": "4285F4",
		"source": "https://commons.wikimedia.org/wiki/File:Google_Authenticator_(April_2023).svg"
	},
	{
		"title": "Google BigQuery",
		"hex": "669DF6",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Bigtable",
		"hex": "669DF6",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Calendar",
		"hex": "4285F4",
		"source": "https://fonts.gstatic.com/s/i/productlogos/calendar_2020q4/v8/192px.svg"
	},
	{
		"title": "Google Campaign Manager 360",
		"hex": "1E8E3E",
		"source": "https://developers.google.com/doubleclick-advertisers"
	},
	{
		"title": "Google Cardboard",
		"hex": "FF7143",
		"source": "https://arvr.google.com/cardboard/images/header/vr-home.svg"
	},
	{
		"title": "Google Chat",
		"hex": "34A853",
		"source": "https://support.google.com/chat/answer/9455386"
	},
	{
		"title": "Google Chrome",
		"hex": "4285F4",
		"source": "https://www.google.com/chrome",
		"guidelines": "https://partnermarketinghub.withgoogle.com/brands/chrome"
	},
	{
		"title": "Google Chronicle",
		"hex": "4285F4",
		"source": "https://chronicle.security"
	},
	{
		"title": "Google Classroom",
		"hex": "0F9D58",
		"source": "https://classroom.google.com"
	},
	{
		"title": "Google Cloud",
		"hex": "4285F4",
		"source": "https://cloud.google.com"
	},
	{
		"title": "Google Cloud Composer",
		"hex": "4285F4",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Cloud Spanner",
		"hex": "4285F4",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Cloud Storage",
		"hex": "AECBFA",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Colab",
		"hex": "F9AB00",
		"source": "https://colab.research.google.com"
	},
	{
		"title": "Google Container Optimized OS",
		"hex": "4285F4",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://cloud.google.com/terms/"
	},
	{
		"title": "Google Data Studio",
		"hex": "669DF6",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Dataflow",
		"hex": "AECBFA",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Dataproc",
		"hex": "AECBFA",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Display & Video 360",
		"hex": "34A853",
		"source": "https://marketingplatform.google.com/about"
	},
	{
		"title": "Google Docs",
		"hex": "4285F4",
		"source": "https://www.google.com/docs/about"
	},
	{
		"title": "Google Drive",
		"hex": "4285F4",
		"source": "https://developers.google.com/drive/web/branding"
	},
	{
		"title": "Google Earth",
		"hex": "4285F4",
		"source": "https://earth.google.com/web/"
	},
	{
		"title": "Google Earth Engine",
		"hex": "4285F4",
		"source": "https://github.com/simple-icons/simple-icons/issues/8912#issuecomment-1638850020"
	},
	{
		"title": "Google Fit",
		"hex": "4285F4",
		"source": "https://partnermarketinghub.withgoogle.com/brands/google-fit/"
	},
	{
		"title": "Google Fonts",
		"hex": "4285F4",
		"source": "https://fonts.google.com"
	},
	{
		"title": "Google Forms",
		"hex": "7248B9",
		"source": "https://about.google/products/#all-products"
	},
	{
		"title": "Google Gemini",
		"hex": "8E75B2",
		"source": "https://gemini.google.com",
		"aliases": {
			"old": [
				"Google Bard"
			]
		}
	},
	{
		"title": "Google Home",
		"hex": "4285F4",
		"source": "https://home.google.com/welcome/"
	},
	{
		"title": "Google Keep",
		"hex": "FFBB00",
		"source": "https://about.google/brand-resource-center/logos-list/"
	},
	{
		"title": "Google Lens",
		"hex": "4285F4",
		"source": "https://lens.google.com"
	},
	{
		"title": "Google Maps",
		"hex": "4285F4",
		"source": "https://commons.wikimedia.org/wiki/File:Google_Maps_icon.svg"
	},
	{
		"title": "Google Marketing Platform",
		"hex": "4285F4",
		"source": "https://about.google/brand-resource-center/logos-list/"
	},
	{
		"title": "Google Meet",
		"hex": "00897B",
		"source": "https://about.google/brand-resource-center/logos-list/"
	},
	{
		"title": "Google Messages",
		"hex": "1A73E8",
		"source": "https://messages.google.com"
	},
	{
		"title": "Google Nearby",
		"hex": "4285F4",
		"source": "https://developers.google.com/nearby/developer-guidelines"
	},
	{
		"title": "Google News",
		"hex": "174EA6",
		"source": "https://partnermarketinghub.withgoogle.com/brands/google-news/",
		"guidelines": "https://partnermarketinghub.withgoogle.com/brands/google-news/legal-and-trademarks/legal-requirements/"
	},
	{
		"title": "Google Pay",
		"hex": "4285F4",
		"source": "https://pay.google.com/intl/en_us/about/"
	},
	{
		"title": "Google Photos",
		"hex": "4285F4",
		"source": "https://partnermarketinghub.withgoogle.com/brands/google-photos/visual-identity/visual-identity/icon/",
		"guidelines": "https://partnermarketinghub.withgoogle.com/brands/google-photos/visual-identity/visual-identity/icon/"
	},
	{
		"title": "Google Play",
		"hex": "414141",
		"source": "https://partnermarketinghub.withgoogle.com/brands/google-play/visual-identity/primary-logos/",
		"guidelines": "https://partnermarketinghub.withgoogle.com/brands/google-play/visual-identity/primary-logos/"
	},
	{
		"title": "Google Pub/Sub",
		"hex": "AECBFA",
		"source": "https://cloud.google.com/icons",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Scholar",
		"hex": "4285F4",
		"source": "https://commons.wikimedia.org/wiki/File:Google_Scholar_logo.svg"
	},
	{
		"title": "Google Search Console",
		"hex": "458CF5",
		"source": "https://search.google.com/search-console"
	},
	{
		"title": "Google Sheets",
		"hex": "34A853",
		"source": "https://sheets.google.com"
	},
	{
		"title": "Google Slides",
		"hex": "FBBC04",
		"source": "https://slides.google.com"
	},
	{
		"title": "Google Street View",
		"hex": "FEC111",
		"source": "https://developers.google.com/streetview/ready/branding",
		"guidelines": "https://developers.google.com/streetview/ready/branding"
	},
	{
		"title": "Google Tag Manager",
		"hex": "246FDB",
		"source": "https://tagmanager.google.com/#/home"
	},
	{
		"title": "Google Tasks",
		"hex": "2684FC",
		"source": "https://assistant.google.com/tasks",
		"guidelines": "https://about.google/brand-resource-center"
	},
	{
		"title": "Google Translate",
		"hex": "4285F4",
		"source": "https://commons.wikimedia.org/wiki/File:Google_Translate_logo.svg"
	},
	{
		"title": "GoToMeeting",
		"hex": "F68D2E",
		"source": "https://www.gotomeeting.com",
		"aliases": {
			"dup": [
				{
					"title": "GoToWebinar",
					"hex": "00C0F3",
					"source": "https://www.gotomeeting.com/en-ie/webinar"
				}
			]
		}
	},
	{
		"title": "Grab",
		"hex": "00B14F",
		"source": "https://en.wikipedia.org/wiki/File:Grab_(application)_logo.svg"
	},
	{
		"title": "Gradio",
		"hex": "F97316",
		"source": "https://www.gradio.app"
	},
	{
		"title": "Gradle",
		"hex": "02303A",
		"source": "https://gradle.com/brand",
		"guidelines": "https://gradle.com/brand"
	},
	{
		"title": "Gradle Play Publisher",
		"hex": "82B816",
		"source": "https://github.com/Triple-T/gradle-play-publisher/blob/df4eadf1ca6b5bad50e21be0b21816722ed50342/assets/logo.svg",
		"license": {
			"type": "MIT"
		},
		"aliases": {
			"aka": [
				"gpp",
				"Triple-T"
			]
		}
	},
	{
		"title": "Grafana",
		"hex": "F46800",
		"source": "https://grafana.com"
	},
	{
		"title": "Grammarly",
		"hex": "027E6F",
		"source": "https://www.grammarly.com/media-assets"
	},
	{
		"title": "Grand Frais",
		"hex": "ED2D2F",
		"source": "https://www.grandfrais.com"
	},
	{
		"title": "GrapheneOS",
		"hex": "0053A3",
		"source": "https://github.com/GrapheneOS/branding-extra/blob/5cc2e4b781345b89457d8ef814bd1aae56af289f/simple.svg",
		"guidelines": "https://github.com/GrapheneOS/branding-extra"
	},
	{
		"title": "Graphite",
		"hex": "000000",
		"source": "https://graphite.dev"
	},
	{
		"title": "GraphQL",
		"hex": "E10098",
		"source": "https://graphql.org/brand",
		"guidelines": "https://graphql.org/brand"
	},
	{
		"title": "Grav",
		"hex": "221E1F",
		"source": "https://getgrav.org/media"
	},
	{
		"title": "Gravatar",
		"hex": "1E8CBE",
		"source": "https://automattic.com/press/brand-materials/"
	},
	{
		"title": "Graylog",
		"hex": "FF3633",
		"source": "https://www.graylog.org"
	},
	{
		"title": "Greasy Fork",
		"hex": "670000",
		"source": "https://github.com/JasonBarnabe/greasyfork/blob/bfeb5f405e03fb32ebc86df7e11c83ca1cb79ddb/misc/logos/logo512.xcf",
		"license": {
			"type": "GPL-3.0-only"
		}
	},
	{
		"title": "Great Learning",
		"hex": "0E39A9",
		"source": "https://www.mygreatlearning.com"
	},
	{
		"title": "Greenhouse",
		"hex": "24A47F",
		"source": "https://brand.greenhouse.io/brand-portal/p/6",
		"guidelines": "https://brand.greenhouse.io/brand-portal/p/5"
	},
	{
		"title": "GreenSock",
		"hex": "88CE02",
		"source": "https://greensock.com"
	},
	{
		"title": "Grid.ai",
		"hex": "78FF96",
		"source": "https://github.com/gridai/logos/blob/1e12c83b77abdc22a41566cab232f4db40223895/GridAI-icons/icon-white-48.svg"
	},
	{
		"title": "Gridsome",
		"hex": "00A672",
		"source": "https://gridsome.org/logo/"
	},
	{
		"title": "Grocy",
		"hex": "337AB7",
		"source": "https://github.com/grocy/grocy/blob/9e1020b7f8994e2d3e3e890da64ceba9903b2fb2/public/img/icon.svg"
	},
	{
		"title": "GroupMe",
		"hex": "00AFF0",
		"source": "https://groupme.com"
	},
	{
		"title": "Groupon",
		"hex": "53A318",
		"source": "https://about.groupon.com/press/",
		"guidelines": "https://about.groupon.com/press/"
	},
	{
		"title": "Grubhub",
		"hex": "F63440",
		"source": "https://www.grubhub.com"
	},
	{
		"title": "Grunt",
		"hex": "FAA918",
		"source": "https://github.com/gruntjs/gruntjs.com/blob/70f43898d9ce8e6cc862ad72bf8a7aee5ca199a9/src/media/grunt-logo-no-wordmark.svg",
		"guidelines": "https://github.com/gruntjs/grunt-docs/blob/main/Grunt-Brand-Guide.md"
	},
	{
		"title": "GSK",
		"hex": "F36633",
		"source": "https://www.gskbrandhub.com",
		"aliases": {
			"aka": [
				"GlaxoSmithKline"
			]
		}
	},
	{
		"title": "GSMArena.com",
		"hex": "D50000",
		"source": "https://www.gsmarena.com"
	},
	{
		"title": "GStreamer",
		"hex": "FF3131",
		"source": "https://gstreamer.freedesktop.org/artwork"
	},
	{
		"title": "GTK",
		"hex": "7FE719",
		"source": "https://commons.wikimedia.org/wiki/File:GTK_logo.svg",
		"guidelines": "https://foundation.gnome.org/logo-and-trademarks",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "Guangzhou Metro",
		"hex": "C51935",
		"source": "https://commons.wikimedia.org/wiki/File:Guangzhou_Metro_logo.svg"
	},
	{
		"title": "Guilded",
		"hex": "F5C400",
		"source": "https://www.guilded.gg/brand",
		"guidelines": "https://www.guilded.gg/brand"
	},
	{
		"title": "Guitar Pro",
		"hex": "569FFF",
		"source": "https://www.guitar-pro.com/c/12-visual-resources",
		"guidelines": "https://www.guitar-pro.com/c/12-visual-resources"
	},
	{
		"title": "gulp",
		"hex": "CF4647",
		"source": "https://github.com/gulpjs/artwork/blob/4e14158817ac88e9a5c02b3b307e6f630fe222fb/gulp-white-text.svg",
		"guidelines": "https://github.com/gulpjs/artwork",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "Gumroad",
		"hex": "FF90E8",
		"source": "https://gumroad.com"
	},
	{
		"title": "Gumtree",
		"hex": "72EF36",
		"source": "https://www.gumtree.com"
	},
	{
		"title": "Gunicorn",
		"hex": "499848",
		"source": "https://github.com/benoitc/gunicorn/blob/ff58e0c6da83d5520916bc4cc109a529258d76e1/docs/logo/gunicorn.svg"
	},
	{
		"title": "Gurobi",
		"hex": "EE3524",
		"source": "https://cdn.gurobi.com/wp-content/uploads/2021/02/Gurobi-Optimization_Corporate-Brochure.pdf"
	},
	{
		"title": "Gusto",
		"hex": "F45D48",
		"source": "https://gusto.com"
	},
	{
		"title": "Gutenberg",
		"hex": "000000",
		"source": "https://github.com/WordPress/gutenberg/blob/7829913ae117dfb561d14c600eea7b281afd6556/docs/final-g-wapuu-black.svg"
	},
	{
		"title": "H&M",
		"hex": "E50010",
		"source": "https://www2.hm.com/en_gb/index.html"
	},
	{
		"title": "H2 Database",
		"hex": "09476B",
		"source": "https://github.com/h2database/h2database/blob/4472d76fc6a77cb079a8a0c24d80dc05dade56e1/h2/src/docsrc/images/h2_v2_3_7.svg"
	},
	{
		"title": "H3",
		"hex": "1E54B7",
		"source": "https://github.com/uber/h3/blob/71e09dc002b211887c6db525609a449058233a71/website/static/images/h3Logo-color.svg"
	},
	{
		"title": "Habr",
		"hex": "65A3BE",
		"source": "https://kiosk.habr.com"
	},
	{
		"title": "Hack Club",
		"hex": "EC3750",
		"source": "https://hackclub.com/brand",
		"guidelines": "https://hackclub.com/brand"
	},
	{
		"title": "Hack The Box",
		"hex": "9FEF00",
		"source": "https://www.hackthebox.com/contact-us",
		"guidelines": "https://www.hackthebox.com/contact-us"
	},
	{
		"title": "Hackaday",
		"hex": "1A1A1A",
		"source": "https://hackaday.com"
	},
	{
		"title": "Hacker Noon",
		"hex": "00FE00",
		"source": "https://sponsor.hackernoon.com/#brandasauthor"
	},
	{
		"title": "HackerEarth",
		"hex": "2C3454",
		"source": "https://www.hackerearth.com/logo/"
	},
	{
		"title": "HackerOne",
		"hex": "494649",
		"source": "https://www.hackerone.com/branding",
		"guidelines": "https://www.hackerone.com/branding/pages#logo_usage"
	},
	{
		"title": "HackerRank",
		"hex": "00EA64",
		"source": "https://www.hackerrank.com/about-us/"
	},
	{
		"title": "Hackster",
		"hex": "2E9FE6",
		"source": "https://www.hackster.io/branding#logos",
		"guidelines": "https://www.hackster.io/branding"
	},
	{
		"title": "HAL",
		"hex": "B03532",
		"source": "https://www.ccsd.cnrs.fr/en/brand-guidelines",
		"guidelines": "https://www.ccsd.cnrs.fr/en/brand-guidelines/"
	},
	{
		"title": "Handlebars.js",
		"hex": "000000",
		"source": "https://github.com/handlebars-lang/docs/blob/13a2e2d9e31ebff4295924ea366abf3062e47ede/src/.vuepress/public/icons/handlebarsjs-icon.svg"
	},
	{
		"title": "Handshake",
		"hex": "D3FB52",
		"source": "https://joinhandshake.com/career-centers/marketing-toolkit",
		"guidelines": "https://joinhandshake.com/career-centers/marketing-toolkit"
	},
	{
		"title": "Handshake",
		"slug": "handshake_protocol",
		"hex": "000000",
		"source": "https://handshake.org"
	},
	{
		"title": "HappyCow",
		"hex": "7C4EC4",
		"source": "https://www.happycow.net/press-kits"
	},
	{
		"title": "Harbor",
		"hex": "60B932",
		"source": "https://github.com/cncf/artwork/blob/ff2b2b5216e22f001ddd444ca580c484dd10302e/projects/harbor/icon/black/harbor-icon-black.svg",
		"guidelines": "https://github.com/cncf/artwork/blob/ff2b2b5216e22f001ddd444ca580c484dd10302e/README.md",
		"license": {
			"type": "custom",
			"url": "https://www.linuxfoundation.org/legal/trademark-usage"
		}
	},
	{
		"title": "HarmonyOS",
		"hex": "000000",
		"source": "https://www.harmonyos.com",
		"aliases": {
			"aka": [
				"HMOS"
			]
		}
	},
	{
		"title": "HashiCorp",
		"hex": "000000",
		"source": "https://www.hashicorp.com",
		"guidelines": "https://www.hashicorp.com/brand"
	},
	{
		"title": "Hashnode",
		"hex": "2962FF",
		"source": "https://hashnode.com/media"
	},
	{
		"title": "Haskell",
		"hex": "5D4F85",
		"source": "https://wiki.haskell.org/Thompson-Wheeler_logo"
	},
	{
		"title": "Hasura",
		"hex": "1EB4D4",
		"source": "https://github.com/hasura/graphql-engine/blob/5e2f5d470cdc2a7e59db7a3d5e94475a00bb2ac6/docs/static/img/logo.svg"
	},
	{
		"title": "Hatena Bookmark",
		"hex": "00A4DE",
		"source": "https://hatenacorp.jp/press/resource"
	},
	{
		"title": "Have I Been Pwned",
		"hex": "2A6379",
		"source": "https://haveibeenpwned.com"
	},
	{
		"title": "Haxe",
		"hex": "EA8220",
		"source": "https://haxe.org/foundation/branding.html",
		"guidelines": "https://haxe.org/foundation/branding.html"
	},
	{
		"title": "HBO",
		"hex": "000000",
		"source": "https://www.hbo.com"
	},
	{
		"title": "HCL",
		"hex": "006BB6",
		"source": "https://www.hcl.com/brand-guidelines",
		"guidelines": "https://www.hcl.com/brand-guidelines"
	},
	{
		"title": "HDFC Bank",
		"hex": "004B8D",
		"source": "https://www.hdfcsales.com",
		"aliases": {
			"aka": [
				"HDB"
			]
		}
	},
	{
		"title": "Headless UI",
		"hex": "66E3FF",
		"source": "https://headlessui.dev"
	},
	{
		"title": "Headphone Zone",
		"hex": "3C07FF",
		"source": "https://www.headphonezone.in"
	},
	{
		"title": "Headspace",
		"hex": "F47D31",
		"source": "https://www.headspace.com/press-and-media"
	},
	{
		"title": "Hearth",
		"hex": "A33035",
		"source": "https://www.gethearth.com"
	},
	{
		"title": "hearthis.at",
		"hex": "000000",
		"source": "https://hearthis.at"
	},
	{
		"title": "Hedera",
		"hex": "222222",
		"source": "https://brand.hedera.com",
		"guidelines": "https://brand.hedera.com"
	},
	{
		"title": "Helium",
		"hex": "0ACF83",
		"source": "https://www.helium.com"
	},
	{
		"title": "Helix",
		"hex": "281733",
		"source": "https://helix-editor.com"
	},
	{
		"title": "HelloFresh",
		"hex": "99CC33",
		"source": "https://www.hellofreshgroup.com/en/newsroom/press-material/brand"
	},
	{
		"title": "Helly Hansen",
		"hex": "DA2128",
		"source": "https://www.hellyhansen.com"
	},
	{
		"title": "Helm",
		"hex": "0F1689",
		"source": "https://helm.sh"
	},
	{
		"title": "Help Scout",
		"hex": "1292EE",
		"source": "https://www.helpscout.com"
	},
	{
		"title": "HelpDesk",
		"hex": "2FC774",
		"source": "https://helpdesk.design",
		"guidelines": "https://helpdesk.design"
	},
	{
		"title": "Hepsiemlak",
		"hex": "E1251B",
		"source": "https://www.hepsiemlak.com"
	},
	{
		"title": "HERE",
		"hex": "00AFAA",
		"source": "https://www.here.com/company/media-assets"
	},
	{
		"title": "Hermes",
		"hex": "0091CD",
		"source": "https://www.myhermes.de/assets/touchicons/favicon.svg"
	},
	{
		"title": "Heroku",
		"hex": "430098",
		"source": "https://devcenter.heroku.com/articles/heroku-brand-guidelines#logos",
		"guidelines": "https://devcenter.heroku.com/articles/heroku-brand-guidelines"
	},
	{
		"title": "Hetzner",
		"hex": "D50C2D",
		"source": "https://www.hetzner.com"
	},
	{
		"title": "Hevy",
		"hex": "000000",
		"source": "https://www.hevyapp.com"
	},
	{
		"title": "Hexlet",
		"hex": "116EF5",
		"source": "https://hexlet.io",
		"aliases": {
			"loc": {
				"ru-RU": "Хекслет"
			}
		}
	},
	{
		"title": "Hexo",
		"hex": "0E83CD",
		"source": "https://hexo.io"
	},
	{
		"title": "HEY",
		"hex": "5522FA",
		"source": "https://hey.com"
	},
	{
		"title": "Hi Bob",
		"hex": "E42C51",
		"source": "https://www.hibob.com",
		"aliases": {
			"aka": [
				"Bob"
			]
		}
	},
	{
		"title": "Hibernate",
		"hex": "59666C",
		"source": "https://hibernate.org"
	},
	{
		"title": "Hilton",
		"hex": "231F20",
		"source": "https://www.hilton.com",
		"guidelines": "https://stories.hilton.com/media-kit-hilton-corporate"
	},
	{
		"title": "Hilton Hotels & Resorts",
		"hex": "1E4380",
		"source": "https://www.hilton.com/en/brands/hilton-hotels"
	},
	{
		"title": "Hitachi",
		"hex": "E60027",
		"source": "https://commons.wikimedia.org/wiki/File:Hitachi_inspire_the_next-Logo.svg"
	},
	{
		"title": "Hive",
		"hex": "FF7A00",
		"source": "https://www.hivehome.com"
	},
	{
		"title": "Hive",
		"slug": "hive_blockchain",
		"hex": "E31337",
		"source": "https://hive.io/brand"
	},
	{
		"title": "HiveMQ",
		"hex": "FFC000",
		"source": "https://www.hivemq.com",
		"guidelines": "https://www.hivemq.com/company/hivemq-brand-resources"
	},
	{
		"title": "Homarr",
		"hex": "FA5252",
		"source": "https://github.com/ajnart/homarr/blob/2bf423132d9077d371d254e577fc57037a31ac4b/public/imgs/favicon/favicon.svg"
	},
	{
		"title": "Home Assistant",
		"hex": "18BCF2",
		"source": "https://github.com/home-assistant/assets/blob/0f69676da79c3881e7dfca6d6c0a5739f88273d8/logo/home-assistant-logo.zip",
		"guidelines": "https://design.home-assistant.io/#brand/logo"
	},
	{
		"title": "Home Assistant Community Store",
		"hex": "41BDF5",
		"source": "https://hacs.xyz"
	},
	{
		"title": "HomeAdvisor",
		"hex": "F68315",
		"source": "https://www.homeadvisor.com"
	},
	{
		"title": "Homebrew",
		"hex": "FBB040",
		"source": "https://github.com/Homebrew/brew.sh/blob/2e576aaca83e62dda41a188597bb4bd20e75e385/assets/img/homebrew.svg"
	},
	{
		"title": "Homebridge",
		"hex": "491F59",
		"source": "https://github.com/homebridge/branding/blob/6ef3a1685e79f79a2ecdcc83824e53775ec0475d/logos/homebridge-silhouette-round-black.svg"
	},
	{
		"title": "Homepage",
		"hex": "009BD5",
		"source": "https://github.com/gethomepage/homepage/blob/e56dccc7f17144a53b97a315c2e4f622fa07e58d/public/safari-pinned-tab.svg"
	},
	{
		"title": "homify",
		"hex": "7DCDA3",
		"source": "https://www.homify.com"
	},
	{
		"title": "Honda",
		"hex": "E40521",
		"source": "https://www.honda.ie"
	},
	{
		"title": "Honey",
		"hex": "FF6801",
		"source": "https://www.joinhoney.com"
	},
	{
		"title": "Honeybadger",
		"hex": "EA5937",
		"source": "https://www.honeybadger.io/assets"
	},
	{
		"title": "Honeygain",
		"hex": "F9C900",
		"source": "https://www.honeygain.com",
		"guidelines": "https://www.honeygain.com/brand-assets"
	},
	{
		"title": "Hono",
		"hex": "E36002",
		"source": "https://github.com/honojs/hono/blob/76dbc74407329c46870af6aa4fab0c04036d8ae2/docs/images/hono-logo.svg"
	},
	{
		"title": "Honor",
		"hex": "000000",
		"source": "https://www.hihonor.com",
		"guidelines": "https://www.hihonor.com/global/brand-guideline11/basics/logo"
	},
	{
		"title": "Hootsuite",
		"hex": "FF4C46",
		"source": "https://hootsuite.widencollective.com/portals/bafpk5oo/bafpk5oo/MediaKitAssets/c/b9e3a7bb-aca7-48d7-90ed-cff5898aafd0",
		"guidelines": "https://hootsuite.widencollective.com/portals/bafpk5oo/MediaKitAssets"
	},
	{
		"title": "Hoppscotch",
		"hex": "09090B",
		"source": "https://hoppscotch.com"
	},
	{
		"title": "Hostinger",
		"hex": "673DE6",
		"source": "https://www.hostinger.com/newsroom",
		"guidelines": "https://www.hostinger.com/newsroom"
	},
	{
		"title": "Hotels.com",
		"hex": "EF3346",
		"source": "https://www.hotels.com"
	},
	{
		"title": "Hotjar",
		"hex": "FF3C00",
		"source": "https://www.hotjar.com"
	},
	{
		"title": "Hotwire",
		"hex": "FFE801",
		"source": "https://hotwired.dev"
	},
	{
		"title": "Houdini",
		"hex": "FF4713",
		"source": "https://www.sidefx.com/products/houdini/"
	},
	{
		"title": "Houzz",
		"hex": "4DBC15",
		"source": "https://www.houzz.com/logoGuidelines",
		"guidelines": "https://www.houzz.com/logoGuidelines"
	},
	{
		"title": "HP",
		"hex": "0096D6",
		"source": "https://brandcentral.hp.com/us/en/elements/hp-logo.html",
		"guidelines": "https://brandcentral.hp.com/us/en/elements/hp-logo.html"
	},
	{
		"title": "HSBC",
		"hex": "DB0011",
		"source": "https://www.hsbc.com",
		"guidelines": "https://www.hsbc.com/terms-and-conditions"
	},
	{
		"title": "HTC",
		"hex": "A5CF4C",
		"source": "https://htc.com"
	},
	{
		"title": "HTC Vive",
		"hex": "00B2E3",
		"source": "https://www.vive.com"
	},
	{
		"title": "HTML Academy",
		"hex": "302683",
		"source": "https://htmlacademy.ru"
	},
	{
		"title": "HTML5",
		"hex": "E34F26",
		"source": "https://www.w3.org/html/logo/"
	},
	{
		"title": "htmx",
		"hex": "3366CC",
		"source": "https://github.com/bigskysoftware/htmx/blob/f690d928342b6334fa539cfbd4be515748d2ba0f/www/static/img/htmx_logo.2.png"
	},
	{
		"title": "htop",
		"hex": "009020",
		"source": "https://github.com/htop-dev/htop/blob/03d5e4746f53bd07daf68638d714a7fec336297b/htop.svg"
	},
	{
		"title": "HTTPie",
		"hex": "73DC8C",
		"source": "https://github.com/httpie/httpie/blob/d262181bede5241a6b692c3245a77e2eb02bc262/docs/httpie-logo.svg"
	},
	{
		"title": "Huawei",
		"hex": "FF0000",
		"source": "https://e.huawei.com/ph/material/partner/0a72728b864949c48b22106454352483",
		"guidelines": "https://e.huawei.com/ph/material/partner/0a72728b864949c48b22106454352483"
	},
	{
		"title": "HubSpot",
		"hex": "FF7A59",
		"source": "https://www.hubspot.com/style-guide",
		"guidelines": "https://www.hubspot.com/style-guide"
	},
	{
		"title": "Hugging Face",
		"hex": "FFD21E",
		"source": "https://huggingface.co/brand",
		"guidelines": "https://huggingface.co/brand"
	},
	{
		"title": "Hugo",
		"hex": "FF4088",
		"source": "https://gohugo.io"
	},
	{
		"title": "Humble Bundle",
		"hex": "CC2929",
		"source": "https://support.humblebundle.com/hc/en-us/articles/202742060-Bundle-Logos"
	},
	{
		"title": "HumHub",
		"hex": "1B8291",
		"source": "https://github.com/humhub/documentation/blob/e7844d7373ddf351cc7603fe9b7449009fa7c3b0/static/img/logo.svg"
	},
	{
		"title": "Hungry Jack's",
		"hex": "D0021B",
		"source": "https://www.hungryjacks.com.au"
	},
	{
		"title": "Husqvarna",
		"hex": "273A60",
		"source": "https://www.husqvarna.com"
	},
	{
		"title": "Hyper",
		"hex": "000000",
		"source": "https://hyper.is"
	},
	{
		"title": "Hyperskill",
		"hex": "8C5AFF",
		"source": "https://hyperskill.org"
	},
	{
		"title": "HyperX",
		"hex": "E21836",
		"source": "https://ca.hyperx.com/cdn/shop/files/image_placeholder.svg"
	},
	{
		"title": "Hypothesis",
		"hex": "BD1C2B",
		"source": "https://web.hypothes.is/brand/"
	},
	{
		"title": "Hyprland",
		"hex": "58E1FF",
		"source": "https://hyprland.org"
	},
	{
		"title": "Hyundai",
		"hex": "002C5E",
		"source": "https://www.hyundai.com"
	},
	{
		"title": "i18next",
		"hex": "26A69A",
		"source": "https://github.com/i18next/i18next-gitbook/blob/32efcfd9c59ae55cc63a60e633dbc1651c7950ad/assets/img/logo.svg"
	},
	{
		"title": "i3",
		"hex": "52C0FF",
		"source": "https://github.com/i3/i3/blob/d6e2a38b5cdf200c0fb82fc4cf7fff7dbcdeb605/logo.svg"
	},
	{
		"title": "IATA",
		"hex": "004E81",
		"source": "https://commons.wikimedia.org/wiki/File:IATAlogo.svg"
	},
	{
		"title": "iBeacon",
		"hex": "3D7EBB",
		"source": "https://developer.apple.com/ibeacon/"
	},
	{
		"title": "Iberia",
		"hex": "D7192D",
		"source": "https://iberia.com"
	},
	{
		"title": "Iced",
		"hex": "3645FF",
		"source": "https://iced.rs"
	},
	{
		"title": "Iceland",
		"hex": "CC092F",
		"source": "https://www.iceland.co.uk"
	},
	{
		"title": "ICICI Bank",
		"hex": "AE282E",
		"source": "https://www.icicibank.com/ms/aboutus/annual-reports/2022-23/icici/assets/images/home-page/logo.svg"
	},
	{
		"title": "Icinga",
		"hex": "06062C",
		"source": "https://github.com/Icinga/icingaweb2/blob/293021b2000e9d459387153ca5690f97e0184aaa/public/img/icinga-logo-compact.svg"
	},
	{
		"title": "iCloud",
		"hex": "3693F3",
		"source": "https://commons.wikimedia.org/wiki/File:ICloud_logo.svg"
	},
	{
		"title": "IcoMoon",
		"hex": "825794",
		"source": "https://icomoon.io"
	},
	{
		"title": "ICON",
		"hex": "31B8BB",
		"source": "https://icon.foundation/contents/resrce/media"
	},
	{
		"title": "Iconfinder",
		"hex": "1A1B1F",
		"source": "https://www.iconfinder.com/p/about"
	},
	{
		"title": "Iconify",
		"hex": "1769AA",
		"source": "https://iconify.design"
	},
	{
		"title": "IconJar",
		"hex": "16A5F3",
		"source": "https://geticonjar.com"
	},
	{
		"title": "Icons8",
		"hex": "1FB141",
		"source": "https://icons8.com"
	},
	{
		"title": "ICQ",
		"hex": "24FF00",
		"source": "https://commons.wikimedia.org/wiki/File:ICQNewlogo.svg"
	},
	{
		"title": "IEEE",
		"hex": "00629B",
		"source": "https://brand-experience.ieee.org/templates-tools-resources/resources/master-brand-and-logos/",
		"guidelines": "https://brand-experience.ieee.org/guidelines/brand-identity/"
	},
	{
		"title": "iFixit",
		"hex": "0071CE",
		"source": "https://www.ifixit.com",
		"guidelines": "https://www.ifixit.com/Info/Media"
	},
	{
		"title": "iFood",
		"hex": "EA1D2C",
		"source": "https://ifood.com.br"
	},
	{
		"title": "IFTTT",
		"hex": "000000",
		"source": "https://ifttt.com/discover/brand-guidelines",
		"guidelines": "https://ifttt.com/discover/brand-guidelines"
	},
	{
		"title": "IGDB",
		"hex": "9147FF",
		"source": "https://commons.wikimedia.org/wiki/File:IGDB_logo.svg"
	},
	{
		"title": "IGN",
		"hex": "BF1313",
		"source": "https://www.ign.com"
	},
	{
		"title": "iHeartRadio",
		"hex": "C6002B",
		"source": "https://brand.iheart.com/logo",
		"guidelines": "https://brand.iheart.com/logo"
	},
	{
		"title": "IKEA",
		"hex": "0058A3",
		"source": "https://www.ikea.com"
	},
	{
		"title": "Île-de-France Mobilités",
		"hex": "67B4E7",
		"source": "https://www.iledefrance-mobilites.fr"
	},
	{
		"title": "Image.sc",
		"hex": "039CB2",
		"source": "https://forum.image.sc"
	},
	{
		"title": "ImageJ",
		"hex": "00D8E0",
		"source": "https://github.com/imagej/imagej/blob/0667395bcac20e5d7a371ac9f468522c74367d59/logo/inkscape_image_logo_src.svg"
	},
	{
		"title": "IMDb",
		"hex": "F5C518",
		"source": "https://brand.imdb.com/imdb",
		"guidelines": "https://brand.imdb.com/imdb"
	},
	{
		"title": "iMessage",
		"hex": "34DA50",
		"source": "https://commons.wikimedia.org/wiki/File:IMessage_logo.svg"
	},
	{
		"title": "Imgur",
		"hex": "1BB76E",
		"source": "https://imgurinc.com/press",
		"guidelines": "https://help.imgur.com/hc/en-us/articles/202062878-Trademark-Use-Policy"
	},
	{
		"title": "Immer",
		"hex": "00E7C3",
		"source": "https://github.com/immerjs/immer/blob/7a5382899bc8b0bf5e21972a1c7db63f53e1d697/website/static/img/immer-logo.svg"
	},
	{
		"title": "Immich",
		"hex": "4250AF",
		"source": "https://github.com/immich-app/immich/blob/25c9b779e4d19bc34551f8b137266a459e0d70e1/design/immich-logo.svg"
	},
	{
		"title": "Imou",
		"hex": "E89313",
		"source": "https://www.imoulife.com/support/download/userManual"
	},
	{
		"title": "ImprovMX",
		"hex": "2FBEFF",
		"source": "https://improvmx.com"
	},
	{
		"title": "Indeed",
		"hex": "003A9B",
		"source": "https://indeed.design/resources"
	},
	{
		"title": "Indian Super League",
		"hex": "ED2F21",
		"source": "https://indiansuperleague.com"
	},
	{
		"title": "Indie Hackers",
		"hex": "0E2439",
		"source": "https://www.indiehackers.com"
	},
	{
		"title": "IndiGo",
		"hex": "09009B",
		"source": "https://www.goindigo.in"
	},
	{
		"title": "Inductive Automation",
		"hex": "445C6D",
		"source": "https://brand.inductiveautomation.com",
		"guidelines": "https://brand.inductiveautomation.com"
	},
	{
		"title": "Inertia",
		"hex": "9553E9",
		"source": "https://inertiajs.com"
	},
	{
		"title": "INFINITI",
		"hex": "020B24",
		"source": "https://www.infiniti.com"
	},
	{
		"title": "InfluxDB",
		"hex": "22ADF6",
		"source": "https://influxdata.github.io/branding/logo/downloads/",
		"guidelines": "https://influxdata.github.io/branding/logo/usage/"
	},
	{
		"title": "Infomaniak",
		"hex": "0098FF",
		"source": "https://www.infomaniak.com/en/about/press"
	},
	{
		"title": "InfoQ",
		"hex": "2C6CAF",
		"source": "https://www.infoq.com"
	},
	{
		"title": "Informatica",
		"hex": "FF4D00",
		"source": "https://www.informatica.com"
	},
	{
		"title": "Infosys",
		"hex": "007CC3",
		"source": "https://www.infosys.com/newsroom/journalist-resources/infosyslogo.html"
	},
	{
		"title": "Infracost",
		"hex": "DB44B8",
		"source": "https://www.infracost.io/img/logo.svg"
	},
	{
		"title": "Ingress",
		"hex": "783CBD",
		"source": "https://ingress.com",
		"guidelines": "https://niantic.helpshift.com/a/ingress/?s=ingress-events&f=brand-and-fan-site-guidelines&p=web"
	},
	{
		"title": "Inkdrop",
		"hex": "7A78D7",
		"source": "https://site-cdn.inkdrop.app/site/icons/inkdrop-icon.svg"
	},
	{
		"title": "Inkscape",
		"hex": "000000",
		"source": "https://inkscape.org/gallery/=inkscape-branding/inkscape-brand-assets/",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "Inoreader",
		"hex": "1875F3",
		"source": "https://www.inoreader.com/brand-portal",
		"guidelines": "https://www.inoreader.com/brand-portal"
	},
	{
		"title": "Insomnia",
		"hex": "4000BF",
		"source": "https://insomnia.rest"
	},
	{
		"title": "INSPIRE",
		"hex": "00E5FF",
		"source": "https://inspirehep.net"
	},
	{
		"title": "Insta360",
		"hex": "FFEE00",
		"source": "https://www.insta360.com/press/logo",
		"guidelines": "https://www.insta360.com/press/logo"
	},
	{
		"title": "Instacart",
		"hex": "43B02A",
		"source": "https://www.instacart.com/press"
	},
	{
		"title": "Instagram",
		"hex": "FF0069",
		"source": "https://about.meta.com/brand/resources/instagram",
		"guidelines": "https://about.meta.com/brand/resources/instagram"
	},
	{
		"title": "Instapaper",
		"hex": "1F1F1F",
		"source": "https://www.instapaper.com"
	},
	{
		"title": "Instatus",
		"hex": "4EE3C2",
		"source": "https://www.instatus.com"
	},
	{
		"title": "Instructables",
		"hex": "FABF15",
		"source": "https://www.instructables.com/community/Official-Instructables-Logos-1/"
	},
	{
		"title": "Instructure",
		"hex": "2A7BA0",
		"source": "https://www.instructure.com/about/brand-guide/download-logos",
		"guidelines": "https://www.instructure.com/canvas/resources/noram-guides/instructure-brand-guide-2022"
	},
	{
		"title": "Intel",
		"hex": "0071C5",
		"source": "https://www.intel.com/content/www/us/en/newsroom/resources/press-kits-intel-overview.html"
	},
	{
		"title": "IntelliJ IDEA",
		"hex": "000000",
		"source": "https://www.jetbrains.com/idea/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "Interaction Design Foundation",
		"hex": "2B2B2B",
		"source": "https://www.interaction-design.org"
	},
	{
		"title": "InteractJS",
		"hex": "2599ED",
		"source": "https://github.com/taye/interact.js/blob/603c34d4b34dece8a260381e2e5991b810d6d739/img/ijs-icon.svg"
	},
	{
		"title": "Interbase",
		"hex": "E62431",
		"source": "https://www.embarcadero.com/news/logo",
		"guidelines": "https://www.ideracorp.com/legal/embarcadero"
	},
	{
		"title": "Intercom",
		"hex": "6AFDEF",
		"source": "https://www.intercom.com/press",
		"guidelines": "https://www.intercom.com/press"
	},
	{
		"title": "Intermarche",
		"hex": "E2001A",
		"source": "https://www.intermarche.com"
	},
	{
		"title": "Internet Archive",
		"hex": "666666",
		"source": "https://archive.org"
	},
	{
		"title": "Internet Computer",
		"hex": "3B00B9",
		"source": "https://dfinity.frontify.com/d/pD7yZhsmpqos/internet-computer#/internet-computer/logo",
		"guidelines": "https://dfinity.frontify.com/d/pD7yZhsmpqos",
		"aliases": {
			"aka": [
				"Internet Computer Protocol"
			]
		}
	},
	{
		"title": "Intigriti",
		"hex": "161A36",
		"source": "https://www.intigriti.com"
	},
	{
		"title": "Intuit",
		"hex": "236CFF",
		"source": "https://www.intuit.com",
		"guidelines": "https://www.intuit.com/company/press-room/logos"
	},
	{
		"title": "InVision",
		"hex": "FF3366",
		"source": "https://www.invisionapp.com/resources/brand",
		"guidelines": "https://www.invisionapp.com/resources/brand"
	},
	{
		"title": "Invoice Ninja",
		"hex": "000000",
		"source": "https://github.com/invoiceninja/invoiceninja/blob/2bdb26dd06123a0426cc7a8da77fc8fce7e5a222/public/images/round_logo.png"
	},
	{
		"title": "ioBroker",
		"hex": "3399CC",
		"source": "https://github.com/ioBroker/awesome-iobroker/blob/6ba42e9fcda7c88356e2f8c98f435ce7b02d4e37/images/awesome-iobroker.svg"
	},
	{
		"title": "Ionic",
		"hex": "3880FF",
		"source": "https://ionicframework.com/press"
	},
	{
		"title": "Ionos",
		"hex": "003D8F",
		"source": "https://www.ionos.de"
	},
	{
		"title": "iOS",
		"hex": "000000",
		"source": "https://en.wikipedia.org/wiki/IOS"
	},
	{
		"title": "IOTA",
		"hex": "131F37",
		"source": "https://www.iota.org/connect/brand",
		"guidelines": "https://www.iota.org/connect/brand",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "IPFS",
		"hex": "65C2CB",
		"source": "https://github.com/ipfs-inactive/logo/tree/73169b495332415b174ac2f37ec27c4b2ee8da83",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "IRIS",
		"hex": "25313C",
		"source": "https://www.iris.co.uk"
	},
	{
		"title": "iRobot",
		"hex": "6CB86A",
		"source": "https://www.irobot.com"
	},
	{
		"title": "ISC2",
		"hex": "468145",
		"source": "https://www.isc2.org",
		"aliases": {
			"aka": [
				"(ISC)²"
			]
		}
	},
	{
		"title": "Issuu",
		"hex": "F36D5D",
		"source": "https://issuu.com/press",
		"guidelines": "https://issuu.com/press"
	},
	{
		"title": "Istio",
		"hex": "466BB0",
		"source": "https://github.com/istio/istio/blob/5a047251817eb2523af297607b7614120812e47a/logo/istio-bluelogo-whitebackground-unframed.svg"
	},
	{
		"title": "Itch.io",
		"hex": "FA5C5C",
		"source": "https://itch.io/press-kit",
		"guidelines": "https://itch.io/press-kit"
	},
	{
		"title": "iTerm2",
		"hex": "000000",
		"source": "https://github.com/gnachman/iTerm2/blob/6a857f3f5872eb1465ddc0dd83412015991e79ae/images/AppIcon/iTermIcon.sketch"
	},
	{
		"title": "iTunes",
		"hex": "FB5BC5",
		"source": "https://commons.wikimedia.org/wiki/File:ITunes_logo.svg"
	},
	{
		"title": "ITVx",
		"hex": "DEEB52",
		"source": "https://www.itvmedia.co.uk"
	},
	{
		"title": "IVECO",
		"hex": "1554FF",
		"source": "https://www.iveco.com/global/welcome"
	},
	{
		"title": "Jabber",
		"hex": "CC0000",
		"source": "https://commons.wikimedia.org/wiki/File:Jabber-bulb.svg",
		"guidelines": "https://www.jabber.org/faq.html#logo",
		"license": {
			"type": "CC-BY-2.5"
		}
	},
	{
		"title": "Jaeger",
		"hex": "66CFE3",
		"source": "https://github.com/cncf/artwork/blob/e7e09686c20db6ddac06e482cf3338b0c8b2e22d/projects/jaeger/icon/black/jaeger-icon-black.svg",
		"guidelines": "https://github.com/cncf/artwork/blob/e7e09686c20db6ddac06e482cf3338b0c8b2e22d/projects/jaeger/jaeger-logo-guide.pdf"
	},
	{
		"title": "Jaguar",
		"hex": "FFFFFF",
		"source": "https://media.jaguar.com/en/press-kit"
	},
	{
		"title": "Jamboard",
		"hex": "F37C20",
		"source": "https://cdn2.hubspot.net/hubfs/159104/ECS/Jamboard/Approved%20Jamboard%20Brand%20Book.pdf",
		"guidelines": "https://cdn2.hubspot.net/hubfs/159104/ECS/Jamboard/Approved%20Jamboard%20Brand%20Book.pdf"
	},
	{
		"title": "Jameson",
		"hex": "004027",
		"source": "https://www.jamesonwhiskey.com"
	},
	{
		"title": "Jamstack",
		"hex": "F0047F",
		"source": "https://github.com/jamstack/jamstack.org/blob/a7de230798f98bdde78f0a0eeb5ebfc488c563aa/src/site/img/logo/svg/Jamstack_Icon_Original.svg"
	},
	{
		"title": "Japan Airlines",
		"hex": "C00000",
		"source": "https://www.jal.co.jp"
	},
	{
		"title": "Jasmine",
		"hex": "8A4182",
		"source": "https://github.com/jasmine/jasmine/blob/8991b1bba39b5b7e89fc5eeb07ae271a684cb1a4/images/jasmine-horizontal.svg"
	},
	{
		"title": "JavaScript",
		"hex": "F7DF1E",
		"source": "https://github.com/voodootikigod/logo.js/blob/1544bdeed6d618a6cfe4f0650d04ab8d9cfa76d9/js.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "JBL",
		"hex": "FF3300",
		"source": "https://www.jbl.com"
	},
	{
		"title": "JCB",
		"hex": "0B4EA2",
		"source": "https://www.global.jcb/en/about-us/brand-concept/"
	},
	{
		"title": "Jeep",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:Jeep_logo.svg"
	},
	{
		"title": "Jekyll",
		"hex": "CC0000",
		"source": "https://github.com/jekyll/brand/blob/8302ad3ecf045054a095020729a8d2cc7005faf8/jekyll-logo-black.svg",
		"guidelines": "https://github.com/jekyll/brand",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "Jellyfin",
		"hex": "00A4DC",
		"source": "https://jellyfin.org/docs/general/contributing/branding.html",
		"guidelines": "https://jellyfin.org/docs/general/contributing/branding.html"
	},
	{
		"title": "Jenkins",
		"hex": "D24939",
		"source": "https://get.jenkins.io/art/",
		"guidelines": "https://www.jenkins.io/press/",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "Jest",
		"hex": "C21325",
		"source": "https://jestjs.io"
	},
	{
		"title": "JET",
		"hex": "FBBA00",
		"source": "https://de.wikipedia.org/wiki/Datei:JET.svg"
	},
	{
		"title": "JetBlue",
		"hex": "001E59",
		"source": "https://www.jetblue.com"
	},
	{
		"title": "JetBrains",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "Jetpack Compose",
		"hex": "4285F4",
		"source": "https://developer.android.com/jetpack/compose/"
	},
	{
		"title": "JFrog",
		"hex": "40BE46",
		"source": "https://jfrog.com/brand-guidelines",
		"guidelines": "https://jfrog.com/brand-guidelines"
	},
	{
		"title": "JFrog Pipelines",
		"hex": "40BE46",
		"source": "https://jfrog.com/pipelines/",
		"guidelines": "https://jfrog.com/brand-guidelines/"
	},
	{
		"title": "JHipster",
		"hex": "3E8ACC",
		"source": "https://github.com/jhipster/jhipster-artwork/blob/1085d85ab6d819b9ef7f6cc710ec8a4977b95e90/logos/JHipster%20bowtie.svg",
		"guidelines": "https://www.jhipster.tech/artwork",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Jinja",
		"hex": "B41717",
		"source": "https://github.com/pallets/jinja/blob/1c240154865a7b6034033027e3c2ca8a2fa53fc2/artwork/jinjalogo.svg"
	},
	{
		"title": "Jio",
		"hex": "0A2885",
		"source": "https://commons.wikimedia.org/wiki/File:Reliance_Jio_Logo.svg"
	},
	{
		"title": "Jira",
		"hex": "0052CC",
		"source": "https://atlassian.design/resources/logo-library",
		"guidelines": "https://atlassian.design/foundations/logos/"
	},
	{
		"title": "Jira Software",
		"hex": "0052CC",
		"source": "https://www.atlassian.com/company/news/press-kit",
		"guidelines": "https://atlassian.design/foundations/logos/"
	},
	{
		"title": "JitPack",
		"hex": "000000",
		"source": "https://docs.jitpack.io"
	},
	{
		"title": "Jitsi",
		"hex": "97979A",
		"source": "https://github.com/jitsi/jitsi-meet/blob/767101497c9a52abf8cef7893e8d6e7e4283bbfc/images/watermark.svg"
	},
	{
		"title": "John Deere",
		"hex": "367C2B",
		"source": "https://en.wikipedia.org/wiki/File:John_Deere_logo.svg",
		"guidelines": "https://johndeere.widencollective.com/portals/arrshkzc/MyPortalFeb23,2021"
	},
	{
		"title": "Joomla",
		"hex": "5091CD",
		"source": "https://docs.joomla.org/Joomla:Brand_Identity_Elements/Official_Logo",
		"guidelines": "https://docs.joomla.org/Joomla:Brand_Identity_Elements"
	},
	{
		"title": "Joplin",
		"hex": "1071D3",
		"source": "https://github.com/laurent22/joplin/blob/45e35576bd8b1bb0ffe958309cc1ab3736cc266b/Assets/JoplinLetter.svg"
	},
	{
		"title": "Jordan",
		"hex": "000000",
		"source": "https://www.nike.com/jordan"
	},
	{
		"title": "JOUAV",
		"hex": "E1B133",
		"source": "https://www.jouav.com"
	},
	{
		"title": "Jovian",
		"hex": "0D61FF",
		"source": "https://jovian.com"
	},
	{
		"title": "JPEG",
		"hex": "8A8A8A",
		"source": "https://jpeg.org/contact.html",
		"license": {
			"type": "CC-BY-ND-4.0"
		}
	},
	{
		"title": "jQuery",
		"hex": "0769AD",
		"source": "https://brand.jquery.org/logos/",
		"guidelines": "https://brand.jquery.org/logos/"
	},
	{
		"title": "JR Group",
		"hex": "44AF35",
		"source": "https://www.jrhokkaido.co.jp"
	},
	{
		"title": "jsDelivr",
		"hex": "E84D3D",
		"source": "https://github.com/jsdelivr/www.jsdelivr.com/blob/eff02f3a8879cf7c7296840584e1293fe04e3a76/src/public/img/logo_horizontal.svg"
	},
	{
		"title": "JSFiddle",
		"hex": "0084FF",
		"source": "https://jsfiddle.net"
	},
	{
		"title": "JSON",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:JSON_vector_logo.svg"
	},
	{
		"title": "JSON Web Tokens",
		"hex": "000000",
		"source": "https://jwt.io"
	},
	{
		"title": "JSR",
		"hex": "F7DF1E",
		"source": "https://github.com/jsr-io/jsr/blob/98c4448c64b1dddd1fc7cc54af961284f4262e82/frontend/static/logo.svg"
	},
	{
		"title": "JSS",
		"hex": "F7DF1E",
		"source": "https://cssinjs.org"
	},
	{
		"title": "JUCE",
		"hex": "8DC63F",
		"source": "https://juce.com"
	},
	{
		"title": "Juejin",
		"hex": "007FFF",
		"source": "https://juejin.cn"
	},
	{
		"title": "JUKE",
		"hex": "6CD74A",
		"source": "https://juke.nl"
	},
	{
		"title": "Julia",
		"hex": "9558B2",
		"source": "https://github.com/JuliaLang/julia-logo-graphics/blob/b5551ca7946b4a25746c045c15fbb8806610f8d0/images/julia-dots.svg"
	},
	{
		"title": "Juniper Networks",
		"hex": "84B135",
		"source": "https://www.juniper.net/us/en/company/press-center/images/image-library/logos/",
		"guidelines": "https://www.juniper.net/us/en/company/press-center/images/image-library/logos/"
	},
	{
		"title": "JUnit5",
		"hex": "25A162",
		"source": "https://github.com/junit-team/junit5/blob/86465f4f491219ad0c0cf9c64eddca7b0edeb86f/assets/img/junit5-logo.svg"
	},
	{
		"title": "Jupyter",
		"hex": "F37626",
		"source": "https://github.com/jupyter/design/blob/80716ee75dd7b2a6ec6abcd89922d020483589b1/logos/Logo%20Mark/logomark-whitebody-whitemoons/logomark-whitebody-whitemoons.svg",
		"guidelines": "https://github.com/jupyter/design"
	},
	{
		"title": "Just Eat",
		"hex": "F36D00",
		"source": "https://justeattakeaway.com/newsroom/en-WW/media_kits/"
	},
	{
		"title": "JustGiving",
		"hex": "AD29B6",
		"source": "https://justgiving.com"
	},
	{
		"title": "K3s",
		"hex": "FFC61C",
		"source": "https://k3s.io"
	},
	{
		"title": "k6",
		"hex": "7D64FF",
		"source": "https://commons.wikimedia.org/wiki/File:K6-logo.svg",
		"aliases": {
			"aka": [
				"Grafana k6"
			]
		}
	},
	{
		"title": "Kaggle",
		"hex": "20BEFF",
		"source": "https://www.kaggle.com/brand-guidelines",
		"guidelines": "https://www.kaggle.com/brand-guidelines"
	},
	{
		"title": "Kagi",
		"hex": "FFB319",
		"source": "https://kagi.com"
	},
	{
		"title": "Kahoot!",
		"hex": "46178F",
		"source": "https://kahoot.com/library/kahoot-logo/",
		"guidelines": "https://kahoot.com/library/kahoot-logo/"
	},
	{
		"title": "KaiOS",
		"hex": "6F02B5",
		"source": "https://www.kaiostech.com/company/press-room"
	},
	{
		"title": "Kakao",
		"hex": "FFCD00",
		"source": "https://www.kakaocorp.com/kakao/introduce/ci",
		"aliases": {
			"loc": {
				"ko-KR": "카카오"
			}
		}
	},
	{
		"title": "KakaoTalk",
		"hex": "FFCD00",
		"source": "https://commons.wikimedia.org/wiki/File:KakaoTalk_logo.svg",
		"aliases": {
			"loc": {
				"ko-KR": "카카오톡"
			}
		}
	},
	{
		"title": "Kali Linux",
		"hex": "557C94",
		"source": "https://www.kali.org/docs/policy/trademark/",
		"guidelines": "https://www.kali.org/docs/policy/trademark/"
	},
	{
		"title": "Kamailio",
		"hex": "506365",
		"source": "https://www.kamailio.org/pub/kamailio-logos/current"
	},
	{
		"title": "Kaniko",
		"hex": "FFA600",
		"source": "https://github.com/GoogleContainerTools/kaniko/blob/cf5ca26aa4e2f7bf0de56efdf3b4e86b0ff74ed0/logo/Kaniko-Logo-Monochrome.svg"
	},
	{
		"title": "Karlsruher Verkehrsverbund",
		"hex": "9B2321",
		"source": "https://commons.wikimedia.org/wiki/File:KVV_2010.svg"
	},
	{
		"title": "Kasa Smart",
		"hex": "4ACBD6",
		"source": "https://www.tp-link.com/us/support/download/hs200/"
	},
	{
		"title": "KashFlow",
		"hex": "E5426E",
		"source": "https://www.kashflow.com"
	},
	{
		"title": "Kaspersky",
		"hex": "006D5C",
		"source": "https://www.kaspersky.com"
	},
	{
		"title": "Katana",
		"hex": "000000",
		"source": "https://www.foundry.com/products/katana"
	},
	{
		"title": "Kaufland",
		"hex": "E10915",
		"source": "https://www.kaufland.com"
	},
	{
		"title": "KDE",
		"hex": "1D99F3",
		"source": "https://kde.org/stuff/clipart/"
	},
	{
		"title": "KDE Plasma",
		"hex": "1D99F3",
		"source": "https://kde.org/stuff/clipart/",
		"guidelines": "https://kde.org/stuff/clipart/"
	},
	{
		"title": "Kdenlive",
		"hex": "527EB2",
		"source": "https://kdenlive.org/en/trademark-logo/",
		"guidelines": "https://kdenlive.org/en/trademark-logo/"
	},
	{
		"title": "Kedro",
		"hex": "FFC900",
		"source": "https://github.com/kedro-org/kedro-brand-identity/blob/7f7b380cb1a2951c06ca292f0d2b442db895f804/icon/black/kedro-icon-svgo-black.svg",
		"guidelines": "https://github.com/kedro-org/kedro-brand-identity/blob/7f7b380cb1a2951c06ca292f0d2b442db895f804/Kedro_Brand_Guidelines.pdf",
		"license": {
			"type": "custom",
			"url": "https://www.linuxfoundation.org/trademark-usage"
		}
	},
	{
		"title": "Keenetic",
		"hex": "009EE2",
		"source": "https://keenetic.com",
		"guidelines": "https://keenetic.com/en/legal"
	},
	{
		"title": "Keep a Changelog",
		"hex": "E05735",
		"source": "https://keepachangelog.com"
	},
	{
		"title": "KeePassXC",
		"hex": "6CAC4D",
		"source": "https://github.com/keepassxreboot/keepassxc/tree/3fdafc6d25e85050976e0cc645db579086db3f45"
	},
	{
		"title": "Keeper",
		"hex": "FFC700",
		"source": "https://docs.keeper.io/en/sso-connect-cloud/graphic-assets",
		"guidelines": "https://www.keepersecurity.com/assets/pdf/brand-guidelines.pdf"
	},
	{
		"title": "KeeWeb",
		"hex": "528BFF",
		"source": "https://github.com/keeweb/keeweb/blob/44432eb66d5b771d5867cdd74f2500d00e006783/graphics/svg/keeweb.svg"
	},
	{
		"title": "Kentico",
		"hex": "F05A22",
		"source": "https://www.kentico.com"
	},
	{
		"title": "Keras",
		"hex": "D00000",
		"source": "https://keras.io"
	},
	{
		"title": "Keybase",
		"hex": "33A0FF",
		"source": "https://github.com/keybase/client/tree/a144e0ce38ee9e495cc5acbcd4ef859f5534d820/media/logos"
	},
	{
		"title": "KeyCDN",
		"hex": "047AED",
		"source": "https://www.keycdn.com/logos"
	},
	{
		"title": "Keycloak",
		"hex": "4D4D4D",
		"source": "https://github.com/keycloak/keycloak-misc/blob/dee033f2d6d6b5c3a6ce8eb84e285f7e5626dbf6/logo/icon-black.svg",
		"license": {
			"type": "custom",
			"url": "https://www.linuxfoundation.org/legal/trademark-usage"
		}
	},
	{
		"title": "Keystone",
		"hex": "166BFF",
		"source": "https://keystonejs.com"
	},
	{
		"title": "KFC",
		"hex": "F40027",
		"source": "https://global.kfc.com/asset-library/",
		"aliases": {
			"aka": [
				"Kentucky Fried Chicken"
			]
		}
	},
	{
		"title": "Khan Academy",
		"hex": "14BF96",
		"source": "https://khanacademy.zendesk.com/hc/en-us/articles/202483630-Press-room",
		"guidelines": "https://support.khanacademy.org/hc/en-us/articles/202263034-Trademark-and-Brand-Usage-Policy"
	},
	{
		"title": "Khronos Group",
		"hex": "CC3333",
		"source": "https://www.khronos.org/legal/trademarks",
		"guidelines": "https://www.khronos.org/files/legal/Khronos-Logo-Usage-Guide.pdf"
	},
	{
		"title": "Kia",
		"hex": "05141F",
		"source": "https://www.kia.com"
	},
	{
		"title": "Kibana",
		"hex": "005571",
		"source": "https://www.elastic.co/brand"
	},
	{
		"title": "KiCad",
		"hex": "314CB0",
		"source": "https://www.kicad.org/about/kicad/",
		"license": {
			"type": "GPL-3.0-or-later"
		}
	},
	{
		"title": "Kick",
		"hex": "53FC19",
		"source": "https://kick.com"
	},
	{
		"title": "Kickstarter",
		"hex": "05CE78",
		"source": "https://www.kickstarter.com/help/brand_assets"
	},
	{
		"title": "Kik",
		"hex": "82BC23",
		"source": "https://www.kik.com/news/"
	},
	{
		"title": "Kingston Technology",
		"hex": "000000",
		"source": "https://www.kingston.com",
		"aliases": {
			"aka": [
				"Kingston"
			]
		}
	},
	{
		"title": "Kinopoisk",
		"hex": "FF5500",
		"source": "https://www.kinopoisk.ru/special/branding",
		"guidelines": "https://www.kinopoisk.ru/special/branding",
		"aliases": {
			"loc": {
				"ru-RU": "КиноПоиск"
			}
		}
	},
	{
		"title": "Kinsta",
		"hex": "5333ED",
		"source": "https://kinsta.com/press"
	},
	{
		"title": "Kirby",
		"hex": "000000",
		"source": "https://getkirby.com/press"
	},
	{
		"title": "Kit",
		"hex": "000000",
		"source": "https://kit.co"
	},
	{
		"title": "Kitsu",
		"hex": "FD755C",
		"source": "https://kitsu.io"
	},
	{
		"title": "Kiwix",
		"hex": "000000",
		"source": "https://wiki.kiwix.org/wiki/Logo",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Klarna",
		"hex": "FFB3C7",
		"source": "https://klarna.design"
	},
	{
		"title": "Kleinanzeigen",
		"hex": "1D4B00",
		"source": "https://www.kleinanzeigen.de",
		"aliases": {
			"aka": [
				"eBay Kleinanzeigen"
			]
		}
	},
	{
		"title": "KLM",
		"hex": "00A1DE",
		"source": "https://www.klm.com"
	},
	{
		"title": "Klook",
		"hex": "FF5722",
		"source": "https://www.klook.com/en-GB/newsroom/"
	},
	{
		"title": "Knative",
		"hex": "0865AD",
		"source": "https://github.com/knative/community/blob/fb49068c9b7619685248247d29e48eb3d96f3ac2/icons/logo.svg",
		"guidelines": "https://github.com/knative/community/blob/main/BRANDING.MD"
	},
	{
		"title": "Knex.js",
		"hex": "D26B38",
		"source": "https://github.com/knex/documentation/blob/a9c4ce47dbc6001bb1c6aa0649bb668edc78fea7/src/public/knex-logo.png"
	},
	{
		"title": "KNIME",
		"hex": "FDD800",
		"source": "https://www.knime.com"
	},
	{
		"title": "Knip",
		"hex": "F56E0F",
		"source": "https://knip.dev"
	},
	{
		"title": "KnowledgeBase",
		"hex": "9146FF",
		"source": "https://www.knowledgebase.com/design",
		"guidelines": "https://www.knowledgebase.com/design"
	},
	{
		"title": "Known",
		"hex": "333333",
		"source": "https://github.com/idno/known/tree/22c4935b57a61d94d2508651128b4f828f864989/gfx/logos"
	},
	{
		"title": "Ko-fi",
		"hex": "FF6433",
		"source": "https://more.ko-fi.com/brand-assets",
		"guidelines": "https://more.ko-fi.com/brand-assets"
	},
	{
		"title": "Koa",
		"hex": "33333D",
		"source": "https://koajs.com"
	},
	{
		"title": "Koc",
		"hex": "F9423A",
		"source": "https://www.koc.com.tr/en"
	},
	{
		"title": "Kodak",
		"hex": "ED0000",
		"source": "https://www.kodak.com",
		"guidelines": "https://www.kodak.com/en/company/page/site-terms"
	},
	{
		"title": "Kodi",
		"hex": "17B2E7",
		"source": "https://kodi.tv"
	},
	{
		"title": "Koenigsegg",
		"hex": "000000",
		"source": "https://www.koenigsegg.com"
	},
	{
		"title": "Kofax",
		"hex": "00558C",
		"source": "https://www.kofax.com"
	},
	{
		"title": "Komoot",
		"hex": "6AA127",
		"source": "https://newsroom.komoot.com/media_kits/219423/",
		"guidelines": "https://newsroom.komoot.com/media_kits/219423/"
	},
	{
		"title": "Konami",
		"hex": "B60014",
		"source": "https://commons.wikimedia.org/wiki/File:Konami_4th_logo_2.svg"
	},
	{
		"title": "Kong",
		"hex": "003459",
		"source": "https://konghq.com/brand-assets/",
		"guidelines": "https://konghq.com/brand/"
	},
	{
		"title": "Kongregate",
		"hex": "F04438",
		"source": "https://www.kongregate.com"
	},
	{
		"title": "Konva",
		"hex": "0D83CD",
		"source": "https://github.com/konvajs/konvajs.github.io/blob/2cfe67461dfe32076ba56c88a75fe8e99d068130/icon.png"
	},
	{
		"title": "Kotlin",
		"hex": "7F52FF",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/",
		"aliases": {
			"loc": {
				"ko-KR": "코틀린"
			}
		}
	},
	{
		"title": "Koyeb",
		"hex": "121212",
		"source": "https://www.koyeb.com"
	},
	{
		"title": "Krita",
		"hex": "3BABFF",
		"source": "https://krita.org/en/about/press/"
	},
	{
		"title": "KTM",
		"hex": "FF6600",
		"source": "https://ktm.com"
	},
	{
		"title": "Ktor",
		"hex": "087CFA",
		"source": "https://www.jetbrains.com/company/brand/#logos-and-icons-product-icons",
		"guidelines": "https://www.jetbrains.com/company/brand/#brand-guidelines"
	},
	{
		"title": "Kuaishou",
		"hex": "FF4906",
		"source": "https://www.kuaishou.com/official/material-lib",
		"guidelines": "https://www.kuaishou.com/official/material-lib"
	},
	{
		"title": "Kubernetes",
		"hex": "326CE5",
		"source": "https://github.com/kubernetes/kubernetes/tree/cac53883f4714452f3084a22e4be20d042a9df33/logo"
	},
	{
		"title": "Kubespray",
		"hex": "3D647F",
		"source": "https://github.com/kubernetes-sigs/kubespray/blob/1b2e66cd305d1349daed85c8e356a5a8de5cc1f3/logo/logo-dark.svg"
	},
	{
		"title": "Kubuntu",
		"hex": "0079C1",
		"source": "https://kubuntu.org"
	},
	{
		"title": "KuCoin",
		"hex": "01BC8D",
		"source": "https://www.kucoin.com/news/en-kucoin-media-kit"
	},
	{
		"title": "Kueski",
		"hex": "0075FF",
		"source": "https://www.kueski.com"
	},
	{
		"title": "Kuma",
		"hex": "290B53",
		"source": "https://cncf-branding.netlify.app/projects/kuma/"
	},
	{
		"title": "Kununu",
		"hex": "FFC62E",
		"source": "https://www.kununu.com"
	},
	{
		"title": "Kuula",
		"hex": "4092B4",
		"source": "https://kuula.co"
	},
	{
		"title": "KX",
		"hex": "101820",
		"source": "https://kx.com/news-room",
		"guidelines": "https://kx.com/news-room"
	},
	{
		"title": "Kyocera",
		"hex": "DF0522",
		"source": "https://uk.kyocera.com"
	},
	{
		"title": "L'Équipe",
		"hex": "E42829",
		"source": "https://commons.wikimedia.org/wiki/File:L_Equipe_Logo.svg"
	},
	{
		"title": "LabVIEW",
		"hex": "FFDB00",
		"source": "https://forums.ni.com/t5/NI-Partner-Network/New-Partner-Co-Marketing-Style-Guide/ba-p/3786987",
		"guidelines": "https://forums.ni.com/t5/NI-Partner-Network/New-Partner-Co-Marketing-Style-Guide/ba-p/3786987"
	},
	{
		"title": "LADA",
		"hex": "ED6B21",
		"source": "https://www.lada.ru",
		"aliases": {
			"loc": {
				"ru-RU": "Лада"
			}
		}
	},
	{
		"title": "Lamborghini",
		"hex": "B6A272",
		"source": "https://www.lamborghini.com"
	},
	{
		"title": "Land Rover",
		"hex": "005A2B",
		"source": "https://media.landrover.com/en/press-kit"
	},
	{
		"title": "LangChain",
		"hex": "1C3C3C",
		"source": "https://www.langchain.com"
	},
	{
		"title": "Langflow",
		"hex": "000000",
		"source": "https://github.com/langflow-ai/langflow/blob/a5f5f3e3e30ee1740b696e3ad1823287ba27870c/docs/static/img/langflow-icon-black-transparent.svg"
	},
	{
		"title": "LangGraph",
		"hex": "1C3C3C",
		"source": "https://www.langchain.com/langgraph"
	},
	{
		"title": "LanguageTool",
		"hex": "45A1FC",
		"source": "https://languagetool.org"
	},
	{
		"title": "Lapce",
		"hex": "3B82F6",
		"source": "https://github.com/lapce/lapce/blob/95c4cf2d87083e348c0b621d0be0ea17f79ed703/extra/images/logo.svg"
	},
	{
		"title": "Laragon",
		"hex": "0E83CD",
		"source": "https://laragon.org"
	},
	{
		"title": "Laravel",
		"hex": "FF2D20",
		"source": "https://github.com/laravel/art/tree/5a8325b064634b900f25dbb6f1cafd888b2d2211"
	},
	{
		"title": "Laravel Horizon",
		"hex": "405263",
		"source": "https://github.com/laravel/horizon/blob/79ed572422d0ff789e9673a6dd9579026f14233a/public/img/horizon.svg"
	},
	{
		"title": "Laravel Nova",
		"hex": "252D37",
		"source": "https://nova.laravel.com"
	},
	{
		"title": "Last.fm",
		"hex": "D51007",
		"source": "https://commons.wikimedia.org/wiki/File:Lastfm_logo.svg"
	},
	{
		"title": "LastPass",
		"hex": "D32D27",
		"source": "https://lastpass.com/press-room/",
		"guidelines": "https://lastpass.com/press-room/"
	},
	{
		"title": "LaTeX",
		"hex": "008080",
		"source": "https://github.com/latex3/branding/tree/9def6b5f6075567d62b67424e11dbe6d4d5245b4"
	},
	{
		"title": "Launchpad",
		"hex": "F8C300",
		"source": "https://help.launchpad.net/logo/submissions",
		"guidelines": "https://help.launchpad.net/Legal",
		"license": {
			"type": "CC-BY-ND-2.0"
		}
	},
	{
		"title": "Lazarus",
		"hex": "000000",
		"source": "https://sourceforge.net/projects/lazarus/"
	},
	{
		"title": "LazyVim",
		"hex": "2E7DE9",
		"source": "https://github.com/LazyVim/lazyvim.github.io/blob/db7f1bd035de3f41a75a29f65f36819f6ac152af/static/img/icon.svg"
	},
	{
		"title": "LBRY",
		"hex": "2F9176",
		"source": "https://lbry.com/press-kit",
		"guidelines": "https://lbry.com/faq/acceptable-use-policy"
	},
	{
		"title": "Leader Price",
		"hex": "E50005",
		"source": "https://www.leaderprice.fr"
	},
	{
		"title": "Leaflet",
		"hex": "199900",
		"source": "https://github.com/Leaflet/Leaflet/blob/d843c3b88486713827d7e860b58bdba75bfbd5a2/src/images/logo.svg"
	},
	{
		"title": "League of Legends",
		"hex": "C28F2C",
		"source": "https://www.leagueoflegends.com"
	},
	{
		"title": "Leanpub",
		"hex": "262425",
		"source": "https://leanpub.com/press",
		"guidelines": "https://leanpub.com/press"
	},
	{
		"title": "LeetCode",
		"hex": "FFA116",
		"source": "https://leetcode.com/store"
	},
	{
		"title": "Lefthook",
		"hex": "FF1E1E",
		"source": "https://github.com/evilmartians/lefthook/blob/c44511f070ef2785fecb215862c4f2ff1ed8dccb/logo_sign.svg"
	},
	{
		"title": "Legacy Games",
		"hex": "144B9E",
		"source": "https://legacygames.com"
	},
	{
		"title": "Leica",
		"hex": "E20612",
		"source": "https://leica-camera.com",
		"guidelines": "https://leica-camera.com/en-US/legal-notices"
	},
	{
		"title": "Lemmy",
		"hex": "000000",
		"source": "https://join-lemmy.org",
		"license": {
			"type": "custom",
			"url": "https://github.com/LemmyNet/lemmy/blob/main/LICENSE"
		}
	},
	{
		"title": "Lemon Squeezy",
		"hex": "FFC233",
		"source": "https://www.lemonsqueezy.com"
	},
	{
		"title": "Lenovo",
		"hex": "E2231A",
		"source": "https://news.lenovo.com/press-kits/"
	},
	{
		"title": "Lens",
		"hex": "3D90CE",
		"source": "https://github.com/lensapp/lens/blob/3cc12d9599b655a366e7a34c356d2a84654b2466/docs/img/lens-logo-icon.svg"
	},
	{
		"title": "Leptos",
		"hex": "EF3939",
		"source": "https://github.com/leptos-rs/leptos/blob/6fac92cb6298f1bfa72464de47e33e47b5e5857d/logos/Simple_Icon.svg"
	},
	{
		"title": "Lerna",
		"hex": "C084FC",
		"source": "https://user-images.githubusercontent.com/900523/173044458-fd0b57f6-6374-4265-98b5-eb8f55fe1fb3.svg"
	},
	{
		"title": "Leroy Merlin",
		"hex": "78BE20",
		"source": "https://www.leroymerlin.fr"
	},
	{
		"title": "Les libraires",
		"hex": "CF4A0C",
		"source": "https://www.leslibraires.ca"
	},
	{
		"title": "Less",
		"hex": "1D365D",
		"source": "https://github.com/less/logo/blob/c9c10c328cfc00071e92443934b35e389310abf8/less_logo.ai"
	},
	{
		"title": "Let's Encrypt",
		"hex": "003A70",
		"source": "https://letsencrypt.org/trademarks/",
		"guidelines": "https://letsencrypt.org/trademarks/",
		"license": {
			"type": "CC-BY-NC-4.0"
		}
	},
	{
		"title": "Letterboxd",
		"hex": "202830",
		"source": "https://letterboxd.com/about/brand/",
		"guidelines": "https://letterboxd.com/about/brand/"
	},
	{
		"title": "levels.fyi",
		"hex": "788B95",
		"source": "https://www.levels.fyi/press/"
	},
	{
		"title": "LG",
		"hex": "A50034",
		"source": "https://www.lg.com/global/our-brand/brand-expression/elements/logo/index.jsp",
		"guidelines": "https://www.lg.com/global/our-brand/brand-expression/elements/logo/index.jsp"
	},
	{
		"title": "Li-Ning",
		"hex": "C5242C",
		"source": "https://www.lining.com"
	},
	{
		"title": "Libera.Chat",
		"hex": "FF55DD",
		"source": "https://libera.chat"
	},
	{
		"title": "Liberapay",
		"hex": "F6C915",
		"source": "https://en.liberapay.com/about/logos",
		"guidelines": "https://en.liberapay.com/about/logos",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "Libraries.io",
		"hex": "337AB7",
		"source": "https://github.com/librariesio/libraries.io/blob/9ab0f659bb7fe137c15cf676612b6811f501a0bd/public/safari-pinned-tab.svg"
	},
	{
		"title": "LibraryThing",
		"hex": "251A15",
		"source": "https://twitter.com/LibraryThing/status/1054466649271656448"
	},
	{
		"title": "LibreOffice",
		"hex": "18A303",
		"source": "https://wiki.documentfoundation.org/Marketing/Branding",
		"guidelines": "https://wiki.documentfoundation.org/Marketing/Branding"
	},
	{
		"title": "LibreOffice Base",
		"hex": "7324A9",
		"source": "https://github.com/LibreOffice/help/blob/e3b1cce7dde7e964c7670dd24a167e750654685a/source/media/navigation/libo-base.svg",
		"guidelines": "https://wiki.documentfoundation.org/Design/Branding",
		"license": {
			"type": "MPL-2.0"
		}
	},
	{
		"title": "LibreOffice Calc",
		"hex": "007C3C",
		"source": "https://github.com/LibreOffice/help/blob/02faeab6e7b014ca97a8c452e829af4522dadfc8/source/media/navigation/libo-calc.svg",
		"guidelines": "https://wiki.documentfoundation.org/Design/Branding",
		"license": {
			"type": "MPL-2.0"
		}
	},
	{
		"title": "LibreOffice Draw",
		"hex": "CB6D30",
		"source": "https://github.com/LibreOffice/help/blob/02faeab6e7b014ca97a8c452e829af4522dadfc8/source/media/navigation/libo-draw.svg",
		"guidelines": "https://wiki.documentfoundation.org/Design/Branding",
		"license": {
			"type": "MPL-2.0"
		}
	},
	{
		"title": "LibreOffice Impress",
		"hex": "D0120D",
		"source": "https://github.com/LibreOffice/help/blob/02faeab6e7b014ca97a8c452e829af4522dadfc8/source/media/navigation/libo-impress.svg",
		"guidelines": "https://wiki.documentfoundation.org/Design/Branding",
		"license": {
			"type": "MPL-2.0"
		}
	},
	{
		"title": "LibreOffice Math",
		"hex": "C10018",
		"source": "https://github.com/LibreOffice/help/blob/02faeab6e7b014ca97a8c452e829af4522dadfc8/source/media/navigation/libo-math.svg",
		"guidelines": "https://wiki.documentfoundation.org/Design/Branding",
		"license": {
			"type": "MPL-2.0"
		}
	},
	{
		"title": "LibreOffice Writer",
		"hex": "083FA6",
		"source": "https://github.com/LibreOffice/help/blob/02faeab6e7b014ca97a8c452e829af4522dadfc8/source/media/navigation/libo-writer.svg",
		"guidelines": "https://wiki.documentfoundation.org/Design/Branding",
		"license": {
			"type": "MPL-2.0"
		}
	},
	{
		"title": "LibreTranslate",
		"hex": "1565C0",
		"source": "https://libretranslate.com"
	},
	{
		"title": "LibreTube",
		"hex": "FF9699",
		"source": "https://github.com/libre-tube/libre-tube.github.io/blob/e5e10090cab71ee7c0abdfbf2789977025733eb7/assets/icons/icon.svg"
	},
	{
		"title": "LibreWolf",
		"hex": "00ACFF",
		"source": "https://librewolf.net"
	},
	{
		"title": "libuv",
		"hex": "403C3D",
		"source": "https://github.com/libuv/libuv/blob/e4087dedf837f415056a45a838f639a3d9dc3ced/img/logos.svg"
	},
	{
		"title": "Lichess",
		"hex": "000000",
		"source": "https://lichess.org/about"
	},
	{
		"title": "Lidl",
		"hex": "0050AA",
		"source": "https://www.lidl.de"
	},
	{
		"title": "LIFX",
		"hex": "000000",
		"source": "https://www.lifx.com/pages/press-enquiries",
		"guidelines": "https://www.dropbox.com/sh/i9khucz3ucy0q5v/AACrbtcpEIS0PdP84RdkhoAFa/Guides"
	},
	{
		"title": "LightBurn",
		"hex": "57182D",
		"source": "https://lightburnsoftware.com"
	},
	{
		"title": "Lighthouse",
		"hex": "F44B21",
		"source": "https://github.com/GoogleChrome/lighthouse/blob/80d2e6c1948f232ec4f1bdeabc8bc632fc5d0bfd/assets/lh_favicon.svg"
	},
	{
		"title": "Lightning",
		"hex": "792EE5",
		"source": "https://github.com/Lightning-AI/lightning/blob/a584196abf820179adb0758ef67ddae91c44e7bc/docs/source/_static/images/icon.svg"
	},
	{
		"title": "LimeSurvey",
		"hex": "14AE5C",
		"source": "https://www.limesurvey.org"
	},
	{
		"title": "LINE",
		"hex": "00C300",
		"source": "https://line.me/en/logo",
		"guidelines": "https://line.me/en/logo",
		"aliases": {
			"loc": {
				"ja-JP": "ライン",
				"ko-KR": "라인"
			}
		}
	},
	{
		"title": "LineageOS",
		"hex": "167C80",
		"source": "https://www.lineageos.org",
		"guidelines": "https://docs.google.com/presentation/d/1VmxFrVqkjtNMjZbAcrC4egp8C_So7gjJR3KuxdJfJDo/edit?usp=sharing"
	},
	{
		"title": "Linear",
		"hex": "5E6AD2",
		"source": "https://linear.app"
	},
	{
		"title": "Linkerd",
		"hex": "2BEDA7",
		"source": "https://cncf-branding.netlify.app/projects/linkerd/"
	},
	{
		"title": "Linkfire",
		"hex": "FF3850",
		"source": "https://www.linkfire.com"
	},
	{
		"title": "Linksys",
		"hex": "000000",
		"source": "https://www.linksys.com"
	},
	{
		"title": "Linktree",
		"hex": "43E55E",
		"source": "https://linktr.ee"
	},
	{
		"title": "Linphone",
		"hex": "FF5E00",
		"source": "https://gitlab.linphone.org/BC/public/linphone-desktop/-/blob/90dff93a24cafb6a0144b345233ca53bf8c3d92e/Linphone/data/image/logo.svg"
	},
	{
		"title": "LintCode",
		"hex": "13B4FF",
		"source": "https://www.lintcode.com"
	},
	{
		"title": "Linux",
		"hex": "FCC624",
		"source": "https://www.linuxfoundation.org/the-linux-mark/"
	},
	{
		"title": "Linux Containers",
		"hex": "333333",
		"source": "https://github.com/lxc/linuxcontainers.org/blob/29d3299ddf8718099b6de1464570fbbadbaabecb/static/img/containers.svg"
	},
	{
		"title": "Linux Foundation",
		"hex": "003778",
		"source": "https://www.linuxfoundation.org/brand-guidelines",
		"guidelines": "https://www.linuxfoundation.org/brand-guidelines"
	},
	{
		"title": "Linux Mint",
		"hex": "86BE43",
		"source": "https://github.com/linuxmint/brand-logo/blob/540ac3b08e987866d77a340f557f994c988ac2ae/ring-mono-green.svg"
	},
	{
		"title": "Linux Professional Institute",
		"hex": "FDC300",
		"source": "https://lpi.org/logos",
		"guidelines": "https://lpi.org/logos"
	},
	{
		"title": "LinuxServer",
		"hex": "DA3B8A",
		"source": "https://github.com/linuxserver/docker-documentation/blob/be0a78849bc87dec372721ffd6f267527d07815d/docs/assets/icon.svg"
	},
	{
		"title": "Lion Air",
		"hex": "ED3237",
		"source": "https://lionairthai.com/en/"
	},
	{
		"title": "Liquibase",
		"hex": "2962FF",
		"source": "https://www.liquibase.com/brand",
		"guidelines": "https://www.liquibase.com/brand"
	},
	{
		"title": "listmonk",
		"hex": "0055D4",
		"source": "https://listmonk.app"
	},
	{
		"title": "Lit",
		"hex": "324FFF",
		"source": "https://github.com/lit/lit.dev/blob/5e59bdb00b7a261d6fdcd6a4ae529e17f6146ed3/packages/lit-dev-content/site/images/flame-favicon.svg"
	},
	{
		"title": "Litecoin",
		"hex": "A6A9AA",
		"source": "https://litecoin-foundation.org/litecoin-branding-guidelines/",
		"guidelines": "https://litecoin-foundation.org/litecoin-branding-guidelines/"
	},
	{
		"title": "Literal",
		"hex": "000000",
		"source": "https://literal.club/pages/press"
	},
	{
		"title": "LITIENGINE",
		"hex": "00A5BC",
		"source": "https://litiengine.com"
	},
	{
		"title": "LiveChat",
		"hex": "FF5100",
		"source": "https://livechat.design",
		"guidelines": "https://livechat.design"
	},
	{
		"title": "LiveJournal",
		"hex": "00B0EA",
		"source": "https://www.livejournal.com"
	},
	{
		"title": "Livewire",
		"hex": "4E56A6",
		"source": "https://laravel-livewire.com"
	},
	{
		"title": "LLVM",
		"hex": "262D3A",
		"source": "https://llvm.org/Logo.html"
	},
	{
		"title": "LMMS",
		"hex": "10B146",
		"source": "https://lmms.io/branding"
	},
	{
		"title": "Lobsters",
		"hex": "AC130D",
		"source": "https://github.com/lobsters/lobsters/blob/dcd56c1d3f7190e33a73b86b77e7feb2665ddc50/app/assets/images/logo-color.svg",
		"license": {
			"type": "BSD-3-Clause"
		}
	},
	{
		"title": "Local",
		"hex": "51BB7B",
		"source": "https://localwp.com"
	},
	{
		"title": "Lodash",
		"hex": "3492FF",
		"source": "https://github.com/lodash/lodash.com/blob/c8d41c62b446f08905fd94802db4da8da05d3e92/assets/img/lodash.svg"
	},
	{
		"title": "Logitech",
		"hex": "00B8FC",
		"source": "https://www.logitech.com/en-us/pr/library",
		"aliases": {
			"dup": [
				{
					"title": "Logicool",
					"hex": "00BFFF",
					"loc": {
						"ja-JP": "ロジクール"
					}
				}
			]
		}
	},
	{
		"title": "Logitech G",
		"hex": "00B8FC",
		"source": "https://www.logitechg.com"
	},
	{
		"title": "LogMeIn",
		"hex": "45B6F2",
		"source": "https://www.logmein.com/legal/trademark",
		"guidelines": "https://www.logmein.com/legal/trademark"
	},
	{
		"title": "Logseq",
		"hex": "85C8C8",
		"source": "https://github.com/logseq/logseq/blob/c4d15ec8487c9fb6b6f41780fc1abddab89491e4/resources/icon.png"
	},
	{
		"title": "Logstash",
		"hex": "005571",
		"source": "https://www.elastic.co/brand",
		"guidelines": "https://www.elastic.co/brand"
	},
	{
		"title": "Looker",
		"hex": "4285F4",
		"source": "https://looker.com"
	},
	{
		"title": "Loom",
		"hex": "625DF5",
		"source": "https://www.loom.com/press"
	},
	{
		"title": "Loop",
		"hex": "F29400",
		"source": "https://loop.frontiersin.org"
	},
	{
		"title": "LoopBack",
		"hex": "3F5DFF",
		"source": "https://loopback.io/resources"
	},
	{
		"title": "Loot Crate",
		"hex": "1E1E1E",
		"source": "https://lootcrate.com"
	},
	{
		"title": "Lospec",
		"hex": "EAEAEA",
		"source": "https://lospec.com/brand",
		"guidelines": "https://lospec.com/brand"
	},
	{
		"title": "LOT Polish Airlines",
		"hex": "11397E",
		"source": "https://www.lot.com/us/en/kaleidoscope-inflight-magazine"
	},
	{
		"title": "LottieFiles",
		"hex": "00DDB3",
		"source": "https://lottiefiles.github.io/lottie-docs/"
	},
	{
		"title": "LTspice",
		"hex": "900028",
		"source": "https://www.analog.com/media/en/news-marketing-collateral/solutions-bulletins-brochures/ltspice-keyboard-shortcuts.pdf",
		"guidelines": "https://www.analog.com/en/about-adi/legal-and-risk-oversight/intellectual-property/trademark-notice.html"
	},
	{
		"title": "Lua",
		"hex": "2C2D72",
		"source": "https://www.lua.org/images/",
		"guidelines": "https://www.lua.org/images/"
	},
	{
		"title": "Lubuntu",
		"hex": "0068C8",
		"source": "https://lubuntu.net"
	},
	{
		"title": "Lucia",
		"hex": "5F57FF",
		"source": "https://v2.lucia-auth.com"
	},
	{
		"title": "Lucid",
		"hex": "282C33",
		"source": "https://lucid.co/brand",
		"guidelines": "https://lucid.co/brand"
	},
	{
		"title": "Lucide",
		"hex": "F56565",
		"source": "https://lucide.dev"
	},
	{
		"title": "Ludwig",
		"hex": "FFFFFF",
		"source": "https://github.com/ludwig-ai/ludwig-docs/blob/8d8abb2117a93af2622a6545943c773b27153e1b/docs/images/ludwig_icon.svg"
	},
	{
		"title": "Lufthansa",
		"hex": "05164D",
		"source": "https://www.lufthansa.com"
	},
	{
		"title": "Lumen",
		"hex": "E74430",
		"source": "https://lumen.laravel.com"
	},
	{
		"title": "Lunacy",
		"hex": "179DE3",
		"source": "https://icons8.com/lunacy"
	},
	{
		"title": "Lutris",
		"hex": "FF9900",
		"source": "https://github.com/lutris/lutris/blob/f62feaef063868cb39afddefbb9ba7a5928bd978/share/icons/hicolor/scalable/apps/lutris.svg"
	},
	{
		"title": "LVGL",
		"hex": "343839",
		"source": "https://lvgl.io/safari-pinned-tab.svg",
		"aliases": {
			"aka": [
				"Light and Versatile Graphics Library"
			]
		}
	},
	{
		"title": "Lydia",
		"hex": "0180FF",
		"source": "https://lydia-app.com/en/info/press.html",
		"guidelines": "https://lydia-app.com/en/info/press.html"
	},
	{
		"title": "Lyft",
		"hex": "FF00BF",
		"source": "https://www.lyft.com/press"
	},
	{
		"title": "MAAS",
		"hex": "E95420",
		"source": "https://design.ubuntu.com/downloads/",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "macOS",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:MacOS_wordmark_(2017).svg"
	},
	{
		"title": "MacPaw",
		"hex": "000000",
		"source": "https://macpaw.com"
	},
	{
		"title": "Macy's",
		"hex": "E21A2C",
		"source": "https://www.macysinc.com/news-media/media-assets"
	},
	{
		"title": "Magasins U",
		"hex": "E71B34",
		"source": "https://www.magasins-u.com"
	},
	{
		"title": "Magic",
		"hex": "6851FF",
		"source": "https://magic.link/brand-assets",
		"guidelines": "https://magic.link/brand-assets"
	},
	{
		"title": "Magisk",
		"hex": "00AF9C",
		"source": "https://github.com/topjohnwu/Magisk/blob/23ad611566b557f26d268920692b25aa89fc0070/app/src/main/res/drawable/ic_magisk.xml"
	},
	{
		"title": "Mahindra",
		"hex": "DD052B",
		"source": "https://www.mahindra.com",
		"guidelines": "https://www.mahindra.com/newsroom/logos"
	},
	{
		"title": "mail.com",
		"hex": "004788",
		"source": "https://www.mail.com",
		"guidelines": "https://www.mail.com/company/terms/"
	},
	{
		"title": "Mail.Ru",
		"hex": "005FF9",
		"source": "https://my.mail.ru"
	},
	{
		"title": "mailbox.org",
		"hex": "76BB21",
		"source": "https://mailbox.org/en/press"
	},
	{
		"title": "MailChimp",
		"hex": "FFE01B",
		"source": "https://mailchimp.com/about/brand-assets",
		"guidelines": "https://mailchimp.com/about/brand-assets"
	},
	{
		"title": "Mailgun",
		"hex": "F06B66",
		"source": "https://mailgun.com"
	},
	{
		"title": "Mailtrap",
		"hex": "22D172",
		"source": "https://mailtrap.io"
	},
	{
		"title": "MainWP",
		"hex": "7FB100",
		"source": "https://mainwp.com"
	},
	{
		"title": "Major League Hacking",
		"hex": "265A8F",
		"source": "https://mlh.io/brand-guidelines",
		"guidelines": "https://mlh.io/brand-guidelines"
	},
	{
		"title": "Make",
		"hex": "6D00CC",
		"source": "https://www.make.com/en/press",
		"guidelines": "https://www.make.com/en/press"
	},
	{
		"title": "MakerBot",
		"hex": "FF1E0D",
		"source": "https://www.makerbot.com/makerbot-press-assets"
	},
	{
		"title": "Malt",
		"hex": "FC5757",
		"source": "https://newsroom.malt.com/media-kit-uk",
		"guidelines": "https://newsroom.malt.com/media-kit-uk"
	},
	{
		"title": "Malwarebytes",
		"hex": "0D3ECC",
		"source": "https://www.malwarebytes.com"
	},
	{
		"title": "Mamba UI",
		"hex": "6D28D9",
		"source": "https://github.com/Microwawe/mamba-ui/blob/b4ca2eba570c451886e5822d7ba12a8d78015bba/src/assets/svg/logo.svg"
	},
	{
		"title": "MAMP",
		"hex": "02749C",
		"source": "https://www.mamp.info/en/mamp/mac/"
	},
	{
		"title": "MAN",
		"hex": "E40045",
		"source": "https://man.eu/corporate/en/homepage.html"
	},
	{
		"title": "ManageIQ",
		"hex": "EF2929",
		"source": "https://www.manageiq.org/logo/"
	},
	{
		"title": "Manjaro",
		"hex": "35BF5C",
		"source": "https://manjaro.org"
	},
	{
		"title": "Mantine",
		"hex": "339AF0",
		"source": "https://github.com/mantinedev/mantine/blob/f2da0287bfcda19dcf7866f4d03a05d1ee7b49f7/docs/src/images/logo.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Mapbox",
		"hex": "000000",
		"source": "https://www.mapbox.com/about/press/brand-guidelines",
		"guidelines": "https://www.mapbox.com/about/press/brand-guidelines"
	},
	{
		"title": "Mapillary",
		"hex": "00AF66",
		"source": "https://www.mapillary.com/press-kit",
		"guidelines": "https://www.mapillary.com/press-kit"
	},
	{
		"title": "MapLibre",
		"hex": "396CB2",
		"source": "https://github.com/maplibre/maplibre-gl-js-docs/blob/e916a4cdd671890126f88b26b2b16c04220dc4b0/docs/pages/assets/favicon/maplibregl-favicon.svg"
	},
	{
		"title": "MapTiler",
		"hex": "323357",
		"source": "https://www.maptiler.com/press/#logo",
		"guidelines": "https://www.maptiler.com/press/#logo"
	},
	{
		"title": "MariaDB",
		"hex": "003545",
		"source": "https://mariadb.com/about-us/logos/",
		"guidelines": "https://mariadb.com/about-us/logos/"
	},
	{
		"title": "MariaDB Foundation",
		"hex": "1F305F",
		"source": "https://mariadb.org"
	},
	{
		"title": "Markdown",
		"hex": "000000",
		"source": "https://github.com/dcurtis/markdown-mark/tree/360a3657fef7f6ad0b303296a95ad52985caa0d3",
		"guidelines": "https://github.com/dcurtis/markdown-mark",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "Marko",
		"hex": "2596BE",
		"source": "https://github.com/marko-js/website/blob/c03b8229e8fe8e01fde6c0772bc1cb0ceae9be05/src/logos/marko.svg"
	},
	{
		"title": "Marriott",
		"hex": "A70023",
		"source": "https://marriott-hotels.marriott.com"
	},
	{
		"title": "MarvelApp",
		"hex": "1FB6FF",
		"source": "https://marvelapp.com"
	},
	{
		"title": "Maserati",
		"hex": "0C2340",
		"source": "https://www.stellantis.com/en/brands/maserati"
	},
	{
		"title": "MasterCard",
		"hex": "EB001B",
		"source": "https://brand.mastercard.com/brandcenter/mastercard-brand-mark/downloads.html",
		"guidelines": "https://brand.mastercard.com/brandcenter/mastercard-brand-mark.html"
	},
	{
		"title": "mastercomfig",
		"hex": "009688",
		"source": "https://github.com/mastercomfig/mastercomfig.github.io/blob/d910ce7e868a6ef32106e36996c3473d78da2ce3/img/mastercomfig_logo.svg"
	},
	{
		"title": "Mastodon",
		"hex": "6364FF",
		"source": "https://github.com/mastodon/mastodon/blob/7ccf7a73f1c47a8c03712c39f7c591e837cf6d08/app/javascript/images/logo-symbol-icon.svg",
		"guidelines": "https://joinmastodon.org/branding"
	},
	{
		"title": "Material Design",
		"hex": "757575",
		"source": "https://material.io/design/"
	},
	{
		"title": "Material Design Icons",
		"hex": "2196F3",
		"source": "https://materialdesignicons.com/icon/vector-square",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Material for MkDocs",
		"hex": "526CFE",
		"source": "https://github.com/squidfunk/mkdocs-material/blob/9ff75d11838cc01615697884c0eb9eb55f4652ad/src/templates/.icons/logo-monochrome.svg"
	},
	{
		"title": "Matillion",
		"hex": "19E57F",
		"source": "https://www.matillion.com"
	},
	{
		"title": "Matomo",
		"hex": "3152A0",
		"source": "https://matomo.org/media/"
	},
	{
		"title": "Matrix",
		"hex": "000000",
		"source": "https://matrix.org"
	},
	{
		"title": "Matter.js",
		"hex": "4B5562",
		"source": "https://brm.io/matter-js"
	},
	{
		"title": "Mattermost",
		"hex": "0058CC",
		"source": "https://www.mattermost.org/brand-guidelines/",
		"guidelines": "https://www.mattermost.org/brand-guidelines/"
	},
	{
		"title": "Matternet",
		"hex": "261C29",
		"source": "https://mttr.net"
	},
	{
		"title": "Mautic",
		"hex": "4E5E9E",
		"source": "https://www.mautic.org/about/logos-and-graphics"
	},
	{
		"title": "Max",
		"hex": "525252",
		"source": "https://cycling74.com"
	},
	{
		"title": "Max-Planck-Gesellschaft",
		"hex": "006C66",
		"source": "https://www.mpg.de"
	},
	{
		"title": "Maytag",
		"hex": "002E5F",
		"source": "https://www.maytagcommerciallaundry.com/mclstorefront/c/-/p/MYR40PD"
	},
	{
		"title": "Mazda",
		"hex": "101010",
		"source": "https://www.mazda.com/en/about/profile/library/"
	},
	{
		"title": "Maze",
		"hex": "000000",
		"source": "https://mazedesign.notion.site/Press-Kit-421d405e76154662a547ce9ef2a3f018"
	},
	{
		"title": "McAfee",
		"hex": "C01818",
		"source": "https://www.mcafee.com/enterprise/en-us/about/newsroom/product-images.html"
	},
	{
		"title": "McDonald's",
		"hex": "FBC817",
		"source": "https://www.mcdonalds.com/gb/en-gb/newsroom.html"
	},
	{
		"title": "McLaren",
		"hex": "FF0000",
		"source": "https://cars.mclaren.com"
	},
	{
		"title": "mdBook",
		"hex": "000000",
		"source": "https://github.com/rust-lang/mdBook/blob/cdfa5ad9909e2cba8390688f3f0686fb70cb4bef/src/theme/favicon.svg"
	},
	{
		"title": "MDN Web Docs",
		"hex": "000000",
		"source": "https://github.com/mdn/yari/blob/77e6cda02f7013219e9da27a00b9424085e60fdb/client/src/assets/mdn-logo.svg"
	},
	{
		"title": "MDX",
		"hex": "1B1F24",
		"source": "https://github.com/mdx-js/mdx/blob/b8a76c95deb14f7297bafdac1aa3eddd2b0fbb8f/docs/_static/icon.svg"
	},
	{
		"title": "Mealie",
		"hex": "E58325",
		"source": "https://github.com/mealie-recipes/mealie.io/blob/5519cac801c116a5688c63d8126c3bf1ce568c58/components/App/Toolbar.vue"
	},
	{
		"title": "MediaFire",
		"hex": "1299F3",
		"source": "https://www.mediafire.com/developers/brand_assets/mediafire_brand_assets/",
		"guidelines": "https://www.mediafire.com/developers/brand_assets/mediafire_brand_assets/"
	},
	{
		"title": "MediaMarkt",
		"hex": "DF0000",
		"source": "https://www.mediamarkt.de"
	},
	{
		"title": "MediaPipe",
		"hex": "0097A7",
		"source": "https://developers.google.com/static/mediapipe/images/mediapipe_icon.svg"
	},
	{
		"title": "MediaTek",
		"hex": "EC9430",
		"source": "https://corp.mediatek.com/news-events/press-library"
	},
	{
		"title": "MediBang Paint",
		"hex": "00DBDE",
		"source": "https://medibangpaint.com"
	},
	{
		"title": "Medium",
		"hex": "000000",
		"source": "https://medium.design/logos-and-brand-guidelines-f1a01a733592",
		"guidelines": "https://medium.design/logos-and-brand-guidelines-f1a01a733592"
	},
	{
		"title": "Medusa",
		"hex": "000000",
		"source": "https://github.com/medusajs/medusa/blob/5b91a3503af41b94697a5c27c35268c29e9bd135/www/docs/static/img/logo.svg"
	},
	{
		"title": "Meetup",
		"hex": "ED1C40",
		"source": "https://www.meetup.com/media/"
	},
	{
		"title": "MEGA",
		"hex": "D9272E",
		"source": "https://mega.io/media"
	},
	{
		"title": "Meilisearch",
		"hex": "FF5CAA",
		"source": "https://www.meilisearch.com"
	},
	{
		"title": "Meituan",
		"hex": "FFD100",
		"source": "https://www.meituan.com/media",
		"aliases": {
			"loc": {
				"zh-CN": "美团"
			}
		}
	},
	{
		"title": "Meizu",
		"hex": "FF4132",
		"source": "https://commons.wikimedia.org/wiki/File:Meizu.svg",
		"aliases": {
			"loc": {
				"zh-CN": "魅族"
			}
		}
	},
	{
		"title": "Mendeley",
		"hex": "9D1620",
		"source": "https://www.mendeley.com"
	},
	{
		"title": "MentorCruise",
		"hex": "172E59",
		"source": "https://mentorcruise.com"
	},
	{
		"title": "Mercado Pago",
		"hex": "00B1EA",
		"source": "https://www.mercadopago.com"
	},
	{
		"title": "Mercedes",
		"hex": "242424",
		"source": "https://www.mercedes-benz.com"
	},
	{
		"title": "Merck",
		"hex": "007A73",
		"source": "https://www.merck.com"
	},
	{
		"title": "Mercurial",
		"hex": "999999",
		"source": "https://www.mercurial-scm.org/hg-logo/",
		"guidelines": "https://www.mercurial-scm.org/hg-logo/",
		"license": {
			"type": "GPL-2.0-or-later"
		}
	},
	{
		"title": "Mermaid",
		"hex": "FF3670",
		"source": "https://github.com/mermaid-js/mermaid/blob/f5bd1e08098fa688ef889e73c8b06696e75e62d8/docs/public/mermaid-logo.svg"
	},
	{
		"title": "Messenger",
		"hex": "0866FF",
		"source": "https://about.meta.com/brand/resources/facebook/messenger-icon",
		"guidelines": "https://about.meta.com/brand/resources/facebook/messenger-icon"
	},
	{
		"title": "Meta",
		"hex": "0467DF",
		"source": "https://www.meta.com",
		"guidelines": "https://www.facebook.com/brand/resources/meta/company-brand"
	},
	{
		"title": "Metabase",
		"hex": "509EE3",
		"source": "https://www.metabase.com"
	},
	{
		"title": "Metacritic",
		"hex": "000000",
		"source": "https://www.metacritic.com",
		"guidelines": "https://developer.iva-api.com/docs/v2/metacritic-brand-guidelines"
	},
	{
		"title": "MetaFilter",
		"hex": "065A8F",
		"source": "https://www.metafilter.com"
	},
	{
		"title": "Metasploit",
		"hex": "2596CD",
		"source": "https://github.com/rapid7/metasploit-framework/blob/f8bd7dfd834354c9a2e2c03e1d9f5d53f8881954/docs/assets/images/favicon.png"
	},
	{
		"title": "Meteor",
		"hex": "DE4F4F",
		"source": "https://meteor.com/brand-assets"
	},
	{
		"title": "Metro",
		"hex": "EF4242",
		"source": "https://facebook.github.io/metro/"
	},
	{
		"title": "Metro de la Ciudad de México",
		"hex": "F77E1C",
		"source": "https://es.wikipedia.org/wiki/Archivo:Metro_de_la_Ciudad_de_M%C3%A9xico_(logo)_version_2019.svg"
	},
	{
		"title": "Metro de Madrid",
		"hex": "255E9C",
		"source": "https://commons.wikimedia.org/wiki/File:MetroMadridLogo.svg"
	},
	{
		"title": "Métro de Paris",
		"hex": "003E95",
		"source": "https://www.ratp.fr"
	},
	{
		"title": "MeWe",
		"hex": "17377F",
		"source": "https://mewe.com"
	},
	{
		"title": "MG",
		"hex": "FF0000",
		"source": "https://www.mg.co.uk/themes/custom/mg/assets/images/svg/mg-logo-desktop.svg",
		"guidelines": "https://www.mg.co.uk/terms-and-conditions",
		"aliases": {
			"aka": [
				"Morris Garages"
			]
		}
	},
	{
		"title": "Micro Editor",
		"hex": "2E3192",
		"source": "https://github.com/zyedidia/micro/blob/48645907ec55798b75723019dad75dba51bd97d7/assets/micro-logo-mark.svg"
	},
	{
		"title": "micro:bit",
		"hex": "00ED00",
		"source": "https://microbit.org"
	},
	{
		"title": "Micro.blog",
		"hex": "FF8800",
		"source": "https://help.micro.blog"
	},
	{
		"title": "MicroPython",
		"hex": "2B2728",
		"source": "https://commons.wikimedia.org/wiki/File:MicroPython_new_logo.svg"
	},
	{
		"title": "Microstation",
		"hex": "62BB47",
		"source": "https://www.bentley.com/software/microstation"
	},
	{
		"title": "MicroStrategy",
		"hex": "D9232E",
		"source": "https://www.microstrategy.com/en/company/press-kit",
		"guidelines": "https://www.microstrategy.com/en/company/press-kit"
	},
	{
		"title": "MIDI",
		"hex": "000000",
		"source": "https://en.wikipedia.org/wiki/MIDI"
	},
	{
		"title": "Migadu",
		"hex": "0043CE",
		"source": "https://migadu.com"
	},
	{
		"title": "miHoYo",
		"hex": "4EA4DD",
		"source": "https://en.wikipedia.org/wiki/File:MiHoYo.svg"
	},
	{
		"title": "MikroTik",
		"hex": "293239",
		"source": "https://mikrotik.com/aboutus"
	},
	{
		"title": "Milanote",
		"hex": "31303A",
		"source": "https://milanote.com"
	},
	{
		"title": "Milvus",
		"hex": "00A1EA",
		"source": "https://github.com/milvus-io/artwork/blob/e30bffa2b0632b0d4cefcdd4e1a2c09fee5b0d28/icon/black/milvus-icon-black.svg"
	},
	{
		"title": "Minds",
		"hex": "FED12F",
		"source": "https://www.minds.com/branding",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Minetest",
		"hex": "53AC56",
		"source": "https://www.minetest.net"
	},
	{
		"title": "MinGW-w64",
		"hex": "000000",
		"source": "https://www.mingw-w64.org"
	},
	{
		"title": "Mini",
		"hex": "000000",
		"source": "https://mini.com"
	},
	{
		"title": "MinIO",
		"hex": "C72E49",
		"source": "https://min.io",
		"guidelines": "https://min.io/logo"
	},
	{
		"title": "Mintlify",
		"hex": "18E299",
		"source": "https://mintlify.com"
	},
	{
		"title": "Minutemailer",
		"hex": "30B980",
		"source": "https://minutemailer.com"
	},
	{
		"title": "Miraheze",
		"hex": "FFFC00",
		"source": "https://miraheze.org"
	},
	{
		"title": "Miro",
		"hex": "050038",
		"source": "https://miro.com"
	},
	{
		"title": "Misskey",
		"hex": "A1CA03",
		"source": "https://misskey-hub.net/appendix/assets.html",
		"license": {
			"type": "CC-BY-NC-SA-4.0"
		}
	},
	{
		"title": "Mitsubishi",
		"hex": "E60012",
		"source": "https://www.mitsubishi.com"
	},
	{
		"title": "Mix",
		"hex": "FF8126",
		"source": "https://mix.com"
	},
	{
		"title": "Mixcloud",
		"hex": "5000FF",
		"source": "https://www.mixcloud.com/about",
		"guidelines": "https://www.mixcloud.com/about"
	},
	{
		"title": "Mixpanel",
		"hex": "7856FF",
		"source": "https://mixpanel.com",
		"guidelines": "https://brand.mixpanel.com"
	},
	{
		"title": "MLB",
		"hex": "041E42",
		"source": "https://www.mlb.com",
		"aliases": {
			"aka": [
				"Major League Baseball"
			]
		}
	},
	{
		"title": "MLflow",
		"hex": "0194E2",
		"source": "https://github.com/mlflow/mlflow/blob/855881f93703b15ffe643003fb4d7c84f0ec2502/assets/icon.svg"
	},
	{
		"title": "MobX",
		"hex": "FF9955",
		"source": "https://github.com/mobxjs/mobx/blob/248e25e37af31c2e71ff452bc662a85816fa40d8/docs/assets/mobservable.svg"
	},
	{
		"title": "MobX-State-Tree",
		"hex": "FF7102",
		"source": "https://github.com/mobxjs/mobx-state-tree/blob/666dabd60a7fb87faf83d177c14f516481b5f141/website/static/img/mobx-state-tree-logo.svg"
	},
	{
		"title": "Mocha",
		"hex": "8D6748",
		"source": "https://mochajs.org"
	},
	{
		"title": "Mock Service Worker",
		"hex": "FF6A33",
		"source": "https://github.com/mswjs/msw/blob/9c53bd23040307d41b5b0b7cec1bf3a05950dbc8/media/msw-logo-black.svg"
	},
	{
		"title": "Modal",
		"hex": "7FEE64",
		"source": "https://modal.com"
	},
	{
		"title": "Modin",
		"hex": "001729",
		"source": "https://modin.org"
	},
	{
		"title": "Modrinth",
		"hex": "00AF5C",
		"source": "https://github.com/modrinth/art/blob/d5ab4f965b0b4cea7201967483885ecd8d04a562/Branding/Favicon/favicon.svg"
	},
	{
		"title": "MODX",
		"hex": "102C53",
		"source": "https://docs.modx.com"
	},
	{
		"title": "Mojeek",
		"hex": "7AB93C",
		"source": "https://www.mojeek.com/logos",
		"guidelines": "https://www.mojeek.com/logos"
	},
	{
		"title": "Moleculer",
		"hex": "3CAFCE",
		"source": "https://moleculer.services"
	},
	{
		"title": "Momenteo",
		"hex": "5A6AB1",
		"source": "https://www.momenteo.com/media"
	},
	{
		"title": "Monero",
		"hex": "FF6600",
		"source": "https://www.getmonero.org/press-kit",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "MoneyGram",
		"hex": "DA291C",
		"source": "https://moneygram.com"
	},
	{
		"title": "MongoDB",
		"hex": "47A248",
		"source": "https://www.mongodb.com/pressroom"
	},
	{
		"title": "Mongoose",
		"hex": "880000",
		"source": "https://github.com/Automattic/mongoose/blob/7971a4dbd55888f0b005e65b06024109af8352f7/docs/images/mongoose.svg"
	},
	{
		"title": "Mongoose",
		"slug": "mongoosedotws",
		"hex": "F04D35",
		"source": "https://mongoose.ws"
	},
	{
		"title": "Monica",
		"hex": "2C2B29",
		"source": "https://github.com/monicahq/monica/blob/d7886cc6fd11388a95b7504e1a5363ecc7ad9a59/public/img/monica.svg"
	},
	{
		"title": "monkey tie",
		"hex": "1A52C2",
		"source": "https://www.monkey-tie.com"
	},
	{
		"title": "Monkeytype",
		"hex": "E2B714",
		"source": "https://github.com/monkeytypegame/monkeytype/blob/20a08d27ead851bbfd5ac557b4ea444ea8bddd79/frontend/static/html/top.html",
		"license": {
			"type": "GPL-3.0-only"
		}
	},
	{
		"title": "MonoGame",
		"hex": "E73C00",
		"source": "https://www.monogame.net"
	},
	{
		"title": "Monoprix",
		"hex": "FB1911",
		"source": "https://www.monoprix.fr"
	},
	{
		"title": "Monster",
		"hex": "6D4C9F",
		"source": "https://www.monster.com/press/"
	},
	{
		"title": "Monzo",
		"hex": "14233C",
		"source": "https://monzo.com/press/"
	},
	{
		"title": "Moo",
		"hex": "00945E",
		"source": "https://www.moo.com/uk/about/press"
	},
	{
		"title": "Moodle",
		"hex": "F98012",
		"source": "https://moodle.com/trademarks",
		"guidelines": "https://moodle.com/trademarks"
	},
	{
		"title": "Moonrepo",
		"hex": "6F53F3",
		"source": "https://moonrepo.dev"
	},
	{
		"title": "Moq",
		"hex": "F4BE00",
		"source": "https://github.com/devlooped/moq/blob/1f31df466bf5513b32ef0a0338e242bc51180c7f/assets/img/moq-icon.png"
	},
	{
		"title": "Moqups",
		"hex": "006BE5",
		"source": "https://app.moqups.com"
	},
	{
		"title": "Morrisons",
		"hex": "007531",
		"source": "https://groceries.morrisons.com"
	},
	{
		"title": "Moscow Metro",
		"hex": "D9232E",
		"source": "https://mosmetro.ru"
	},
	{
		"title": "Motorola",
		"hex": "E1140A",
		"source": "https://motorola-global-portal-de.custhelp.com"
	},
	{
		"title": "Movistar",
		"hex": "019DF4",
		"source": "https://www.movistar.com.co",
		"guidelines": "https://brandfactory.telefonica.com/document/4201#/movistar/mision-y-valores"
	},
	{
		"title": "Mozilla",
		"hex": "161616",
		"source": "https://brand.mozilla.com/document/36",
		"guidelines": "https://brand.mozilla.com"
	},
	{
		"title": "mpv",
		"hex": "691F69",
		"source": "https://github.com/mpv-player/mpv/blob/da400ed3a9b54408d1b5112855a7281380a1ef52/etc/mpv.svg"
	},
	{
		"title": "MQTT",
		"hex": "660066",
		"source": "https://mqtt.org"
	},
	{
		"title": "MSI",
		"hex": "FF0000",
		"source": "https://www.msi.com/page/brochure",
		"aliases": {
			"aka": [
				"Micro-Star International"
			]
		}
	},
	{
		"title": "MSI Business",
		"hex": "9A8555",
		"source": "https://www.msi.com/Business-Productivity"
	},
	{
		"title": "MTA",
		"hex": "0039A6",
		"source": "https://mta.info"
	},
	{
		"title": "MTR",
		"hex": "AC2E45",
		"source": "https://commons.wikimedia.org/wiki/File:MTR_(logo_with_text).svg"
	},
	{
		"title": "MUBI",
		"hex": "000000",
		"source": "https://mubi.com"
	},
	{
		"title": "MUI",
		"hex": "007FFF",
		"source": "https://github.com/mui-org/material-ui/blob/353cecb5391571163eb6bd8cbf36d2dd299aaf56/docs/src/icons/SvgMuiLogo.tsx",
		"aliases": {
			"aka": [
				"Material-UI"
			]
		}
	},
	{
		"title": "Mulesoft",
		"hex": "00A0DF",
		"source": "https://www.mulesoft.com/brand",
		"guidelines": "https://www.mulesoft.com/brand"
	},
	{
		"title": "Müller",
		"hex": "F46519",
		"source": "https://www.mueller.de"
	},
	{
		"title": "Mullvad",
		"hex": "294D73",
		"source": "https://mullvad.net/press#logos",
		"guidelines": "https://mullvad.net/press",
		"aliases": {
			"aka": [
				"Mullvad VPN"
			]
		}
	},
	{
		"title": "Multisim",
		"hex": "57B685",
		"source": "https://www.multisim.com",
		"guidelines": "https://www.ni.com/en-us/about-ni/legal.html"
	},
	{
		"title": "Mumble",
		"hex": "000000",
		"source": "https://github.com/mumble-voip/mumble/blob/d40a19eb88cda61084da245a1b6cb8f32ef1b6e4/icons/mumble_small.svg",
		"guidelines": "https://github.com/mumble-voip/mumble/blob/d40a19eb88cda61084da245a1b6cb8f32ef1b6e4/LICENSE"
	},
	{
		"title": "MUO",
		"hex": "C60D0D",
		"source": "https://www.makeuseof.com",
		"aliases": {
			"aka": [
				"MakeUseOf"
			]
		}
	},
	{
		"title": "Mural",
		"hex": "FF4B4B",
		"source": "https://www.mural.co/brand-assets",
		"guidelines": "https://www.mural.co/brand-assets"
	},
	{
		"title": "MuseScore",
		"hex": "1A70B8",
		"source": "https://musescore.org/en/about/logos-and-graphics"
	},
	{
		"title": "MusicBrainz",
		"hex": "BA478F",
		"source": "https://metabrainz.org/projects"
	},
	{
		"title": "MX Linux",
		"hex": "000000",
		"source": "https://mxlinux.org/art/",
		"license": {
			"type": "GPL-3.0-only"
		}
	},
	{
		"title": "MyAnimeList",
		"hex": "2E51A2",
		"source": "https://myanimelist.net/forum/?topicid=1575618"
	},
	{
		"title": "MyGet",
		"hex": "0C79CE",
		"source": "https://docs.myget.org"
	},
	{
		"title": "MYOB",
		"hex": "6100A5",
		"source": "https://myob-identikit.frontify.com/d/JK2D4WFOdAwV/for-developers"
	},
	{
		"title": "Myspace",
		"hex": "030303",
		"source": "https://myspace.com"
	},
	{
		"title": "MySQL",
		"hex": "4479A1",
		"source": "https://www.mysql.com/about/legal/logos.html",
		"guidelines": "https://www.mysql.com/about/legal/logos.html"
	},
	{
		"title": "N26",
		"hex": "48AC98",
		"source": "https://n26.com"
	},
	{
		"title": "n8n",
		"hex": "EA4B71",
		"source": "https://n8n.io/press"
	},
	{
		"title": "Namebase",
		"hex": "0068FF",
		"source": "https://www.namebase.io"
	},
	{
		"title": "Namecheap",
		"hex": "DE3723",
		"source": "https://www.namecheap.com"
	},
	{
		"title": "NameMC",
		"hex": "12161A",
		"source": "https://namemc.com"
	},
	{
		"title": "NameSilo",
		"hex": "031B4E",
		"source": "https://www.namesilo.com/support/v2"
	},
	{
		"title": "Namu Wiki",
		"hex": "008275",
		"source": "https://namu.wiki/w/%ED%8C%8C%EC%9D%BC:%EB%82%98%EB%AC%B4%EC%9C%84%ED%82%A4%20%EC%95%84%EC%9D%B4%EC%BD%98.svg",
		"aliases": {
			"loc": {
				"ko-KR": "나무위키"
			}
		}
	},
	{
		"title": "Nano",
		"hex": "4A90E2",
		"source": "https://nano.org/resources",
		"guidelines": "https://nano.org/resources"
	},
	{
		"title": "Nano Stores",
		"hex": "000000",
		"source": "https://github.com/nanostores/nanostores/blob/7fb5cd871fa00f484ebc866fdf330b56cab2aa20/img/logo-auto.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Napster",
		"hex": "2259FF",
		"source": "https://www.napster.com/us/wp-content/uploads/sites/5/2022/03/logo-napster.svg"
	},
	{
		"title": "NASA",
		"hex": "E03C31",
		"source": "https://commons.wikimedia.org/wiki/File:NASA_Worm_logo.svg",
		"guidelines": "https://www.nasa.gov/multimedia/guidelines/index.html"
	},
	{
		"title": "National Grid",
		"hex": "00148C",
		"source": "https://www.nationalgrid.com"
	},
	{
		"title": "National Rail",
		"hex": "003366",
		"source": "https://www.nationalrailguidelines.co.uk",
		"guidelines": "https://www.nationalrailguidelines.co.uk"
	},
	{
		"title": "NativeScript",
		"hex": "65ADF1",
		"source": "https://docs.nativescript.org"
	},
	{
		"title": "NATS.io",
		"hex": "27AAE1",
		"source": "https://github.com/cncf/artwork/blob/88bc5e7a0cc7f3770ba6edddc92e1ab8a6006171/projects/nats/icon/black/nats-icon-black.svg"
	},
	{
		"title": "Naver",
		"hex": "03C75A",
		"source": "https://developers.naver.com/docs/login/bi/bi.md",
		"guidelines": "https://developers.naver.com/docs/login/bi/bi.md",
		"aliases": {
			"loc": {
				"ja-JP": "ネイバー",
				"ko-KR": "네이버"
			}
		}
	},
	{
		"title": "NBA",
		"hex": "253B73",
		"source": "https://nba.com"
	},
	{
		"title": "NBB",
		"hex": "FF7100",
		"source": "https://presse.notebooksbilliger.de/presskits/style-guide"
	},
	{
		"title": "NBC",
		"hex": "222222",
		"source": "https://www.nbcnews.com"
	},
	{
		"title": "NDR",
		"hex": "0C1754",
		"source": "https://www.ndr.de"
	},
	{
		"title": "NEAR",
		"hex": "000000",
		"source": "https://near.org/brand"
	},
	{
		"title": "Nebula",
		"hex": "2CADFE",
		"source": "https://nebula.tv"
	},
	{
		"title": "NEC",
		"hex": "1414A0",
		"source": "https://commons.wikimedia.org/wiki/File:NEC_logo.svg"
	},
	{
		"title": "Neo4j",
		"hex": "4581C3",
		"source": "https://neo4j.com/brand/#logo",
		"guidelines": "https://neo4j.com/brand/#logo"
	},
	{
		"title": "Neovim",
		"hex": "57A143",
		"source": "https://neovim.io",
		"license": {
			"type": "CC-BY-SA-3.0"
		}
	},
	{
		"title": "Neptune",
		"hex": "5B69C2",
		"source": "https://neptune.ai"
	},
	{
		"title": "NestJS",
		"hex": "E0234E",
		"source": "https://nestjs.com"
	},
	{
		"title": "NetApp",
		"hex": "0067C5",
		"source": "https://www.netapp.com",
		"guidelines": "https://www.netapp.com/company/legal/trademark-guidelines/"
	},
	{
		"title": "NetBSD",
		"hex": "FF6600",
		"source": "https://www.netbsd.org",
		"guidelines": "https://www.netbsd.org/about/disclaimer.html"
	},
	{
		"title": "netcup",
		"hex": "056473",
		"source": "https://www.netcup.de/static/assets/images/favicons/favicon.svg",
		"guidelines": "https://www.netcup.eu/ueber-netcup/werbemittel"
	},
	{
		"title": "Netdata",
		"hex": "00AB44",
		"source": "https://www.netdata.cloud"
	},
	{
		"title": "NetEase Cloud Music",
		"hex": "D43C33",
		"source": "https://y.music.163.com/m",
		"aliases": {
			"loc": {
				"zh-CN": "网易云音乐"
			}
		}
	},
	{
		"title": "Netflix",
		"hex": "E50914",
		"source": "https://brand.netflix.com/en/assets/brand-symbol",
		"guidelines": "https://brand.netflix.com/en/assets/brand-symbol"
	},
	{
		"title": "NETGEAR",
		"hex": "2C262D",
		"source": "https://www.powershift.netgear.de/images/powershift/collateral/logos-visio-icons/brandguideline_partner_2018.pdf",
		"guidelines": "https://www.netgear.com/about/trademarks"
	},
	{
		"title": "Netlify",
		"hex": "00C7B7",
		"source": "https://www.netlify.com/press/",
		"guidelines": "https://www.netlify.com/press/",
		"aliases": {
			"dup": [
				{
					"title": "Netlify CMS",
					"hex": "C9FA4B",
					"source": "https://www.netlifycms.org"
				}
			]
		}
	},
	{
		"title": "Nette",
		"hex": "3484D2",
		"source": "https://nette.org/en/logo",
		"guidelines": "https://nette.org/en/logo"
	},
	{
		"title": "Netto",
		"hex": "FFE500",
		"source": "https://www.netto-online.de/INTERSHOP/static/WFS/Plus-NettoDE-Site/-/-/de_DE/css/images/netto-logo.svg"
	},
	{
		"title": "Neutralinojs",
		"hex": "F89901",
		"source": "https://github.com/neutralinojs/design-guide/blob/52a7232598ff22cddd810a3079e09a2cc2892609/logo/neutralinojs_logo_vector.svg"
	},
	{
		"title": "New Balance",
		"hex": "CF0A2C",
		"source": "https://www.newbalance.com"
	},
	{
		"title": "New Japan Pro-Wrestling",
		"hex": "FF160B",
		"source": "https://en.wikipedia.org/wiki/File:NJPW_World_Logo.svg",
		"aliases": {
			"aka": [
				"NJPW"
			],
			"dup": [
				{
					"title": "NJPW World",
					"hex": "B79C65",
					"source": "https://njpwworld.com"
				}
			],
			"loc": {
				"ja-JP": "新日本プロレスリング"
			}
		}
	},
	{
		"title": "New Relic",
		"hex": "1CE783",
		"source": "https://newrelic.com/about/media-assets",
		"guidelines": "https://newrelic.com/about/media-assets#guidelines"
	},
	{
		"title": "New York Times",
		"hex": "000000",
		"source": "https://www.nytimes.com"
	},
	{
		"title": "Newegg",
		"hex": "E05E00",
		"source": "https://www.newegg.com"
	},
	{
		"title": "NEXON",
		"hex": "000000",
		"source": "https://brand.nexon.com/en/ci-brand-guidelines/primary-identity",
		"guidelines": "https://brand.nexon.com"
	},
	{
		"title": "Next.js",
		"hex": "000000",
		"source": "https://vercel.com/design/brands#next-js",
		"guidelines": "https://vercel.com/design/brands#next-js"
	},
	{
		"title": "NextBillion.ai",
		"hex": "8D5A9E",
		"source": "https://nextbillion.ai"
	},
	{
		"title": "Nextcloud",
		"hex": "0082C9",
		"source": "https://nextcloud.com/press/",
		"guidelines": "https://nextcloud.com/trademarks/"
	},
	{
		"title": "NextDNS",
		"hex": "007BFF",
		"source": "https://github.com/simple-icons/simple-icons/pull/9150#issuecomment-1856317201"
	},
	{
		"title": "Nextdoor",
		"hex": "8ED500",
		"source": "https://about.nextdoor.com/us-media/"
	},
	{
		"title": "Nextflow",
		"hex": "0DC09D",
		"source": "https://github.com/seqeralabs/logos/blob/a8d4906b8fa7359541e520882f93a4bf029af44c/nextflow/nextflow_icon_color.svg"
	},
	{
		"title": "Nextra",
		"hex": "000000",
		"source": "https://nextra.site",
		"guidelines": "https://nextra.site/about#design-assets"
	},
	{
		"title": "NextUI",
		"hex": "000000",
		"source": "https://nextui.org/figma",
		"guidelines": "https://www.figma.com/community/file/1267584376234254760"
	},
	{
		"title": "Nexus Mods",
		"hex": "E6832B",
		"source": "https://wiki.nexusmods.com/skins/Metrolook/images/nexuslogo.svg"
	},
	{
		"title": "nf-core",
		"hex": "24B064",
		"source": "https://github.com/nf-core/logos/blob/c9c0e328d2a1b2b584a017d97cae0921ab998299/nf-core-logos/nf-core-logo-square-mono.svg",
		"guidelines": "https://nf-co.re/docs/guidelines/graphic_design/logo"
	},
	{
		"title": "NFC",
		"hex": "002E5F",
		"source": "https://nfc-forum.org/our-work/nfc-branding/n-mark/guidelines-and-brand-assets/",
		"guidelines": "https://nfc-forum.org/our-work/nfc-branding/n-mark/guidelines-and-brand-assets/"
	},
	{
		"title": "NGINX",
		"hex": "009639",
		"source": "https://www.nginx.com/press/",
		"guidelines": "https://www.nginx.com/press/"
	},
	{
		"title": "Nginx Proxy Manager",
		"hex": "F15833",
		"source": "https://github.com/NginxProxyManager/nginx-proxy-manager/blob/2a06384a4aa597777931d38cef49cf89540392e6/docs/.vuepress/public/logo.svg"
	},
	{
		"title": "ngrok",
		"hex": "1F1E37",
		"source": "https://ngrok.com"
	},
	{
		"title": "NgRx",
		"hex": "BA2BD2",
		"source": "https://ngrx.io",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "NHL",
		"hex": "000000",
		"source": "https://www.nhl.com",
		"aliases": {
			"aka": [
				"National Hockey League"
			]
		}
	},
	{
		"title": "NiceHash",
		"hex": "FBC342",
		"source": "https://www.nicehash.com/nicehash-media",
		"guidelines": "https://www.nicehash.com/nicehash-media"
	},
	{
		"title": "niconico",
		"hex": "231815",
		"source": "https://www.nicovideo.jp"
	},
	{
		"title": "Nike",
		"hex": "111111",
		"source": "https://www.nike.com"
	},
	{
		"title": "Nikon",
		"hex": "FFE100",
		"source": "https://www.nikon.com",
		"guidelines": "https://www.nikon.com/usage/group-info"
	},
	{
		"title": "Nim",
		"hex": "FFE953",
		"source": "https://nim-lang.org"
	},
	{
		"title": "Nissan",
		"hex": "C3002F",
		"source": "https://www.nissan.ie"
	},
	{
		"title": "NixOS",
		"hex": "5277C3",
		"source": "https://github.com/NixOS/nixos-homepage/tree/58cfdb770aba28b73446a1b3ee65a5cec4f0d44f/logo"
	},
	{
		"title": "Node-RED",
		"hex": "8F0000",
		"source": "https://nodered.org/about/resources/"
	},
	{
		"title": "Node.js",
		"hex": "5FA04E",
		"source": "https://nodejs.org/en/about/branding",
		"guidelines": "https://nodejs.org/en/about/branding"
	},
	{
		"title": "Nodemon",
		"hex": "76D04B",
		"source": "https://nodemon.io"
	},
	{
		"title": "Nokia",
		"hex": "005AFF",
		"source": "https://www.nokia.com"
	},
	{
		"title": "Nomad",
		"hex": "00CA8E",
		"source": "https://www.hashicorp.com/brand",
		"guidelines": "https://www.hashicorp.com/brand"
	},
	{
		"title": "Norco",
		"hex": "00FF00",
		"source": "https://www.norco.com"
	},
	{
		"title": "Nordic Semiconductor",
		"hex": "00A9CE",
		"source": "https://www.nordicsemi.com"
	},
	{
		"title": "NordVPN",
		"hex": "4687FF",
		"source": "https://nordvpn.com/press-area/",
		"guidelines": "https://nordvpn.com/press-area/"
	},
	{
		"title": "Normalize.css",
		"hex": "E3695F",
		"source": "https://github.com/necolas/normalize.css/blob/3a60304f90870c6087d226f53e02a7523c907a35/logo.svg"
	},
	{
		"title": "Norton",
		"hex": "FFE01A",
		"source": "https://us.norton.com"
	},
	{
		"title": "Norwegian",
		"hex": "D81939",
		"source": "https://www.norwegian.com/ie/travel-info/on-board/in-flight-entertainment/magazine/"
	},
	{
		"title": "Notepad++",
		"hex": "90E59A",
		"source": "https://github.com/notepad-plus-plus/notepad-plus-plus/blob/1f2c63cce173e3e1dc5922637c81a851693e2856/PowerEditor/misc/chameleon/chameleon-pencil.eps"
	},
	{
		"title": "Notion",
		"hex": "000000",
		"source": "https://www.notion.so"
	},
	{
		"title": "Notist",
		"hex": "333333",
		"source": "https://noti.st"
	},
	{
		"title": "Noun Project",
		"hex": "000000",
		"source": "https://thenounproject.com"
	},
	{
		"title": "Novu",
		"hex": "000000",
		"source": "https://handbook.novu.co/logos-assets"
	},
	{
		"title": "NOW",
		"hex": "001211",
		"source": "https://www.nowtv.com"
	},
	{
		"title": "npm",
		"hex": "CB3837",
		"source": "https://www.npmjs.com",
		"guidelines": "https://docs.npmjs.com/policies/logos-and-usage"
	},
	{
		"title": "Nrwl",
		"hex": "96D7E8",
		"source": "https://nrwl.io"
	},
	{
		"title": "NSIS",
		"hex": "01B0F0",
		"source": "https://github.com/idleberg/nsis-logo/blob/885ba2fd08a6ff450c6f7cbd675563b5df728d38/src/Logo/below%2024x24/mono-flat.svg",
		"aliases": {
			"aka": [
				"Nullsoft Scriptable Install System"
			]
		}
	},
	{
		"title": "ntfy",
		"hex": "317F6F",
		"source": "https://ntfy.sh"
	},
	{
		"title": "Nubank",
		"hex": "820AD1",
		"source": "https://nubank.com.br/en/press/"
	},
	{
		"title": "Nucleo",
		"hex": "252B2D",
		"source": "https://nucleoapp.com"
	},
	{
		"title": "NuGet",
		"hex": "004880",
		"source": "https://github.com/NuGet/Media/blob/89f7c87245e52e8ce91d94c0a47f44c6576e3a0d/Images/MainLogo/Vector/nuget.svg"
	},
	{
		"title": "Nuke",
		"hex": "000000",
		"source": "https://www.foundry.com/products/nuke"
	},
	{
		"title": "Numba",
		"hex": "00A3E0",
		"source": "https://github.com/numba/numba/blob/0db8a2bcd0f53c0d0ad8a798432fb3f37f14af27/docs/_static/numba-blue-icon-rgb.svg"
	},
	{
		"title": "NumPy",
		"hex": "013243",
		"source": "https://numpy.org/press-kit/",
		"guidelines": "https://github.com/numpy/numpy/blob/main/branding/logo/logoguidelines.md"
	},
	{
		"title": "Nunjucks",
		"hex": "1C4913",
		"source": "https://github.com/mozilla/nunjucks/blob/fd500902d7c88672470c87170796de52fc0f791a/docs/img/favicon.png"
	},
	{
		"title": "Nushell",
		"hex": "4E9A06",
		"source": "https://github.com/nushell/nushell/blob/3016d7a64ccb2c2eac9f735f6144fc896ea724a5/assets/icons/nushell-original.png"
	},
	{
		"title": "Nutanix",
		"hex": "024DA1",
		"source": "https://www.nutanix.com/content/dam/nutanix/en/cmn/documents/nutanix-brandbook.pdf"
	},
	{
		"title": "Nuxt",
		"hex": "00DC82",
		"source": "https://nuxt.com/design-kit",
		"guidelines": "https://nuxt.com/design-kit",
		"aliases": {
			"aka": [
				"Nuxt.js"
			]
		}
	},
	{
		"title": "NVIDIA",
		"hex": "76B900",
		"source": "https://www.nvidia.com/en-us"
	},
	{
		"title": "nvm",
		"hex": "F4DD4B",
		"source": "https://github.com/nvm-sh/logos/blob/bf1f9618e83e5098024b18c73ada1b0f542db5f8/nvm-logo-black.svg"
	},
	{
		"title": "Nx",
		"hex": "143055",
		"source": "https://nx.dev"
	},
	{
		"title": "NXP",
		"hex": "000000",
		"source": "https://www.nxp.com/company/about-nxp/newsroom:NEWSROOM",
		"guidelines": "https://www.nxp.com/company/about-nxp/newsroom:NEWSROOM"
	},
	{
		"title": "NZXT",
		"hex": "000000",
		"source": "https://nzxt.com",
		"guidelines": "https://nzxt.com/about/brand-guidelines"
	},
	{
		"title": "O'Reilly",
		"hex": "D3002D",
		"source": "https://www.oreilly.com/about/logos/",
		"guidelines": "https://www.oreilly.com/about/logos/"
	},
	{
		"title": "O2",
		"hex": "0050FF",
		"source": "https://www.telefonica.de/presse/fotos/logos.html",
		"guidelines": "https://www.telefonica.de/presse/fotos/logos.html"
	},
	{
		"title": "ÖBB",
		"hex": "E40327",
		"source": "https://presse.oebb.at/de/fotos-videos/oebb-logos",
		"aliases": {
			"aka": [
				"Österreichische Bundesbahnen"
			]
		}
	},
	{
		"title": "OBS Studio",
		"hex": "302E31",
		"source": "https://commons.wikimedia.org/wiki/File:OBS.svg"
	},
	{
		"title": "Observable",
		"hex": "353E58",
		"source": "https://observablehq.com"
	},
	{
		"title": "Obsidian",
		"hex": "7C3AED",
		"source": "https://obsidian.md",
		"guidelines": "https://obsidian.md/brand"
	},
	{
		"title": "Obtainium",
		"hex": "D2BCFD",
		"source": "https://github.com/ImranR98/Obtainium/blob/e5afe7521347c73382534a013c070b9c1da716c5/assets/graphics/icon.svg"
	},
	{
		"title": "OCaml",
		"hex": "EC6813",
		"source": "https://ocaml.org/logo",
		"guidelines": "https://ocaml.org/logo",
		"license": {
			"type": "Unlicense"
		}
	},
	{
		"title": "OCLC",
		"hex": "007DBA",
		"source": "https://oclc.org",
		"guidelines": "https://oclc.org/en/news/media-kit.html"
	},
	{
		"title": "oclif",
		"hex": "000000",
		"source": "https://github.com/oclif/oclif.github.io/blob/2356a96dbaf0d3791ec2ddce3b08ccd78408e0a0/website/static/img/oclif.svg"
	},
	{
		"title": "Octane Render",
		"hex": "000000",
		"source": "https://render.otoy.com/forum/viewtopic.php?f=9&t=359",
		"aliases": {
			"aka": [
				"otoy"
			]
		}
	},
	{
		"title": "Octave",
		"hex": "0790C0",
		"source": "https://www.gnu.org/software/octave/"
	},
	{
		"title": "October CMS",
		"hex": "DB6A26",
		"source": "https://octobercms.com"
	},
	{
		"title": "OctoPrint",
		"hex": "13C100",
		"source": "https://github.com/OctoPrint/OctoPrint/blob/53b9b6185781c07e8c4744a6e28462e96448f249/src/octoprint/static/img/mask.svg"
	},
	{
		"title": "Octopus Deploy",
		"hex": "2F93E0",
		"source": "https://octopus.com/company/brand",
		"guidelines": "https://octopus.com/company/brand"
	},
	{
		"title": "Oculus",
		"hex": "1C1E20",
		"source": "https://en.facebookbrand.com/oculus/assets/oculus?audience=oculus-landing",
		"guidelines": "https://en.facebookbrand.com/oculus/"
	},
	{
		"title": "Odin",
		"hex": "3882D2",
		"source": "https://github.com/odin-lang/artwork/blob/5f887a73f3cc5a4b61971ec15854ae456b886426/logo/emblem-without-background.svg"
	},
	{
		"title": "Odnoklassniki",
		"hex": "EE8208",
		"source": "https://insideok.ru/brandbook"
	},
	{
		"title": "Odoo",
		"hex": "714B67",
		"source": "https://www.odoo.com/page/brand-assets",
		"guidelines": "https://www.odoo.com/page/brand-assets"
	},
	{
		"title": "Odysee",
		"hex": "EF1970",
		"source": "https://odysee.com/@OdyseeHelp:b/odyseepresskit:b"
	},
	{
		"title": "Oh Dear",
		"hex": "FF3900",
		"source": "https://ohdear.app/logos"
	},
	{
		"title": "okcupid",
		"hex": "0500BE",
		"source": "https://okcupid.com/press"
	},
	{
		"title": "Okta",
		"hex": "007DC1",
		"source": "https://www.okta.com/press-room/media-assets/",
		"guidelines": "https://www.okta.com/terms-of-use-for-okta-content/"
	},
	{
		"title": "OKX",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:OKX_logo.svg"
	},
	{
		"title": "Ollama",
		"hex": "000000",
		"source": "https://github.com/ollama/ollama/issues/2152#issuecomment-1905286922"
	},
	{
		"title": "Omada Cloud",
		"hex": "10C1D0",
		"source": "https://omada.tplinkcloud.com"
	},
	{
		"title": "OnePlus",
		"hex": "F5010C",
		"source": "https://www.oneplus.com/ca_en/brand/asset"
	},
	{
		"title": "OnlyFans",
		"hex": "00AFF0",
		"source": "https://onlyfans.com/brand",
		"guidelines": "https://onlyfans.com/brand"
	},
	{
		"title": "ONLYOFFICE",
		"hex": "444444",
		"source": "https://www.onlyoffice.com/en/press-downloads.aspx"
	},
	{
		"title": "ONNX",
		"hex": "005CED",
		"source": "https://github.com/onnx/onnx.github.io/blob/382e7036b616ce1555499ac41730245a2478513c/images/ONNX-ICON.svg"
	},
	{
		"title": "OnStar",
		"hex": "003D7D",
		"source": "https://www.onstar.com"
	},
	{
		"title": "Opel",
		"hex": "F7FF14",
		"source": "https://www.stellantis.com/en/brands/opel"
	},
	{
		"title": "Open Access",
		"hex": "F68212",
		"source": "https://commons.wikimedia.org/wiki/File:Open_Access_logo_PLoS_white.svg"
	},
	{
		"title": "Open Badges",
		"hex": "073B5A",
		"source": "https://backpack.openbadges.org"
	},
	{
		"title": "Open Bug Bounty",
		"hex": "F67909",
		"source": "https://www.openbugbounty.org"
	},
	{
		"title": "Open Collective",
		"hex": "7FADF2",
		"source": "https://docs.opencollective.com/help/about#media-logo"
	},
	{
		"title": "Open Containers Initiative",
		"hex": "262261",
		"source": "https://github.com/opencontainers/artwork/blob/d8ccfe94471a0236b1d4a3f0f90862c4fe5486ce/oci/icon/black/oci-icon-black.svg"
	},
	{
		"title": "Open Source Hardware",
		"hex": "0099B0",
		"source": "https://www.oshwa.org/open-source-hardware-logo",
		"guidelines": "https://www.oshwa.org/open-source-hardware-logo",
		"license": {
			"type": "CC-BY-SA-4.0"
		},
		"aliases": {
			"aka": [
				"OSHWA"
			]
		}
	},
	{
		"title": "Open Source Initiative",
		"hex": "3DA639",
		"source": "https://opensource.org/logo-usage-guidelines",
		"guidelines": "https://opensource.org/logo-usage-guidelines"
	},
	{
		"title": "Open3D",
		"hex": "000000",
		"source": "https://github.com/isl-org/Open3D/blob/2ae042aa74ad3917afd891e36798ffe687513662/cpp/apps/Open3DViewer/icon.svg"
	},
	{
		"title": "OpenAI",
		"hex": "412991",
		"source": "https://openai.com/brand",
		"guidelines": "https://openai.com/brand"
	},
	{
		"title": "OpenAI Gym",
		"hex": "0081A5",
		"source": "https://gym.openai.com"
	},
	{
		"title": "OpenAPI Initiative",
		"hex": "6BA539",
		"source": "https://www.openapis.org/faq/style-guide",
		"guidelines": "https://www.openapis.org/faq/style-guide"
	},
	{
		"title": "OpenBSD",
		"hex": "F2CA30",
		"source": "https://en.wikipedia.org/wiki/OpenBSD"
	},
	{
		"title": "OpenCV",
		"hex": "5C3EE8",
		"source": "https://opencv.org/resources/media-kit/",
		"guidelines": "https://opencv.org/resources/media-kit/"
	},
	{
		"title": "OpenFaaS",
		"hex": "3B5EE9",
		"source": "https://docs.openfaas.com"
	},
	{
		"title": "OpenGL",
		"hex": "5586A4",
		"source": "https://www.khronos.org/legal/trademarks",
		"guidelines": "https://www.khronos.org/files/legal/Khronos-Logo-Usage-Guide.pdf"
	},
	{
		"title": "openHAB",
		"hex": "E64A19",
		"source": "https://www.openhab.org/artwork.html",
		"guidelines": "https://www.openhab.org/about/trademark.html"
	},
	{
		"title": "OpenID",
		"hex": "F78C40",
		"source": "https://openid.net/add-openid/logos/"
	},
	{
		"title": "OpenJDK",
		"hex": "000000",
		"source": "https://hg.openjdk.java.net/duke/duke/file/ca00f100dafc/vector/Agent.svg#l1"
	},
	{
		"title": "OpenJS Foundation",
		"hex": "0075C9",
		"source": "https://github.com/openjs-foundation/artwork/blob/270575392800eb17a02612203f6f0d5868c634a7/openjs_foundation/openjs_foundation-icon-black.svg",
		"guidelines": "https://trademark-policy.openjsf.org"
	},
	{
		"title": "Openlayers",
		"hex": "1F6B75",
		"source": "https://github.com/openlayers/openlayers.github.io/blob/5b93e18b8d302eb49a812fb96abb529895ceb7a2/assets/logo.svg"
	},
	{
		"title": "openmediavault",
		"hex": "5DACDF",
		"source": "https://github.com/openmediavault/openmediavault/blob/12f8ef70f19f967733b744d6fb6156a4181f1ddc/deb/openmediavault/workbench/src/favicon.svg"
	},
	{
		"title": "OpenMined",
		"hex": "ED986C",
		"source": "https://www.openmined.org",
		"guidelines": "https://www.openmined.org"
	},
	{
		"title": "OpenNebula",
		"hex": "0097C2",
		"source": "https://opennebula.io/docs/"
	},
	{
		"title": "OpenProject",
		"hex": "0770B8",
		"source": "https://www.openproject.org/press/"
	},
	{
		"title": "OpenSCAD",
		"hex": "F9D72C",
		"source": "https://commons.wikimedia.org/wiki/File:Openscad.svg"
	},
	{
		"title": "OpenSea",
		"hex": "2081E2",
		"source": "https://docs.opensea.io"
	},
	{
		"title": "OpenSearch",
		"hex": "005EB8",
		"source": "https://opensearch.org/trademark-brand-policy.html",
		"guidelines": "https://opensearch.org/trademark-brand-policy.html"
	},
	{
		"title": "OpenSSL",
		"hex": "721412",
		"source": "https://www.openssl.org"
	},
	{
		"title": "OpenStack",
		"hex": "ED1944",
		"source": "https://www.openstack.org/brand/openstack-logo/",
		"guidelines": "https://www.openstack.org/brand/openstack-logo/"
	},
	{
		"title": "OpenStreetMap",
		"hex": "7EBC6F",
		"source": "https://www.openstreetmap.org",
		"guidelines": "https://wiki.osmfoundation.org/wiki/Trademark_Policy"
	},
	{
		"title": "openSUSE",
		"hex": "73BA25",
		"source": "https://github.com/openSUSE/artwork/blob/33e94aa76837c09f03d1712705949b71a246a53b/logos/buttons/button-colour.svg",
		"guidelines": "https://en.opensuse.org/Portal:Artwork"
	},
	{
		"title": "OpenTelemetry",
		"hex": "000000",
		"source": "https://cncf-branding.netlify.app/projects/opentelemetry/",
		"guidelines": "https://cncf-branding.netlify.app/projects/opentelemetry/",
		"license": {
			"type": "CC-BY-4.0"
		},
		"aliases": {
			"aka": [
				"OTel"
			]
		}
	},
	{
		"title": "OpenText",
		"hex": "000000",
		"source": "https://www.opentext.com",
		"aliases": {
			"aka": [
				"Micro Focus"
			]
		}
	},
	{
		"title": "OpenTofu",
		"hex": "FFDA18",
		"source": "https://github.com/opentofu/brand-artifacts/blob/0d4d0d6050ca0ff06471400bc3249a64c145f659/symbol-only/transparent/SVG/on-light-mono.svg",
		"aliases": {
			"aka": [
				"OpenTF",
				"Terraform"
			]
		}
	},
	{
		"title": "Openverse",
		"hex": "FFE033",
		"source": "https://github.com/WordPress/openverse/blob/5db2545d6b73ec4aa5e908822683ee9d18af301d/brand/icon.svg",
		"guidelines": "https://www.figma.com/file/GIIQ4sDbaToCfFQyKMvzr8/Openverse-Design-Library?node-id=312%3A487"
	},
	{
		"title": "OpenVPN",
		"hex": "EA7E20",
		"source": "https://openvpn.net",
		"guidelines": "https://openvpn.net/legal"
	},
	{
		"title": "OpenWrt",
		"hex": "00B5E2",
		"source": "https://openwrt.org/docs/guide-graphic-designer/openwrt-logo",
		"guidelines": "https://openwrt.org/docs/guide-graphic-designer/openwrt-logo"
	},
	{
		"title": "OpenZeppelin",
		"hex": "4E5EE4",
		"source": "https://openzeppelin.com"
	},
	{
		"title": "OpenZFS",
		"hex": "2A667F",
		"source": "https://commons.wikimedia.org/wiki/File:OpenZFS_logo.svg"
	},
	{
		"title": "Opera",
		"hex": "FF1B2D",
		"source": "https://brand.opera.com/1472-2/opera-logos/",
		"guidelines": "https://brand.opera.com"
	},
	{
		"title": "Opera GX",
		"hex": "EE2950",
		"source": "https://brand.opera.com/1472-2/opera-logos/",
		"guidelines": "https://brand.opera.com"
	},
	{
		"title": "OPNSense",
		"hex": "D94F00",
		"source": "https://opnsense.org/about/legal-notices/",
		"guidelines": "https://opnsense.org/about/legal-notices/"
	},
	{
		"title": "OPPO",
		"hex": "2D683D",
		"source": "https://www.figma.com/community/file/832815970641696814/OPPO-Media-Kit",
		"guidelines": "https://www.oppo.com/en/terms/"
	},
	{
		"title": "Opsgenie",
		"hex": "172B4D",
		"source": "https://www.atlassian.com/company/news/press-kit"
	},
	{
		"title": "OpsLevel",
		"hex": "0A53E0",
		"source": "https://www.opslevel.com"
	},
	{
		"title": "Optimism",
		"hex": "FF0420",
		"source": "https://github.com/ethereum-optimism/brand-kit/blob/71ea3bb1ea24e87968804b388e99bed0b52e2a4b/assets/svg/Profile-Logo.svg"
	},
	{
		"title": "Orange",
		"hex": "FF7900",
		"source": "https://brand.orange.com",
		"guidelines": "https://system.design.orange.com/0c1af118d/p/494474-guidelines"
	},
	{
		"title": "ORCID",
		"hex": "A6CE39",
		"source": "https://orcid.figshare.com/articles/figure/ORCID_iD_icon_graphics/5008697",
		"guidelines": "https://info.orcid.org/brand-guidelines/"
	},
	{
		"title": "Org",
		"hex": "77AA99",
		"source": "https://orgmode.org"
	},
	{
		"title": "Organic Maps",
		"hex": "006C35",
		"source": "https://organicmaps.app"
	},
	{
		"title": "Origin",
		"hex": "F56C2D",
		"source": "https://www.origin.com/gbr/en-us/store"
	},
	{
		"title": "Osano",
		"hex": "7764FA",
		"source": "https://www.osano.com/company/assets"
	},
	{
		"title": "OSF",
		"hex": "2CB9F1",
		"source": "https://github.com/CenterForOpenScience/osf.io/blob/de170682924278eba1db9d6e1c50166bf43700e0/website/static/img/circle_logo.png",
		"aliases": {
			"aka": [
				"Open Science Framework"
			],
			"dup": [
				{
					"title": "Center for Open Science",
					"source": "https://www.cos.io/initiatives/top-guidelines"
				}
			]
		}
	},
	{
		"title": "OSGeo",
		"hex": "4CB05B",
		"source": "https://www.osgeo.org",
		"guidelines": "https://www.osgeo.org/about/branding-material/"
	},
	{
		"title": "Oshkosh",
		"hex": "E6830F",
		"source": "https://oshkoshdefense.com/media/photos/",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "OsmAnd",
		"hex": "FF8800",
		"source": "https://github.com/osmandapp/OsmAnd-misc/blob/9ec3bacebf580d0862ded5813a4aa934d0862302/logo/osmand/symbol_osmand.svg"
	},
	{
		"title": "OSMC",
		"hex": "17394A",
		"source": "https://github.com/osmc/website/tree/e7d0d8002660c979ae5119e28d1c69c893ac9f76/content/themes/osmc/assets/img/logo"
	},
	{
		"title": "osu!",
		"hex": "FF66AA",
		"source": "https://osu.ppy.sh/wiki/Brand_identity_guidelines",
		"guidelines": "https://osu.ppy.sh/wiki/Brand_identity_guidelines"
	},
	{
		"title": "Otto",
		"hex": "D4021D",
		"source": "https://www.ottogroup.com/en/presse/material.php"
	},
	{
		"title": "Outline",
		"hex": "000000",
		"source": "https://www.getoutline.com"
	},
	{
		"title": "Overcast",
		"hex": "FC7E0F",
		"source": "https://overcast.fm"
	},
	{
		"title": "Overleaf",
		"hex": "47A141",
		"source": "https://www.overleaf.com/for/press/media-resources"
	},
	{
		"title": "OVH",
		"hex": "123F6D",
		"source": "https://www.ovh.com/ca/en/newsroom/"
	},
	{
		"title": "OWASP",
		"hex": "000000",
		"source": "https://github.com/OWASP/www-event-2020-07-virtual/blob/eefbef6c1afdd1dee2af11e7f44ad005b25ad48c/assets/images/logo.svg"
	},
	{
		"title": "OWASP Dependency-Check",
		"slug": "dependencycheck",
		"hex": "F78D0A",
		"source": "https://github.com/jeremylong/DependencyCheck/blob/8ee82149179c6faeca78727e57039e987c387e26/src/site/resources/images/logo.svg",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "ownCloud",
		"hex": "041E42",
		"source": "https://owncloud.com"
	},
	{
		"title": "Oxygen",
		"hex": "3A209E",
		"source": "https://oxygenbuilder.com",
		"guidelines": "https://oxygenbuilder.com/trademark-policy/"
	},
	{
		"title": "OYO",
		"hex": "EE2E24",
		"source": "https://www.oyorooms.com"
	},
	{
		"title": "p5.js",
		"hex": "ED225D",
		"source": "https://p5js.org"
	},
	{
		"title": "Packagist",
		"hex": "F28D1A",
		"source": "https://github.com/composer/packagist/issues/1147#issuecomment-747951608",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Packer",
		"hex": "02A8EF",
		"source": "https://www.hashicorp.com/brand",
		"guidelines": "https://www.hashicorp.com/brand"
	},
	{
		"title": "Packt",
		"hex": "F37143",
		"source": "https://www.packtpub.com"
	},
	{
		"title": "Paddle",
		"hex": "FDDD35",
		"source": "https://www.paddle.com"
	},
	{
		"title": "PaddlePaddle",
		"hex": "0062B0",
		"source": "https://www.paddlepaddle.org.cn/en"
	},
	{
		"title": "Paddy Power",
		"hex": "004833",
		"source": "https://www.paddypower.com"
	},
	{
		"title": "Pagekit",
		"hex": "212121",
		"source": "https://pagekit.com/logo-guide",
		"guidelines": "https://pagekit.com/logo-guide"
	},
	{
		"title": "PagerDuty",
		"hex": "06AC38",
		"source": "https://www.pagerduty.com/brand/",
		"guidelines": "https://www.pagerduty.com/brand/"
	},
	{
		"title": "PageSpeed Insights",
		"hex": "4285F4",
		"source": "https://developers.google.com/web/fundamentals/performance/speed-tools/"
	},
	{
		"title": "PagSeguro",
		"hex": "FFC801",
		"source": "https://pagseguro.uol.com.br"
	},
	{
		"title": "Palantir",
		"hex": "101113",
		"source": "https://github.com/palantir/conjure/blob/1b0d450dc52c4822b4c9d1da8c61ad7f78855fe5/docs/media/palantir-logo.svg"
	},
	{
		"title": "Palo Alto Networks",
		"hex": "F04E23",
		"source": "https://www.paloaltonetworks.com",
		"guidelines": "https://www.paloaltonetworks.com/company/brand"
	},
	{
		"title": "Palo Alto Software",
		"hex": "83DA77",
		"source": "https://www.paloalto.com"
	},
	{
		"title": "Panasonic",
		"hex": "0049AB",
		"source": "https://www.panasonic.com",
		"guidelines": "https://holdings.panasonic/global/terms-of-use.html"
	},
	{
		"title": "pandas",
		"hex": "150458",
		"source": "https://pandas.pydata.org/about/citing.html",
		"guidelines": "https://pandas.pydata.org/about/citing.html"
	},
	{
		"title": "Pandora",
		"hex": "224099",
		"source": "https://www.pandoraforbrands.com"
	},
	{
		"title": "Pantheon",
		"hex": "FFDC28",
		"source": "https://projects.invisionapp.com/boards/8UOJQWW2J3G5#/1145336",
		"guidelines": "https://projects.invisionapp.com/boards/8UOJQWW2J3G5#/1145336"
	},
	{
		"title": "Paperless-ngx",
		"hex": "17541F",
		"source": "https://github.com/paperless-ngx/paperless-ngx/blob/e16645b146da24f07004eb772a455450354a37a7/resources/logo/web/svg/square.svg"
	},
	{
		"title": "Papers With Code",
		"hex": "21CBCE",
		"source": "https://paperswithcode.com"
	},
	{
		"title": "Paperspace",
		"hex": "000000",
		"source": "https://docs.paperspace.com/img/ps-logo-light.svg"
	},
	{
		"title": "Paradox Interactive",
		"hex": "101010",
		"source": "https://www.paradoxinteractive.com"
	},
	{
		"title": "Paramount+",
		"hex": "0064FF",
		"source": "https://www.paramount.com/brand/paramount-plus"
	},
	{
		"title": "Parity Substrate",
		"hex": "282828",
		"source": "https://substrate.dev"
	},
	{
		"title": "Parrot Security",
		"hex": "15E0ED",
		"source": "https://gitlab.com/parrotsec/project/documentation/-/blob/d1d426b9cb3ea0efd16a2b34056c1ebb21bb9af9/static/img/parrot-logo.svg"
	},
	{
		"title": "Parse.ly",
		"hex": "5BA745",
		"source": "https://www.parse.ly/press-kit",
		"guidelines": "https://www.parse.ly/press-kit"
	},
	{
		"title": "Passport",
		"hex": "34E27A",
		"source": "https://www.passportjs.org"
	},
	{
		"title": "Pastebin",
		"hex": "02456C",
		"source": "https://pastebin.com"
	},
	{
		"title": "Patreon",
		"hex": "000000",
		"source": "https://www.patreon.com/brand",
		"guidelines": "https://www.patreon.com/brand"
	},
	{
		"title": "Paychex",
		"hex": "004B8D",
		"source": "https://www.paychex.com"
	},
	{
		"title": "Payhip",
		"hex": "5C6AC4",
		"source": "https://payhip.com"
	},
	{
		"title": "Payload CMS",
		"hex": "000000",
		"source": "https://payloadcms.com"
	},
	{
		"title": "Payoneer",
		"hex": "FF4800",
		"source": "https://www.payoneer.com"
	},
	{
		"title": "PayPal",
		"hex": "003087",
		"source": "https://www.paypal.com",
		"guidelines": "https://newsroom.paypal-corp.com/media-resources"
	},
	{
		"title": "Paytm",
		"hex": "20336B",
		"source": "https://paytm.com"
	},
	{
		"title": "PCGamingWiki",
		"hex": "556DB3",
		"source": "https://www.pcgamingwiki.com/wiki/Home"
	},
	{
		"title": "PDM",
		"hex": "AC75D7",
		"source": "https://github.com/pdm-project/pdm/blob/68abaae63e8d8fc8eb0c101285fd7dcb5cd9798a/docs/docs/assets/logo.svg"
	},
	{
		"title": "PDQ",
		"hex": "231F20",
		"source": "https://pdq.com"
	},
	{
		"title": "Peak Design",
		"hex": "1C1B1C",
		"source": "https://www.peakdesign.com"
	},
	{
		"title": "Pearson",
		"hex": "000000",
		"source": "https://www.pearson.com",
		"aliases": {
			"dup": [
				{
					"title": "Pearson VUE",
					"hex": "008FB4"
				}
			]
		}
	},
	{
		"title": "Peerlist",
		"hex": "00AA45",
		"source": "https://peerlist.io",
		"guidelines": "https://peerlist.io/legal/peerlist-terms-conditions.pdf"
	},
	{
		"title": "PeerTube",
		"hex": "F1680D",
		"source": "https://joinpeertube.org",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Pegasus Airlines",
		"hex": "FDC43E",
		"source": "https://www.flypgs.com/en/about-pegasus/flypgscom-magazine"
	},
	{
		"title": "Pelican",
		"hex": "14A0C4",
		"source": "https://blog.getpelican.com/pages/gratitude.html",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "Peloton",
		"hex": "181A1D",
		"source": "https://press.onepeloton.com/#logos"
	},
	{
		"title": "Penny",
		"hex": "CD1414",
		"source": "https://www.penny.de"
	},
	{
		"title": "Penpot",
		"hex": "000000",
		"source": "https://penpot.app"
	},
	{
		"title": "Percy",
		"hex": "9E66BF",
		"source": "https://percy.io"
	},
	{
		"title": "Perforce",
		"hex": "404040",
		"source": "https://www.perforce.com"
	},
	{
		"title": "Perl",
		"hex": "0073A1",
		"source": "https://github.com/metacpan/perl-assets/blob/56b555711934dde8fd0b20ec29ecc3bf81a3d493/blessed/src/010.svg"
	},
	{
		"title": "Perplexity",
		"hex": "1FB8CD",
		"source": "https://www.perplexity.ai"
	},
	{
		"title": "Persistent",
		"hex": "FD5F07",
		"source": "https://www.persistent.com/company-overview/branding-guidelines/#nav-persistent-logo",
		"guidelines": "https://www.persistent.com/company-overview/branding-guidelines/#nav-persistent-logo"
	},
	{
		"title": "Personio",
		"hex": "000000",
		"source": "https://www.personio.com"
	},
	{
		"title": "Pets at Home",
		"hex": "00AA28",
		"source": "https://petsathome.com"
	},
	{
		"title": "Peugeot",
		"hex": "000000",
		"source": "https://www.peugeot.co.uk"
	},
	{
		"title": "Pexels",
		"hex": "05A081",
		"source": "https://www.pexels.com"
	},
	{
		"title": "pfSense",
		"hex": "212121",
		"source": "https://www.pfsense.org"
	},
	{
		"title": "Phabricator",
		"hex": "4A5F88",
		"source": "https://github.com/phacility/phabricator/blob/0a3093ef9c1898913196564435346e4daa9d2538/webroot/rsrc/image/logo/light-eye.png",
		"guidelines": "https://phacility.com/trademarks/"
	},
	{
		"title": "Philips Hue",
		"hex": "0065D3",
		"source": "https://www.philips-hue.com/en-us/support/faq"
	},
	{
		"title": "Phoenix Framework",
		"hex": "FD4F00",
		"source": "https://github.com/phoenixframework/phoenix/blob/e9f1975d5aa15bee22bab6a4acae8f543886b17a/installer/templates/phx_assets/logo.svg"
	},
	{
		"title": "PhonePe",
		"hex": "5F259F",
		"source": "https://www.phonepe.com/press/"
	},
	{
		"title": "Phosphor Icons",
		"hex": "3C402B",
		"source": "https://phosphoricons.com",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Photobucket",
		"hex": "1C47CB",
		"source": "https://photobucket.com"
	},
	{
		"title": "Photocrowd",
		"hex": "3DAD4B",
		"source": "https://www.photocrowd.com"
	},
	{
		"title": "Photon",
		"hex": "004480",
		"source": "https://www.photonengine.com"
	},
	{
		"title": "Photopea",
		"hex": "18A497",
		"source": "https://github.com/photopea/photopea/blob/d5c532e8ad8ece246e2ea8646aac7df768407c64/logo.svg"
	},
	{
		"title": "PHP",
		"hex": "777BB4",
		"source": "https://php.net/download-logos.php",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "phpBB",
		"hex": "009BDF",
		"source": "https://www.phpbb.com/about/logos"
	},
	{
		"title": "phpMyAdmin",
		"hex": "6C78AF",
		"source": "https://github.com/phpmyadmin/data/blob/b7d3bdb9bb973beff4726541b87d3a4c8a950b4b/brand/phpMyAdmin-Logo-Symbol.svg"
	},
	{
		"title": "PhpStorm",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "Pi Network",
		"hex": "F4AF47",
		"source": "https://blockexplorer.minepi.com"
	},
	{
		"title": "Pi-hole",
		"hex": "96060C",
		"source": "https://docs.pi-hole.net",
		"guidelines": "https://pi-hole.net/trademark-rules-and-brand-guidelines/"
	},
	{
		"title": "Piaggio Group",
		"hex": "000000",
		"source": "https://www.piaggiogroup.com",
		"guidelines": "https://www.piaggiogroup.com/en/archive/document/logo-guide"
	},
	{
		"title": "Piapro",
		"hex": "E4007B",
		"source": "https://magicalmirai.com"
	},
	{
		"title": "Picard Surgelés",
		"hex": "2D4999",
		"source": "https://www.picard.fr"
	},
	{
		"title": "Picarto.TV",
		"hex": "1DA456",
		"source": "https://picarto.tv/site/press"
	},
	{
		"title": "Picnic",
		"hex": "E1171E",
		"source": "https://picnic.app/nl/feestdagen/"
	},
	{
		"title": "PicPay",
		"hex": "21C25E",
		"source": "https://www.picpay.com/site/sobre-nos"
	},
	{
		"title": "Picrew",
		"hex": "FFBD16",
		"source": "https://picrew.me"
	},
	{
		"title": "Picsart",
		"hex": "C209C1",
		"source": "https://picsart.com",
		"guidelines": "https://picsart.com/press-kit"
	},
	{
		"title": "Picxy",
		"hex": "2E3192",
		"source": "https://www.picxy.com"
	},
	{
		"title": "Pimcore",
		"hex": "6428B4",
		"source": "https://pimcore.com/en/media-kit",
		"guidelines": "https://pimcore.com/en/media-kit"
	},
	{
		"title": "Pinboard",
		"hex": "0000FF",
		"source": "https://commons.wikimedia.org/wiki/File:Feedbin-Icon-share-pinboard.svg"
	},
	{
		"title": "Pine Script",
		"hex": "00B453",
		"source": "https://github.com/tradingview/documentation-guidelines/blob/0d7a2d014818ebdd03540c5fd7b97fe493cd056c/images/pine/PineScript_logo.svg"
	},
	{
		"title": "Pingdom",
		"hex": "FFF000",
		"source": "https://www.pingdom.com/resources/brand-assets/",
		"guidelines": "https://www.pingdom.com/resources/brand-assets/"
	},
	{
		"title": "pino",
		"hex": "687634",
		"source": "https://github.com/pinojs/pino/blob/bb31ed77568959670cce62ca2847234b3f2cb87f/pino-tree.png"
	},
	{
		"title": "Pinterest",
		"hex": "BD081C",
		"source": "https://business.pinterest.com/en/brand-guidelines",
		"guidelines": "https://business.pinterest.com/en/brand-guidelines"
	},
	{
		"title": "Pioneer DJ",
		"hex": "1A1928",
		"source": "https://www.pioneerdj.com"
	},
	{
		"title": "Piped",
		"hex": "F84330",
		"source": "https://github.com/TeamPiped/Piped/blob/71a3742f18893b87cad15e832855bd2bd7c2b557/public/img/icons/logo.svg"
	},
	{
		"title": "pipx",
		"hex": "2CFFAA",
		"source": "https://github.com/pypa/pipx/blob/fc9c95349cfcec1d886c26b70329257de53e10cb/logo.svg"
	},
	{
		"title": "Pivotal Tracker",
		"hex": "517A9E",
		"source": "https://www.pivotaltracker.com/branding-guidelines",
		"guidelines": "https://www.pivotaltracker.com/branding-guidelines"
	},
	{
		"title": "Piwigo",
		"hex": "FF7700",
		"source": "https://github.com/Piwigo/piwigodotorg/blob/6edb840c16257314caec770a9a51f67ef81836e4/images/piwigo.org.svg"
	},
	{
		"title": "Pix",
		"hex": "77B6A8",
		"source": "https://www.bcb.gov.br/estabilidadefinanceira/pix",
		"guidelines": "https://www.bcb.gov.br/content/estabilidadefinanceira/pix/Regulamento_Pix/I_manual_uso_marca_pix.pdf"
	},
	{
		"title": "Pixabay",
		"hex": "2EC66D",
		"source": "https://pixabay.com/service/about/"
	},
	{
		"title": "Pixelfed",
		"hex": "6366F1",
		"source": "https://pixelfed.org"
	},
	{
		"title": "pixiv",
		"hex": "0096FA",
		"source": "https://policies.pixiv.net/en.html#brand",
		"guidelines": "https://policies.pixiv.net/en.html#brand"
	},
	{
		"title": "Pixlr",
		"hex": "3EBBDF",
		"source": "https://pixlr.com"
	},
	{
		"title": "pkgsrc",
		"hex": "FF6600",
		"source": "https://pkgsrc.org"
	},
	{
		"title": "Planet",
		"hex": "009DB1",
		"source": "https://www.planet.com/explorer/"
	},
	{
		"title": "PlanetScale",
		"hex": "000000",
		"source": "https://planetscale.com"
	},
	{
		"title": "PlanGrid",
		"hex": "0085DE",
		"source": "https://app.plangrid.com"
	},
	{
		"title": "Platform.sh",
		"hex": "1A182A",
		"source": "https://platform.sh/logos/"
	},
	{
		"title": "PlatformIO",
		"hex": "F5822A",
		"source": "https://piolabs.com",
		"guidelines": "https://piolabs.com/legal/trademarks.html#use-of-logos"
	},
	{
		"title": "Platzi",
		"hex": "98CA3F",
		"source": "https://github.com/PlatziDev/oss/blob/932bd83d43e061e1c38fbc116db31aa6d0145be6/static/logo.svg"
	},
	{
		"title": "Plausible Analytics",
		"hex": "5850EC",
		"source": "https://github.com/plausible/docs/blob/be5c935484e075f1e0caf3c9b3351ddd62348139/static/img/logo.svg"
	},
	{
		"title": "PlayCanvas",
		"hex": "E05F2C",
		"source": "https://playcanvas.com"
	},
	{
		"title": "Player FM",
		"hex": "C8122A",
		"source": "https://player.fm"
	},
	{
		"title": "Player.me",
		"hex": "C0379A",
		"source": "https://player.me/p/about-us"
	},
	{
		"title": "PlayStation",
		"hex": "0070D1",
		"source": "https://www.playstation.com/en-us/"
	},
	{
		"title": "PlayStation 2",
		"hex": "003791",
		"source": "https://commons.wikimedia.org/wiki/File:PlayStation_2_logo.svg"
	},
	{
		"title": "PlayStation 3",
		"hex": "003791",
		"source": "https://commons.wikimedia.org/wiki/File:PlayStation_3_Logo_neu.svg#/media/File:PS3.svg"
	},
	{
		"title": "PlayStation 4",
		"hex": "003791",
		"source": "https://commons.wikimedia.org/wiki/File:PlayStation_4_logo_and_wordmark.svg"
	},
	{
		"title": "PlayStation 5",
		"hex": "003791",
		"source": "https://www.playstation.com/en-us/ps5/"
	},
	{
		"title": "PlayStation Portable",
		"hex": "003791",
		"source": "https://commons.wikimedia.org/wiki/File:PSP_Logo.svg",
		"aliases": {
			"aka": [
				"PSP"
			]
		}
	},
	{
		"title": "PlayStation Vita",
		"hex": "003791",
		"source": "https://commons.wikimedia.org/wiki/File:PlayStation_Vita_logo.svg"
	},
	{
		"title": "Pleroma",
		"hex": "FBA457",
		"source": "https://pleroma.social",
		"license": {
			"type": "custom",
			"url": "https://git.pleroma.social/pleroma/pleroma/-/blob/develop/COPYING"
		}
	},
	{
		"title": "Plesk",
		"hex": "52BBE6",
		"source": "https://www.plesk.com/brand/",
		"guidelines": "https://www.plesk.com/brand/"
	},
	{
		"title": "Plex",
		"hex": "EBAF00",
		"source": "https://brand.plex.tv",
		"guidelines": "https://brand.plex.tv"
	},
	{
		"title": "Plotly",
		"hex": "3F4F75",
		"source": "https://plotly.com"
	},
	{
		"title": "Plume",
		"hex": "7C5CDF",
		"source": "https://www.plume.com",
		"guidelines": "https://www.plume.com/legal/trademarks"
	},
	{
		"title": "Pluralsight",
		"hex": "F15B2A",
		"source": "https://www.pluralsight.com/newsroom/brand-assets"
	},
	{
		"title": "Plurk",
		"hex": "FF574D",
		"source": "https://www.plurk.com/brandInfo",
		"guidelines": "https://www.plurk.com/brandInfo"
	},
	{
		"title": "Plus Codes",
		"hex": "4285F4",
		"source": "https://maps.google.com/pluscodes/"
	},
	{
		"title": "PM2",
		"hex": "2B037A",
		"source": "https://pm2.keymetrics.io"
	},
	{
		"title": "pnpm",
		"hex": "F69220",
		"source": "https://pnpm.io/logos"
	},
	{
		"title": "Pocket",
		"hex": "EF3F56",
		"source": "https://blog.getpocket.com/press/"
	},
	{
		"title": "Pocket Casts",
		"hex": "F43E37",
		"source": "https://blog.pocketcasts.com/press/"
	},
	{
		"title": "PocketBase",
		"hex": "B8DBE4",
		"source": "https://github.com/pocketbase/pocketbase/blob/4b64e0910b7dc527ff3de8cdacec074e40449e2e/ui/dist/images/logo.svg"
	},
	{
		"title": "Podcast Addict",
		"hex": "F4842D",
		"source": "https://podcastaddict.com"
	},
	{
		"title": "Podcast Index",
		"hex": "F90000",
		"source": "https://podcastindex.org"
	},
	{
		"title": "Podman",
		"hex": "892CA0",
		"source": "https://podman.io"
	},
	{
		"title": "Poe",
		"hex": "5D5CDE",
		"source": "https://poe.com"
	},
	{
		"title": "Poetry",
		"hex": "60A5FA",
		"source": "https://python-poetry.org"
	},
	{
		"title": "Pointy",
		"hex": "009DE0",
		"source": "https://www.pointy.com/ie/vend"
	},
	{
		"title": "Polars",
		"hex": "CD792C",
		"source": "https://pola.rs"
	},
	{
		"title": "Polestar",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:Polestar_logo_2020.svg"
	},
	{
		"title": "Polkadot",
		"hex": "E6007A",
		"source": "https://polkadot.network/brand-assets/",
		"guidelines": "https://polkadot.network/brand-assets/"
	},
	{
		"title": "Poly",
		"hex": "EB3C00",
		"source": "https://www.poly.com"
	},
	{
		"title": "Polygon",
		"hex": "7B3FE4",
		"source": "https://www.polygon.technology",
		"guidelines": "https://polygon.technology/brandguidelines",
		"aliases": {
			"aka": [
				"Matic"
			]
		}
	},
	{
		"title": "Polymer Project",
		"hex": "FF4470",
		"source": "https://github.com/Polymer/polymer-project.org/blob/3d3e967446858b49a7796676714865ac9b2a5275/app/images/logos/p-logo.svg"
	},
	{
		"title": "Polywork",
		"hex": "543DE0",
		"source": "https://www.polywork.com"
	},
	{
		"title": "Pond5",
		"hex": "000000",
		"source": "https://pond5.com"
	},
	{
		"title": "Pop!_OS",
		"hex": "48B9C7",
		"source": "https://github.com/system76/brand/blob/7a31740b54f929b62a165baa61dfb0b5164261e8/Pop_OS%20branding/Pop_icon.svg"
	},
	{
		"title": "Porkbun",
		"hex": "EF7878",
		"source": "https://porkbun.design",
		"guidelines": "https://porkbun.design/guidelines.html"
	},
	{
		"title": "Porsche",
		"hex": "B12B28",
		"source": "https://www.porsche.com"
	},
	{
		"title": "PortableApps.com",
		"hex": "818F95",
		"source": "https://github.com/simple-icons/simple-icons/pull/12366#issuecomment-2551561301"
	},
	{
		"title": "Portainer",
		"hex": "13BEF9",
		"source": "https://www.portainer.io"
	},
	{
		"title": "PortSwigger",
		"hex": "FF6633",
		"source": "https://portswigger.net"
	},
	{
		"title": "Posit",
		"hex": "447099",
		"source": "https://docs.posit.co",
		"guidelines": "https://posit.co/about/trademark-guidelines",
		"aliases": {
			"old": [
				"RStudio"
			]
		}
	},
	{
		"title": "PostCSS",
		"hex": "DD3A0A",
		"source": "https://postcss.org"
	},
	{
		"title": "PostgreSQL",
		"hex": "4169E1",
		"source": "https://wiki.postgresql.org/wiki/Logo",
		"guidelines": "https://www.postgresql.org/about/policies/trademarks/"
	},
	{
		"title": "PostHog",
		"hex": "000000",
		"source": "https://posthog.com/handbook/company/brand-assets",
		"guidelines": "https://posthog.com/handbook/company/brand-assets"
	},
	{
		"title": "Postman",
		"hex": "FF6C37",
		"source": "https://www.getpostman.com/resources/media-assets/"
	},
	{
		"title": "Postmates",
		"hex": "FFDF18",
		"source": "https://postmates.com/press-and-media"
	},
	{
		"title": "POWERS",
		"hex": "E74536",
		"source": "https://www.powerswhiskey.com"
	},
	{
		"title": "pr.co",
		"hex": "0080FF",
		"source": "https://news.pr.co/media_kits"
	},
	{
		"title": "pre-commit",
		"hex": "FAB040",
		"source": "https://github.com/pre-commit/pre-commit.com/blob/f263cdbcf46f97e1bd6229f2ab6d27bf8290ca88/logo.svg"
	},
	{
		"title": "Preact",
		"hex": "673AB8",
		"source": "https://preactjs.com"
	},
	{
		"title": "Prefect",
		"hex": "070E10",
		"source": "https://www.prefect.io"
	},
	{
		"title": "Premier League",
		"hex": "360D3A",
		"source": "https://www.premierleague.com"
	},
	{
		"title": "PrepBytes",
		"hex": "5A87C6",
		"source": "https://www.prepbytes.com"
	},
	{
		"title": "PrestaShop",
		"hex": "DF0067",
		"source": "https://prestashop.com/brand-book"
	},
	{
		"title": "Presto",
		"hex": "5890FF",
		"source": "https://github.com/prestodb/presto/blob/414ab2a6bbdcca6479c2615b048920adac34dd20/presto-docs/src/main/resources/logo/web/fb/dark-blue/Presto_FB_Lockups_DARKBLUE_BG-14.svg"
	},
	{
		"title": "Prettier",
		"hex": "F7B93E",
		"source": "https://github.com/prettier/prettier-logo/blob/06997b307e0608ebee2044dafa0b9429d6b5a103/images/prettier-icon-clean-centred.svg"
	},
	{
		"title": "Pretzel",
		"hex": "1BB3A4",
		"source": "https://www.pretzel.rocks"
	},
	{
		"title": "Prevention",
		"hex": "44C1C5",
		"source": "https://prevention.com"
	},
	{
		"title": "Prezi",
		"hex": "3181FF",
		"source": "https://prezi.com/press/kit/"
	},
	{
		"title": "Prime",
		"hex": "00A8E1",
		"source": "https://www.amazon.com/b?node=17277626011",
		"guidelines": "https://www.amazon.com/b?node=17277626011"
	},
	{
		"title": "Prime Video",
		"hex": "1F2E3E",
		"source": "https://videodirect.amazon.com/home/help?topicId=GT7W7GJBTDJW6Z8W#G8T2JFQZXPMHJLRZ",
		"guidelines": "https://videodirect.amazon.com/home/help?topicId=GT7W7GJBTDJW6Z8W#G8T2JFQZXPMHJLRZ"
	},
	{
		"title": "PrimeFaces",
		"hex": "263238",
		"source": "https://www.primefaces.org/press-kit",
		"guidelines": "https://www.primefaces.org/press-kit"
	},
	{
		"title": "PrimeNG",
		"hex": "DD0031",
		"source": "https://www.primefaces.org/press-kit",
		"guidelines": "https://www.primefaces.org/press-kit"
	},
	{
		"title": "PrimeReact",
		"hex": "03C4E8",
		"source": "https://www.primefaces.org/press-kit",
		"guidelines": "https://www.primefaces.org/press-kit"
	},
	{
		"title": "PrimeVue",
		"hex": "41B883",
		"source": "https://www.primefaces.org/press-kit",
		"guidelines": "https://www.primefaces.org/press-kit"
	},
	{
		"title": "Printables",
		"hex": "FA6831",
		"source": "https://printables.com"
	},
	{
		"title": "Prisma",
		"hex": "2D3748",
		"source": "https://github.com/prisma/presskit/tree/4bcb64181f266723439d955d60afa1c55fefa715"
	},
	{
		"title": "Prismic",
		"hex": "5163BA",
		"source": "https://prismic.io"
	},
	{
		"title": "Private Division",
		"hex": "000000",
		"source": "https://account.privatedivision.com"
	},
	{
		"title": "Private Internet Access",
		"hex": "1E811F",
		"source": "https://www.privateinternetaccess.com",
		"aliases": {
			"aka": [
				"PIA"
			]
		}
	},
	{
		"title": "Pro Tools",
		"hex": "7ACB10",
		"source": "https://cdn-www.avid.com/Content/fonts/avidmoon.ttf"
	},
	{
		"title": "Probot",
		"hex": "00B0D8",
		"source": "https://github.com/probot/probot/blob/5d29945dd2116618d63aba9d7a4460b940a85f5d/static/robot.svg"
	},
	{
		"title": "Processing Foundation",
		"hex": "006699",
		"source": "https://processingfoundation.org"
	},
	{
		"title": "ProcessWire",
		"hex": "2480E6",
		"source": "https://processwire.com"
	},
	{
		"title": "Product Hunt",
		"hex": "DA552F",
		"source": "https://www.producthunt.com/branding",
		"guidelines": "https://www.producthunt.com/branding"
	},
	{
		"title": "Progate",
		"hex": "380953",
		"source": "https://progate.com"
	},
	{
		"title": "Progress",
		"hex": "5CE500",
		"source": "https://www.progress.com",
		"guidelines": "https://www.progress.com/legal/trademarks/trademarks-use-policy"
	},
	{
		"title": "Prometheus",
		"hex": "E6522C",
		"source": "https://prometheus.io"
	},
	{
		"title": "Pronouns.page",
		"hex": "C71585",
		"source": "https://pronouns.page/design"
	},
	{
		"title": "ProSieben",
		"hex": "E6000F",
		"source": "https://www.prosieben.de"
	},
	{
		"title": "Proteus",
		"hex": "1C79B3",
		"source": "https://www.labcenter.com"
	},
	{
		"title": "Proto.io",
		"hex": "34A7C1",
		"source": "https://proto.io/en/presskit"
	},
	{
		"title": "protocols.io",
		"hex": "4D9FE7",
		"source": "https://www.protocols.io/brand",
		"guidelines": "https://www.protocols.io/brand"
	},
	{
		"title": "Proton",
		"hex": "6D4AFF",
		"source": "https://proton.me/media/kit"
	},
	{
		"title": "Proton Calendar",
		"hex": "50B0E9",
		"source": "https://proton.me/media/kit"
	},
	{
		"title": "Proton Drive",
		"hex": "EB508D",
		"source": "https://proton.me/media/kit"
	},
	{
		"title": "Proton Mail",
		"hex": "6D4AFF",
		"source": "https://proton.me/media/kit"
	},
	{
		"title": "Proton VPN",
		"hex": "66DEB1",
		"source": "https://proton.me/media/kit"
	},
	{
		"title": "ProtonDB",
		"hex": "F50057",
		"source": "https://www.protondb.com"
	},
	{
		"title": "Protractor",
		"hex": "ED163A",
		"source": "https://github.com/angular/protractor/blob/4bc80d1a459542d883ea9200e4e1f48d265d0fda/logo.svg"
	},
	{
		"title": "Proxmox",
		"hex": "E57000",
		"source": "https://www.proxmox.com/en/news/media-kit",
		"guidelines": "https://www.proxmox.com/en/news/media-kit"
	},
	{
		"title": "Pterodactyl",
		"hex": "10539F",
		"source": "https://github.com/pterodactyl/panel/blob/eaf46429f2a001469fb5f18f7891ce8e5be7f049/public/favicons/favicon-96x96.png"
	},
	{
		"title": "PUBG",
		"hex": "F4B942",
		"source": "https://krafton.com/en/about/brandcenter"
	},
	{
		"title": "Publons",
		"hex": "336699",
		"source": "https://publons.com/about/the-publons-logo",
		"guidelines": "https://publons.com/about/the-publons-logo"
	},
	{
		"title": "PubMed",
		"hex": "326599",
		"source": "https://pubmed.ncbi.nlm.nih.gov"
	},
	{
		"title": "Pug",
		"hex": "A86454",
		"source": "https://github.com/pugjs/pug-logo/blob/61429fc45b5a411b83bdb5c99a61084d3054d1e6/SVG/pug-final-logo_-mono-64.svg"
	},
	{
		"title": "Pulumi",
		"hex": "8A3391",
		"source": "https://www.pulumi.com",
		"guidelines": "https://www.pulumi.com/brand/"
	},
	{
		"title": "Puma",
		"hex": "242B2F",
		"source": "https://us.puma.com"
	},
	{
		"title": "Puppet",
		"hex": "FFAE1A",
		"source": "https://puppet.com/company/press-room/"
	},
	{
		"title": "Puppeteer",
		"hex": "40B5A4",
		"source": "https://pptr.dev"
	},
	{
		"title": "PureScript",
		"hex": "14161A",
		"source": "https://github.com/purescript/logo/tree/1e7a57affdaeaf88ff594c08bd2b5a78fe2ed13c",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "PurgeCSS",
		"hex": "14161A",
		"source": "https://github.com/FullHuman/purgecss/blob/4e2bf58e218119cc9faf9faa615d62a059bf9d9a/docs/.vuepress/public/safari-pinned-tab.svg"
	},
	{
		"title": "Purism",
		"hex": "2D2D2D",
		"source": "https://puri.sm/pr/images/"
	},
	{
		"title": "Pushbullet",
		"hex": "4AB367",
		"source": "https://www.pushbullet.com/press"
	},
	{
		"title": "Pusher",
		"hex": "300D4F",
		"source": "https://pusher.com"
	},
	{
		"title": "PWA",
		"hex": "5A0FC8",
		"source": "https://github.com/webmaxru/progressive-web-apps-logo/blob/77744cd5c0a4d484bb3d082c6ac458c44202da03/pwalogo-white.svg",
		"guidelines": "https://github.com/webmaxru/progressive-web-apps-logo#readme",
		"aliases": {
			"aka": [
				"Progressive Web Application"
			]
		}
	},
	{
		"title": "PyCharm",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "PyCQA",
		"hex": "201B44",
		"source": "https://github.com/PyCQA/meta/blob/ac828d8d7eb55501addefb0ceb6496ab15e85ca5/logo/pycqa1-02.svg",
		"license": {
			"type": "CC-BY-NC-ND-4.0"
		}
	},
	{
		"title": "Pydantic",
		"hex": "E92063",
		"source": "https://github.com/pydantic/pydantic/blob/94c748001a32992a587694b999fb1f3d2f1fc1fe/docs/logo-white.svg"
	},
	{
		"title": "PyG",
		"hex": "3C2179",
		"source": "https://github.com/pyg-team/pyg_sphinx_theme/blob/4f696513b4b4adf2ba3874574a10a8e8718672fe/pyg_sphinx_theme/static/img/pyg_logo.svg",
		"aliases": {
			"aka": [
				"PyTorch Geometric"
			]
		}
	},
	{
		"title": "PyPI",
		"hex": "3775A9",
		"source": "https://pypi.org"
	},
	{
		"title": "PyPy",
		"hex": "193440",
		"source": "https://www.pypy.org"
	},
	{
		"title": "PyScaffold",
		"hex": "005CA0",
		"source": "https://github.com/pyscaffold/pyscaffold/blob/3f72bf7894fc73b34af06a90bb5d43aae410ce5d/docs/gfx/logo.svg"
	},
	{
		"title": "PySyft",
		"hex": "F1BF7A",
		"source": "https://github.com/OpenMined/openmined-website/blob/db5c223657c8c49ab1ee8db2841fe802f73af31c/src/containers/app/components/repo-icon/assets/syft.svg"
	},
	{
		"title": "Pytest",
		"hex": "0A9EDC",
		"source": "https://github.com/pytest-dev/design/blob/081f06cd2d6cd742e68f593560a2e8c1802feb7c/pytest_logo/pytest_logo.svg"
	},
	{
		"title": "Python",
		"hex": "3776AB",
		"source": "https://www.python.org/community/logos/",
		"guidelines": "https://www.python.org/community/logos/"
	},
	{
		"title": "PythonAnywhere",
		"hex": "1D9FD7",
		"source": "https://www.pythonanywhere.com"
	},
	{
		"title": "PyTorch",
		"hex": "EE4C2C",
		"source": "https://github.com/pytorch/pytorch.github.io/blob/8f083bd12192ca12d5e1c1f3d236f4831d823d8f/assets/images/logo.svg",
		"guidelines": "https://github.com/pytorch/pytorch.github.io/blob/381117ec296f002b2de475402ef29cca6c55e209/assets/brand-guidelines/PyTorch-Brand-Guidelines.pdf"
	},
	{
		"title": "PyUp",
		"hex": "9F55FF",
		"source": "https://pyup.io"
	},
	{
		"title": "Qantas",
		"hex": "E40000",
		"source": "https://www.qantas.com"
	},
	{
		"title": "Qase",
		"hex": "4F46DC",
		"source": "https://qase.io",
		"license": {
			"type": "custom",
			"url": "https://github.com/simple-icons/simple-icons/pull/9907#issuecomment-1831377594"
		}
	},
	{
		"title": "Qatar Airways",
		"hex": "5C0D34",
		"source": "https://www.qatarairways.com/press-releases/en-WW/media_kits"
	},
	{
		"title": "qbittorrent",
		"hex": "2F67BA",
		"source": "https://github.com/qbittorrent/qBittorrent/blob/73028f9930d9ab9d89edb60ed4aedb66d75669d9/src/icons/qbittorrent-tray-light.svg"
	},
	{
		"title": "QEMU",
		"hex": "FF6600",
		"source": "https://wiki.qemu.org/Logo"
	},
	{
		"title": "Qgis",
		"hex": "589632",
		"source": "https://www.qgis.org/en/site/getinvolved/styleguide.html",
		"guidelines": "https://www.qgis.org/en/site/getinvolved/styleguide.html"
	},
	{
		"title": "Qi",
		"hex": "000000",
		"source": "https://www.wirelesspowerconsortium.com/knowledge-base/retail/qi-logo-guidelines-and-artwork.html",
		"guidelines": "https://www.wirelesspowerconsortium.com/knowledge-base/retail/qi-logo-guidelines-and-artwork.html"
	},
	{
		"title": "Qiita",
		"hex": "55C500",
		"source": "https://help.qiita.com/ja/articles/others-brand-guideline",
		"guidelines": "https://help.qiita.com/ja/articles/others-brand-guideline"
	},
	{
		"title": "Qiskit",
		"hex": "6929C4",
		"source": "https://qiskit.org"
	},
	{
		"title": "QIWI",
		"hex": "FF8C00",
		"source": "https://qiwi.com"
	},
	{
		"title": "Qlik",
		"hex": "009848",
		"source": "https://www.qlik.com",
		"guidelines": "https://www.qlik.com/us/legal/trademarks"
	},
	{
		"title": "QMK",
		"hex": "333333",
		"source": "https://github.com/qmk/qmk.fm/blob/1c3cf365e734a1fb551ccfb7ade6e210ae86e774/src/public/qmk-logo-light.svg"
	},
	{
		"title": "QNAP",
		"hex": "0C2E82",
		"source": "https://marketing.qnap.com/resource/qnap-logo-k100",
		"guidelines": "https://marketing.qnap.com/resource/qnap-brand-logo-guideline",
		"aliases": {
			"aka": [
				"Quality Network Appliance Provider"
			]
		}
	},
	{
		"title": "QQ",
		"hex": "1EBAFC",
		"source": "https://en.wikipedia.org/wiki/File:Tencent_QQ.svg",
		"guidelines": "https://qq.design/brand/BrandDesign/Logo"
	},
	{
		"title": "Qt",
		"hex": "41CD52",
		"source": "https://www.qt.io",
		"guidelines": "https://www.qt.io/brand"
	},
	{
		"title": "Qualcomm",
		"hex": "3253DC",
		"source": "https://www.qualcomm.com"
	},
	{
		"title": "Qualtrics",
		"hex": "00B4EF",
		"source": "https://www.qualtrics.com/brand-book",
		"guidelines": "https://www.qualtrics.com/brand-book"
	},
	{
		"title": "Qualys",
		"hex": "ED2E26",
		"source": "https://www.qualys.com",
		"guidelines": "https://www.qualys.com/company/newsroom/media-contacts"
	},
	{
		"title": "Quantcast",
		"hex": "000000",
		"source": "https://www.quantcast.com"
	},
	{
		"title": "QuantConnect",
		"hex": "F98309",
		"source": "https://www.quantconnect.com",
		"guidelines": "https://www.quantconnect.com/terms"
	},
	{
		"title": "Quarkus",
		"hex": "4695EB",
		"source": "https://design.jboss.org/quarkus"
	},
	{
		"title": "Quarto",
		"hex": "39729E",
		"source": "https://github.com/quarto-dev/quarto-web/blob/fd2a993e3274b3433a0088d5daf85080bdf68d71/quarto-icon.svg",
		"guidelines": "https://quarto.org/trademark.html"
	},
	{
		"title": "Quasar",
		"hex": "050A14",
		"source": "https://github.com/quasarframework/quasar-art/blob/6300e95687a923cd027dc4b8c356dd4e0cea618f/Brand/Logo/RGB/Icon/Monochrome/Cold%20Black/QUASAR_icon_mono_cold_black_RGB.svg",
		"license": {
			"type": "custom",
			"url": "https://github.com/quasarframework/quasar-art/blob/6300e95687a923cd027dc4b8c356dd4e0cea618f/LICENSE"
		}
	},
	{
		"title": "Qubes OS",
		"hex": "3874D8",
		"source": "https://github.com/QubesOS/qubes-attachment/blob/ed7e552eb8a5fca4e099361d137793d3551b3968/icons/qubes-logo-home.svg"
	},
	{
		"title": "Quest",
		"hex": "FB4F14",
		"source": "https://brand.quest.com/quest/questlogos",
		"guidelines": "https://brand.quest.com/quest/questlogos"
	},
	{
		"title": "QuickBooks",
		"hex": "2CA01C",
		"source": "https://design.intuit.com/quickbooks/brand",
		"guidelines": "https://design.intuit.com/quickbooks/brand"
	},
	{
		"title": "QuickLook",
		"hex": "0078D3",
		"source": "https://github.com/QL-Win/QuickLook/blob/f726841d99bbceafd5399e5777b4dba302bf1e51/QuickLook/Resources/app.svg",
		"license": {
			"type": "GPL-3.0-or-later"
		}
	},
	{
		"title": "QuickTime",
		"hex": "1C69F0",
		"source": "https://support.apple.com/quicktime"
	},
	{
		"title": "quicktype",
		"hex": "159588",
		"source": "https://github.com/glideapps/quicktype-xcode/blob/2f9a8d2ef2466358341142c3881d54e065b30a8c/media/logo.svg"
	},
	{
		"title": "Quip",
		"hex": "F27557",
		"source": "https://quip.com"
	},
	{
		"title": "Quizlet",
		"hex": "4255FF",
		"source": "https://quizlet.com"
	},
	{
		"title": "Quora",
		"hex": "B92B27",
		"source": "https://www.quora.com"
	},
	{
		"title": "Qwant",
		"hex": "282B2F",
		"source": "https://about.qwant.com"
	},
	{
		"title": "Qwik",
		"hex": "AC7EF4",
		"source": "https://github.com/BuilderIO/qwik/blob/c88e53d49dc65020899d770338f4e51f3134611e/packages/docs/public/logos/qwik-logo.svg"
	},
	{
		"title": "Qwiklabs",
		"hex": "F5CD0E",
		"source": "https://www.cloudskillsboost.google"
	},
	{
		"title": "Qzone",
		"hex": "FECE00",
		"source": "https://qzone.qq.com"
	},
	{
		"title": "R",
		"hex": "276DC3",
		"source": "https://www.r-project.org/logo/",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "R3",
		"hex": "EC1D24",
		"source": "https://www.r3.com",
		"guidelines": "https://www.r3.com/contact-press-media/"
	},
	{
		"title": "RabbitMQ",
		"hex": "FF6600",
		"source": "https://www.rabbitmq.com",
		"guidelines": "https://www.rabbitmq.com/trademark-guidelines.html"
	},
	{
		"title": "Racket",
		"hex": "9F1D20",
		"source": "https://racket-lang.org"
	},
	{
		"title": "RAD Studio",
		"hex": "E62431",
		"source": "https://www.embarcadero.com/news/logo",
		"guidelines": "https://www.ideracorp.com/legal/embarcadero"
	},
	{
		"title": "Radar",
		"hex": "007AFF",
		"source": "https://radar.io"
	},
	{
		"title": "radarr",
		"hex": "FFCB3D",
		"source": "https://github.com/Radarr/Radarr/blob/5f624a147bb62d37b731d9a0ae02bfd338793962/Logo/Radarr.svg"
	},
	{
		"title": "Radix UI",
		"hex": "161618",
		"source": "https://www.radix-ui.com"
	},
	{
		"title": "Railway",
		"hex": "0B0D0E",
		"source": "https://railway.app"
	},
	{
		"title": "Rainmeter",
		"hex": "19519B",
		"source": "https://github.com/rainmeter/rainmeter-www/blob/867fd905fda8d1b1083730adcb7f49f1775cb5b0/source/img/logo_blue.ai"
	},
	{
		"title": "Rakuten",
		"hex": "BF0000",
		"source": "https://global.rakuten.com/corp/news/media",
		"guidelines": "https://global.rakuten.com/corp/news/media"
	},
	{
		"title": "Ram",
		"hex": "000000",
		"source": "https://www.fcaci.com/x/RAMv15",
		"guidelines": "https://www.fcaci.com/x/RAMv15"
	},
	{
		"title": "Rancher",
		"hex": "0075A8",
		"source": "https://rancher.com/brand-guidelines/",
		"guidelines": "https://rancher.com/brand-guidelines/"
	},
	{
		"title": "Rapid",
		"hex": "0055DA",
		"source": "https://rapidapi.com"
	},
	{
		"title": "Rarible",
		"hex": "FEDA03",
		"source": "https://rarible.com"
	},
	{
		"title": "Rasa",
		"hex": "5A17EE",
		"source": "https://rasa.com"
	},
	{
		"title": "Raspberry Pi",
		"hex": "A22846",
		"source": "https://www.raspberrypi.org/trademark-rules",
		"guidelines": "https://www.raspberrypi.org/trademark-rules"
	},
	{
		"title": "Ravelry",
		"hex": "EE6E62",
		"source": "https://www.ravelry.com/help/logos",
		"guidelines": "https://www.ravelry.com/help/logos"
	},
	{
		"title": "Ray",
		"hex": "028CF0",
		"source": "https://github.com/ray-project/ray/blob/6522935291caa120e83697c6c9b3a450617c9283/dashboard/client/src/logo.svg"
	},
	{
		"title": "Raycast",
		"hex": "FF6363",
		"source": "https://www.raycast.com/press",
		"guidelines": "https://www.raycast.com/press"
	},
	{
		"title": "Raylib",
		"hex": "000000",
		"source": "https://github.com/raysan5/raylib/blob/e7a486fa81adac1833253c849ca73c5b3f7ef361/logo/raylib_512x512.png"
	},
	{
		"title": "Razer",
		"hex": "00FF00",
		"source": "https://press.razer.com"
	},
	{
		"title": "Razorpay",
		"hex": "0C2451",
		"source": "https://razorpay.com/newsroom/brand-assets/",
		"guidelines": "https://razorpay.com/newsroom/brand-assets/"
	},
	{
		"title": "Rclone",
		"hex": "3F79AD",
		"source": "https://github.com/rclone/rclone/blob/8f1c309c8149a734ccc3a0d2ce185b936dbe783a/graphics/logo/svg/logo_symbol_color.svg"
	},
	{
		"title": "React",
		"hex": "61DAFB",
		"source": "https://github.com/facebook/create-react-app/blob/282c03f9525fdf8061ffa1ec50dce89296d916bd/test/fixtures/relative-paths/src/logo.svg",
		"aliases": {
			"dup": [
				{
					"title": "React Native",
					"source": "https://reactnative.dev"
				}
			]
		}
	},
	{
		"title": "React Bootstrap",
		"hex": "41E0FD",
		"source": "https://github.com/react-bootstrap/react-bootstrap/blob/be23c304fa40ddb209919b0faac1e5dd8cef53ad/www/static/img/logo.svg"
	},
	{
		"title": "React Hook Form",
		"hex": "EC5990",
		"source": "https://github.com/react-hook-form/documentation/blob/d049ffe923336ce7a5bf58990c54c07f39ab2429/src/images/Logo.svg"
	},
	{
		"title": "React Query",
		"hex": "FF4154",
		"source": "https://github.com/tannerlinsley/react-query/blob/9b5d18cd47a4c1454d6c8dd0f38280641c1dd5dd/docs/src/images/emblem-light.svg"
	},
	{
		"title": "React Router",
		"hex": "CA4245",
		"source": "https://github.com/ReactTraining/react-router/blob/c94bcd8cef0c811f80b02777ec26fee3618f8e86/website/static/safari-pinned-tab.svg"
	},
	{
		"title": "React Table",
		"hex": "FF4154",
		"source": "https://github.com/tannerlinsley/react-table/blob/8c77b4ad97353a0b1f0746be5b919868862a9dcc/docs/src/images/emblem-light.svg"
	},
	{
		"title": "Reactive Resume",
		"hex": "000000",
		"source": "https://github.com/AmruthPillai/Reactive-Resume/blob/0f765af4687acd05d63cccf3676583735c86a8c2/apps/artboard/public/icon/dark.svg"
	},
	{
		"title": "ReactiveX",
		"hex": "B7178C",
		"source": "https://github.com/ReactiveX/rxjs/blob/ee6ababb9fa75f068ac2122e956ff4e449604c59/resources/CI-CD/logo/svg/RxJs_Logo_Black.svg",
		"aliases": {
			"dup": [
				{
					"title": "RxJS",
					"hex": "D81B60"
				}
			]
		}
	},
	{
		"title": "ReactOS",
		"hex": "0088CC",
		"source": "https://github.com/reactos/press-media/tree/48089e09e0c7e828f1eb81e5ea0d8da85ec41dc3"
	},
	{
		"title": "Read the Docs",
		"hex": "8CA1AF",
		"source": "https://github.com/readthedocs/readthedocs.org/blob/2dc9706c4fe7fa6d4410ed0e5aedca8d4796fe0f/media/readthedocsbranding.ai"
	},
	{
		"title": "Read.cv",
		"hex": "111111",
		"source": "https://read.cv/support/faq"
	},
	{
		"title": "ReadMe",
		"hex": "018EF5",
		"source": "https://readme.com"
	},
	{
		"title": "Reason",
		"hex": "DD4B39",
		"source": "https://github.com/reasonml/reasonml.github.io/blob/18dc62ad841f0def6551a65e41083c9d5784da93/website/static/img/reason.svg"
	},
	{
		"title": "Reason Studios",
		"hex": "FFFFFF",
		"source": "https://www.reasonstudios.com/press",
		"guidelines": "https://www.reasonstudios.com/press"
	},
	{
		"title": "Recoil",
		"hex": "3578E5",
		"source": "https://recoiljs.org"
	},
	{
		"title": "Red",
		"hex": "B32629",
		"source": "https://www.red-lang.org"
	},
	{
		"title": "Red Bull",
		"hex": "DB0A40",
		"source": "https://www.redbull.com"
	},
	{
		"title": "Red Candle Games",
		"hex": "D23735",
		"source": "https://shop.redcandlegames.com"
	},
	{
		"title": "Red Hat",
		"hex": "EE0000",
		"source": "https://www.redhat.com/en/about/brand/new-brand/details"
	},
	{
		"title": "Red Hat Open Shift",
		"hex": "EE0000",
		"source": "https://www.openshift.com"
	},
	{
		"title": "Redash",
		"hex": "FF7964",
		"source": "https://github.com/getredash/website/blob/c454b523fdaa60218845313904c5498cda7e7b7a/static/assets/images/elements/redash-logo.svg"
	},
	{
		"title": "Redbubble",
		"hex": "E41321",
		"source": "https://www.redbubble.com"
	},
	{
		"title": "Reddit",
		"hex": "FF4500",
		"source": "https://www.redditinc.com/brand",
		"guidelines": "https://www.redditinc.com/brand"
	},
	{
		"title": "Redis",
		"hex": "FF4438",
		"source": "https://redis.io/brand-guidelines",
		"guidelines": "https://redis.io/brand-guidelines"
	},
	{
		"title": "Redmine",
		"hex": "B32024",
		"source": "https://www.redmine.org/projects/redmine/wiki/logo",
		"license": {
			"type": "CC-BY-SA-2.5"
		}
	},
	{
		"title": "Redox",
		"hex": "000000",
		"source": "https://github.com/redox-os/assets/blob/4935a777cd7aa44323d3c263b1e0bb4ae864a027/logos/redox/vectorized_logo.svg"
	},
	{
		"title": "Redragon",
		"hex": "E60012",
		"source": "https://redragonshop.com"
	},
	{
		"title": "Redsys",
		"hex": "DC7C26",
		"source": "https://redsys.es"
	},
	{
		"title": "Redux",
		"hex": "764ABC",
		"source": "https://github.com/reduxjs/redux/blob/abb5f892f7e46849e5ca9bc13e75cfbc944a71b6/logo/logo.svg"
	},
	{
		"title": "Redux-Saga",
		"hex": "999999",
		"source": "https://github.com/redux-saga/redux-saga/blob/9d2164946f402e594a0dfe453c6d20fb6f14858f/logo/3840/Redux-Saga-Logo.png"
	},
	{
		"title": "RedwoodJS",
		"hex": "BF4722",
		"source": "https://redwoodjs.com/brand",
		"guidelines": "https://redwoodjs.com/brand"
	},
	{
		"title": "Reebok",
		"hex": "E41D1B",
		"source": "https://www.reebok.com/us"
	},
	{
		"title": "Refine",
		"hex": "14141F",
		"source": "https://s.refine.dev/refine-brand-assets",
		"guidelines": "https://s.refine.dev/refine-brand-assets"
	},
	{
		"title": "Refined GitHub",
		"hex": "9E95B7",
		"source": "https://github.com/refined-github/refined-github/blob/f30ca4a22528e9720e23b85d4cd38f074d64b179/media/icon.svg"
	},
	{
		"title": "Relay",
		"hex": "F26B00",
		"source": "https://relay.dev"
	},
	{
		"title": "Reliance Industries Limited",
		"hex": "D1AB66",
		"source": "https://www.ril.com/news-media/resource-center/media-kit/reliance-industries-limited",
		"guidelines": "https://www.ril.com/legal-notice"
	},
	{
		"title": "remark",
		"hex": "000000",
		"source": "https://github.com/remarkjs/remark/blob/26dc58a675ac7267c105f0fdb76a82db77f8402a/logo.svg"
	},
	{
		"title": "Remedy Entertainment",
		"hex": "D6001C",
		"source": "https://www.remedygames.com"
	},
	{
		"title": "Remix",
		"hex": "000000",
		"source": "https://drive.google.com/drive/u/0/folders/1pbHnJqg8Y1ATs0Oi8gARH7wccJGv4I2c"
	},
	{
		"title": "remove.bg",
		"hex": "54616C",
		"source": "https://www.remove.bg"
	},
	{
		"title": "Ren'Py",
		"hex": "FF7F7F",
		"source": "https://renpy.org"
	},
	{
		"title": "Renault",
		"hex": "FFCC33",
		"source": "https://media.renaultgroup.com"
	},
	{
		"title": "Render",
		"hex": "000000",
		"source": "https://render.com"
	},
	{
		"title": "Renovate",
		"hex": "308BE3",
		"source": "https://github.com/user-attachments/assets/8533178e-b2c4-4e15-bb3d-8df9e19e3760",
		"guidelines": "https://docs.renovatebot.com/logo-brand-guidelines"
	},
	{
		"title": "Renren",
		"hex": "217DC6",
		"source": "https://seeklogo.com/vector-logo/184137/renren-inc"
	},
	{
		"title": "Replicate",
		"hex": "000000",
		"source": "https://replicate.com"
	},
	{
		"title": "Replit",
		"hex": "F26207",
		"source": "https://repl.it"
	},
	{
		"title": "Republic of Gamers",
		"hex": "FF0029",
		"source": "https://rog.asus.com",
		"aliases": {
			"aka": [
				"ASUS ROG",
				"ROG"
			]
		}
	},
	{
		"title": "ReScript",
		"hex": "E6484F",
		"source": "https://rescript-lang.org/brand"
	},
	{
		"title": "RescueTime",
		"hex": "161A3B",
		"source": "https://www.rescuetime.com/press"
	},
	{
		"title": "ResearchGate",
		"hex": "00CCBB",
		"source": "https://www.researchgate.net"
	},
	{
		"title": "Resend",
		"hex": "000000",
		"source": "https://resend.com/brand",
		"guidelines": "https://resend.com/brand"
	},
	{
		"title": "ReSharper",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "Resurrection Remix OS",
		"hex": "000000",
		"source": "https://avatars.githubusercontent.com/u/4931972"
	},
	{
		"title": "Retool",
		"hex": "3D3D3D",
		"source": "https://retool.com"
	},
	{
		"title": "RetroArch",
		"hex": "000000",
		"source": "https://github.com/libretro/RetroArch/blob/b01aabf7d1f025999ad0f7812e6e6816d011e631/media/retroarch.svg"
	},
	{
		"title": "RetroPie",
		"hex": "CC0000",
		"source": "https://github.com/RetroPie/RetroPie-Docs/blob/c4e882bd2c9d740c591ff346e07a4a4cb536ca93/images/logo.svg"
	},
	{
		"title": "ReVanced",
		"hex": "9ED5FF",
		"source": "https://revanced.app"
	},
	{
		"title": "reveal.js",
		"hex": "F2E142",
		"source": "https://revealjs.com"
	},
	{
		"title": "ReverbNation",
		"hex": "E43526",
		"source": "https://www.reverbnation.com"
	},
	{
		"title": "Revolt.chat",
		"hex": "FF4655",
		"source": "https://app.revolt.chat/assets/badges/revolt_r.svg",
		"aliases": {
			"aka": [
				"revolt"
			]
		}
	},
	{
		"title": "Revolut",
		"hex": "191C1F",
		"source": "https://developer.revolut.com/docs/resources/marketing-assets-guidelines/marketing-guidelines"
	},
	{
		"title": "REWE",
		"hex": "CC071E",
		"source": "https://www.rewe.de"
	},
	{
		"title": "Rezgo",
		"hex": "F76C00",
		"source": "https://www.rezgo.com"
	},
	{
		"title": "Rhinoceros",
		"hex": "801010",
		"source": "https://github.com/mcneel/compute.rhino3d/blob/2204d998ff0397a1c6a18dd2312a96508ad48bdb/README.md"
	},
	{
		"title": "Rich",
		"hex": "FAE742",
		"source": "https://github.com/Textualize/rich/blob/fd981823644ccf50d685ac9c0cfe8e1e56c9dd35/imgs/logo.svg"
	},
	{
		"title": "Rider",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos/",
		"guidelines": "https://www.jetbrains.com/company/brand/"
	},
	{
		"title": "Rimac Automobili",
		"hex": "0A222E",
		"source": "https://www.rimac-automobili.com/media/",
		"guidelines": "https://www.rimac-automobili.com/media/"
	},
	{
		"title": "Rime",
		"hex": "000000",
		"source": "https://github.com/rime/home/blob/65738f446c7e6c56a560fdaa0c0f02937b8e51d0/blog/source/images/logo.svg"
	},
	{
		"title": "Ring",
		"hex": "1C9AD6",
		"source": "https://store.ring.com/press"
	},
	{
		"title": "Riot Games",
		"hex": "EB0029",
		"source": "https://www.riotgames.com/en/press"
	},
	{
		"title": "Ripple",
		"hex": "0085C0",
		"source": "https://www.ripple.com/media-kit/",
		"guidelines": "https://brand.ripple.com/document/44#/foundations/logo"
	},
	{
		"title": "RISC-V",
		"hex": "283272",
		"source": "https://riscv.org/risc-v-logo/",
		"guidelines": "https://riscv.org/about/risc-v-branding-guidelines/"
	},
	{
		"title": "Riseup",
		"hex": "FF0000",
		"source": "https://riseup.net/en/about-us/images"
	},
	{
		"title": "Ritz Carlton",
		"hex": "000000",
		"source": "https://www.ritzcarlton.com/en/about-the-ritz-carlton"
	},
	{
		"title": "Rive",
		"hex": "1D1D1D",
		"source": "https://rive.app"
	},
	{
		"title": "roadmap.sh",
		"hex": "000000",
		"source": "https://roadmap.sh"
	},
	{
		"title": "Roam Research",
		"hex": "343A40",
		"source": "https://roamresearch.com/#/app/help/page/Vu1MmjinS"
	},
	{
		"title": "Robinhood",
		"hex": "CCFF00",
		"source": "https://press.robinhood.com"
	},
	{
		"title": "Roblox",
		"hex": "000000",
		"source": "https://www.roblox.com",
		"guidelines": "https://en.help.roblox.com/hc/en-us/articles/115001708126-Roblox-Name-and-Logo-Community-Usage-Guidelines"
	},
	{
		"title": "Roblox Studio",
		"hex": "00A2FF",
		"source": "https://create.roblox.com"
	},
	{
		"title": "Roboflow",
		"hex": "6706CE",
		"source": "https://roboflow.com/press"
	},
	{
		"title": "Robot Framework",
		"hex": "000000",
		"source": "https://github.com/robotframework/visual-identity/blob/fadf8cda9f79ea31987a214f0047cca9626327b7/logo/robot-framework.svg",
		"guidelines": "https://github.com/robotframework/visual-identity/blob/fadf8cda9f79ea31987a214f0047cca9626327b7/robot-framework-brand-guidelines.pdf",
		"license": {
			"type": "CC-BY-NC-SA-4.0"
		}
	},
	{
		"title": "Rocket",
		"hex": "D33847",
		"source": "https://rocket.rs"
	},
	{
		"title": "Rocket.Chat",
		"hex": "F5455C",
		"source": "https://docs.rocket.chat/docs/media-kit"
	},
	{
		"title": "RocksDB",
		"hex": "2A2A2A",
		"source": "https://github.com/facebook/rocksdb/blob/9ed96703d11a1cf4af0e1c1db0e4a6057a8e5d42/docs/static/logo.svg",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "Rockstar Games",
		"hex": "FCAF17",
		"source": "https://www.rockstargames.com"
	},
	{
		"title": "Rockwell Automation",
		"hex": "CD163F",
		"source": "https://www.rockwellautomation.com/en-ie/company/news.html"
	},
	{
		"title": "Rocky Linux",
		"hex": "10B981",
		"source": "https://github.com/rocky-linux/branding/blob/94e97dd30b87d909cc4f6a6838a2926f77f9ac47/logo/src/icon-black.svg",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Roku",
		"hex": "662D91",
		"source": "https://www.roku.com",
		"guidelines": "https://docs.roku.com/published/trademarkguidelines/en/ca"
	},
	{
		"title": "Roll20",
		"hex": "E10085",
		"source": "https://roll20.net"
	},
	{
		"title": "Rolls-Royce",
		"hex": "281432",
		"source": "https://www.rolls-roycemotorcars.com"
	},
	{
		"title": "rollup.js",
		"hex": "EC4A3F",
		"source": "https://rollupjs.org"
	},
	{
		"title": "Rook",
		"hex": "2AC6EA",
		"source": "https://github.com/rook/artwork/blob/d252db9f43753e6abf64db0ce12d38916a5de464/logo/Rook_Icon.svg",
		"guidelines": "https://www.linuxfoundation.org/legal/trademark-usage",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Roon",
		"hex": "2039F3",
		"source": "https://help.roonlabs.com/portal/en/home"
	},
	{
		"title": "Root Me",
		"hex": "000000",
		"source": "https://www.root-me.org"
	},
	{
		"title": "Roots",
		"hex": "525DDC",
		"source": "https://roots.io/about/brand/",
		"guidelines": "https://roots.io/about/brand/"
	},
	{
		"title": "Roots Bedrock",
		"hex": "525DDC",
		"source": "https://roots.io/about/brand/"
	},
	{
		"title": "Roots Sage",
		"hex": "525DDC",
		"source": "https://roots.io/about/brand/"
	},
	{
		"title": "ROS",
		"hex": "22314E",
		"source": "https://www.ros.org/press-kit/",
		"guidelines": "https://www.ros.org/press-kit/"
	},
	{
		"title": "Rossmann",
		"hex": "C3002D",
		"source": "https://www.rossmann.de"
	},
	{
		"title": "Rotary International",
		"hex": "F7A81B",
		"source": "https://www.rotary.org/en",
		"guidelines": "https://my.rotary.org/en/rotary-identity-guidelines"
	},
	{
		"title": "Rotten Tomatoes",
		"hex": "FA320A",
		"source": "https://commons.wikimedia.org/wiki/File:Rottentomatoesalternativelogo.svg"
	},
	{
		"title": "Roundcube",
		"hex": "37BEFF",
		"source": "https://roundcube.net"
	},
	{
		"title": "RSocket",
		"hex": "EF0092",
		"source": "https://rsocket.io/img/r-socket-pink.svg"
	},
	{
		"title": "RSS",
		"hex": "FFA500",
		"source": "https://en.wikipedia.org/wiki/Feed_icon"
	},
	{
		"title": "RStudio IDE",
		"hex": "75AADB",
		"source": "https://www.rstudio.com/about/logos",
		"guidelines": "https://www.rstudio.com/about/logos"
	},
	{
		"title": "RTÉ",
		"hex": "00A7B3",
		"source": "https://www.rte.ie/archives/"
	},
	{
		"title": "RTL",
		"hex": "FA002E",
		"source": "https://www.rtl.de"
	},
	{
		"title": "RTLZWEI",
		"hex": "00BCF6",
		"source": "https://www.rtl2.de"
	},
	{
		"title": "RTM",
		"hex": "36474F",
		"source": "https://www.rtm.fr",
		"aliases": {
			"aka": [
				"Régie des Transports Métropolitains"
			],
			"old": [
				"Régie des Transports de Marseille"
			]
		}
	},
	{
		"title": "RuboCop",
		"hex": "000000",
		"source": "https://github.com/rubocop-semver/rubocop-ruby2_0/blob/5302f93058f7b739a73a7a6c11c566a2b196b96e/docs/images/logo/rubocop-light.svg",
		"license": {
			"type": "CC-BY-NC-4.0"
		}
	},
	{
		"title": "Ruby",
		"hex": "CC342D",
		"source": "https://www.ruby-lang.org/en/about/logo/",
		"license": {
			"type": "CC-BY-SA-2.5"
		}
	},
	{
		"title": "Ruby on Rails",
		"hex": "D30001",
		"source": "https://github.com/simple-icons/simple-icons/issues/9619#issuecomment-1735150580",
		"guidelines": "https://rubyonrails.org/trademarks/"
	},
	{
		"title": "Ruby Sinatra",
		"hex": "000000",
		"source": "https://github.com/sinatra/resources/tree/64c22f9b4bf2e52b5c0c875ba16671f295689efb/logo"
	},
	{
		"title": "RubyGems",
		"hex": "E9573F",
		"source": "https://rubygems.org/pages/about"
	},
	{
		"title": "RubyMine",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos",
		"guidelines": "https://www.jetbrains.com/company/brand"
	},
	{
		"title": "Ruff",
		"hex": "D7FF64",
		"source": "https://astral.sh/ruff"
	},
	{
		"title": "Rumahweb",
		"hex": "2EB4E3",
		"source": "https://www.rumahweb.com"
	},
	{
		"title": "Rumble",
		"hex": "85C742",
		"source": "https://rumble.com"
	},
	{
		"title": "Rundeck",
		"hex": "F73F39",
		"source": "https://github.com/rundeck/docs/blob/a1c98b682eb6e82b60de0daa876133f390630821/docs/.vuepress/public/images/rundeck-logo.svg"
	},
	{
		"title": "Runkeeper",
		"hex": "001E62",
		"source": "https://runkeeper.com/cms/press-kit",
		"guidelines": "https://runkeeper.com/cms/press-kit"
	},
	{
		"title": "RunKit",
		"hex": "491757",
		"source": "https://www.npmjs.com/package/@runkit/brand"
	},
	{
		"title": "Runrun.it",
		"hex": "DB3729",
		"source": "https://runrun.it/en-US/project-management-logos-icons",
		"guidelines": "https://runrun.it/en-US/project-management-logos-icons"
	},
	{
		"title": "Rust",
		"hex": "000000",
		"source": "https://www.rust-lang.org",
		"guidelines": "https://www.rust-lang.org/policies/media-guide",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "RustDesk",
		"hex": "024EFF",
		"source": "https://github.com/rustdesk/rustdesk/blob/80857c22c9ee1578b4329aec3250c3e6f285a7d2/res/logo.svg"
	},
	{
		"title": "RxDB",
		"hex": "8D1F89",
		"source": "https://github.com/pubkey/rxdb/blob/0c554dbcf7a4e6c48cd581ec1e3b130a4b5ab7d6/docs/files/logo/logo.svg"
	},
	{
		"title": "Ryanair",
		"hex": "073590",
		"source": "https://corporate.ryanair.com/media-centre/stock-images-gallery/#album-container-3"
	},
	{
		"title": "Rye",
		"hex": "000000",
		"source": "https://github.com/mitsuhiko/rye/blob/8b76d2a1a9d44c97ccbbcedceb72bc7437142caf/docs/static/favicon.svg"
	},
	{
		"title": "S7 Airlines",
		"hex": "C4D600",
		"source": "https://www.s7.ru/en/info/s7-airlines/brand/",
		"guidelines": "https://www.s7.ru/en/info/s7-airlines/brand/"
	},
	{
		"title": "Sabanci",
		"hex": "004B93",
		"source": "https://www.sabanci.com/en"
	},
	{
		"title": "Safari",
		"hex": "006CFF",
		"source": "https://apps.apple.com/us/app/safari/id1146562112"
	},
	{
		"title": "Sage",
		"hex": "00D639",
		"source": "https://www.sage.com"
	},
	{
		"title": "SageMath",
		"hex": "3333FF",
		"source": "https://github.com/sagemath/artwork/blob/dc51186a48f46ac9ff29e453491b8daf4c52ca15/sage-logo-2018.svg",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Sahibinden",
		"hex": "FFE800",
		"source": "https://www.sahibinden.com/favicon.ico"
	},
	{
		"title": "Sailfish OS",
		"hex": "053766",
		"source": "https://sailfishos.org"
	},
	{
		"title": "Sails.js",
		"hex": "14ACC2",
		"source": "https://sailsjs.com/logos",
		"guidelines": "https://sailsjs.com/logos"
	},
	{
		"title": "Salesforce",
		"hex": "00A1E0",
		"source": "https://brand.salesforce.com/content/logo-guidelines",
		"guidelines": "https://brand.salesforce.com/content/logo-guidelines"
	},
	{
		"title": "Salla",
		"hex": "BAF3E6",
		"source": "https://brand.salla.com",
		"guidelines": "https://brand.salla.com"
	},
	{
		"title": "Salt Project",
		"hex": "57BCAD",
		"source": "https://saltproject.io",
		"guidelines": "https://gitlab.com/saltstack/open/salt-branding-guide/-/blob/37bbc3a8577be2f44895310c092439472491a8f4/README.md",
		"license": {
			"type": "Apache-2.0"
		}
	},
	{
		"title": "Sam's Club",
		"hex": "0067A0",
		"source": "https://www.samsclub.com"
	},
	{
		"title": "Samsung",
		"hex": "1428A0",
		"source": "https://www.samsung.com/us/about-us/brand-identity/logo/",
		"guidelines": "https://www.samsung.com/us/about-us/brand-identity/logo/"
	},
	{
		"title": "Samsung Pay",
		"hex": "1428A0",
		"source": "https://pay.samsung.com/developers/resource/brand",
		"guidelines": "https://pay.samsung.com/developers/resource/brand"
	},
	{
		"title": "San Francisco Municipal Railway",
		"hex": "BA0C2F",
		"source": "https://www.actransit.org/wp-content/uploads/HSP_CC-sched.pdf"
	},
	{
		"title": "SanDisk",
		"hex": "ED1C24",
		"source": "https://kb.sandisk.com"
	},
	{
		"title": "Sanic",
		"hex": "FF0D68",
		"source": "https://github.com/sanic-org/sanic-assets/blob/79af646b7948fdfdc3b2f98d8aeedf58eba34b5b/svg/sanic-framework-logo-mono-black.svg"
	},
	{
		"title": "Sanity",
		"hex": "F03E2F",
		"source": "https://github.com/sanity-io/logos/blob/6934d28ae0b5f63b0386810997b8be61ec7009b5/src/sanityMonogram.tsx",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "São Paulo Metro",
		"hex": "004382",
		"source": "https://commons.wikimedia.org/wiki/File:Sao_Paulo_Metro_Logo.svg"
	},
	{
		"title": "SAP",
		"hex": "0FAAFF",
		"source": "https://www.sap.com"
	},
	{
		"title": "Sartorius",
		"hex": "FFED00",
		"source": "https://www.sartorius.com"
	},
	{
		"title": "Sass",
		"hex": "CC6699",
		"source": "https://sass-lang.com/styleguide/brand",
		"guidelines": "https://sass-lang.com/styleguide/brand",
		"license": {
			"type": "CC-BY-NC-SA-3.0"
		}
	},
	{
		"title": "Sat.1",
		"slug": "sat1",
		"hex": "047DA3",
		"source": "https://www.prosiebensat1.com/presse/downloads/logos"
	},
	{
		"title": "Satellite",
		"hex": "000000",
		"source": "https://www.satellite.me"
	},
	{
		"title": "Saturn",
		"hex": "EB680B",
		"source": "https://www.saturn.de"
	},
	{
		"title": "Sauce Labs",
		"hex": "3DDC91",
		"source": "https://saucelabs.com"
	},
	{
		"title": "Saudia",
		"hex": "026938",
		"source": "https://www.saudiatechnic.com/media-center/press-kit"
	},
	{
		"title": "Scala",
		"hex": "DC322F",
		"source": "https://www.scala-lang.org"
	},
	{
		"title": "Scalar",
		"hex": "1A1A1A",
		"source": "https://scalar.com"
	},
	{
		"title": "Scaleway",
		"hex": "4F0599",
		"source": "https://ultraviolet.scaleway.com",
		"guidelines": "https://ultraviolet.scaleway.com"
	},
	{
		"title": "Scania",
		"hex": "041E42",
		"source": "https://digitaldesign.scania.com/resources/brand/logotype",
		"guidelines": "https://digitaldesign.scania.com/resources/brand/logotype"
	},
	{
		"title": "Schneider Electric",
		"hex": "3DCD58",
		"source": "https://www.se.com/us/en/assets/739/media/202250/SE_logo-LIO-white_header.svg"
	},
	{
		"title": "scikit-learn",
		"hex": "F7931E",
		"source": "https://github.com/scikit-learn/scikit-learn/blob/c5ef2e985c13119001aa697e446ebb3dbcb326e5/doc/logos/scikit-learn-logo.svg"
	},
	{
		"title": "Scilab",
		"hex": "CD1925",
		"source": "https://gitlab.com/scilab/scilab/-/blob/599df2b32347029f4806a7c5fa2fe9d5f1293f0d/scilab/modules/gui/images/icons/scilabicon.svg"
	},
	{
		"title": "SciPy",
		"hex": "8CAAE6",
		"source": "https://github.com/scikit-image/skimage-branding/blob/eafb65cbc3a700e3d9c8ba2ba15788fcc8703984/logo/scipy.svg"
	},
	{
		"title": "Scopus",
		"hex": "E9711C",
		"source": "https://www.scopus.com"
	},
	{
		"title": "SCP Foundation",
		"hex": "FFFFFF",
		"source": "https://scp-wiki.wikidot.com"
	},
	{
		"title": "Scrapbox",
		"hex": "06B632",
		"source": "https://scrapbox.io/nota-press"
	},
	{
		"title": "Scrapy",
		"hex": "60A839",
		"source": "https://github.com/scrapy/scrapy.org/blob/d8e296f68c30664ffee3d142dd5d4c288d1e77c6/_brand/Scrapy%20Logo.eps"
	},
	{
		"title": "Scratch",
		"hex": "4D97FF",
		"source": "https://github.com/LLK/scratch-link/blob/027e3754ba6db976495e905023d5ac5e730dccfc/Assets/Windows/SVG/Windows%20Tray%20400x400.svg"
	},
	{
		"title": "Screencastify",
		"hex": "FF8282",
		"source": "https://www.screencastify.com"
	},
	{
		"title": "Scribd",
		"hex": "1E7B85",
		"source": "https://brand.scribd.com/d/oFZcsq7FVpSh/about-scribd#/media-press-kit/downloads",
		"guidelines": "https://brand.scribd.com/d/oFZcsq7FVpSh/about-scribd#/marketing-visual-guidelines/our-logo/our-logomark"
	},
	{
		"title": "Scrimba",
		"hex": "2B283A",
		"source": "https://scrimba.com"
	},
	{
		"title": "ScrollReveal",
		"hex": "FFCB36",
		"source": "https://scrollrevealjs.org"
	},
	{
		"title": "Scrum Alliance",
		"hex": "009FDA",
		"source": "https://www.scrumalliance.org/ScrumRedesignDEVSite/media/ScrumAllianceMedia/Files%20and%20PDFs/Infographics/S_BrandGuidelines_2018_rev.pdf",
		"guidelines": "https://www.scrumalliance.org/ScrumRedesignDEVSite/media/ScrumAllianceMedia/Files%20and%20PDFs/Infographics/S_BrandGuidelines_2018_rev.pdf"
	},
	{
		"title": "Scrutinizer CI",
		"hex": "8A9296",
		"source": "https://scrutinizer-ci.com"
	},
	{
		"title": "ScyllaDB",
		"hex": "6CD5E7",
		"source": "https://www.scylladb.com/media-kit",
		"guidelines": "https://www.scylladb.com/media-kit"
	},
	{
		"title": "Seagate",
		"hex": "6EBE49",
		"source": "https://branding.seagate.com/productpage/3fc51aba-c35a-4eff-a833-a258b0440bd2"
	},
	{
		"title": "SearXNG",
		"hex": "3050FF",
		"source": "https://docs.searxng.org"
	},
	{
		"title": "SEAT",
		"hex": "33302E",
		"source": "https://www.seat.es"
	},
	{
		"title": "SeatGeek",
		"hex": "FF5B49",
		"source": "https://seatgeek.com/press",
		"guidelines": "https://seatgeek.com/press"
	},
	{
		"title": "SecurityScorecard",
		"hex": "7033FD",
		"source": "https://securityscorecard.com"
	},
	{
		"title": "Sefaria",
		"hex": "212E50",
		"source": "https://github.com/Sefaria/Sefaria-Project/blob/c141b2b3491660ed563df9f4b1a2e4c071e88688/static/img/logo/samekh.svg"
	},
	{
		"title": "Sega",
		"hex": "0089CF",
		"source": "https://commons.wikimedia.org/wiki/File:SEGA_logo.svg"
	},
	{
		"title": "Selenium",
		"hex": "43B02A",
		"source": "https://github.com/SeleniumHQ/heroku-selenium/blob/2f66891ba030d3aa1f36ab1748c52ba4fb4e057d/selenium-green.svg"
	},
	{
		"title": "Sellfy",
		"hex": "21B352",
		"source": "https://sellfy.com/about/"
	},
	{
		"title": "Semantic Scholar",
		"hex": "1857B6",
		"source": "https://www.semanticscholar.org/about"
	},
	{
		"title": "Semantic UI",
		"hex": "00B5AD",
		"source": "https://semantic-ui.com"
	},
	{
		"title": "Semantic UI React",
		"hex": "35BDB2",
		"source": "https://react.semantic-ui.com"
	},
	{
		"title": "Semantic Web",
		"hex": "005A9C",
		"source": "https://www.w3.org/2007/10/sw-logos.html"
	},
	{
		"title": "semantic-release",
		"hex": "494949",
		"source": "https://github.com/semantic-release/semantic-release/blob/85bc213f04445a9bb8f19e5d45d6ecd7acccf841/media/semantic-release-logo.svg"
	},
	{
		"title": "Semaphore CI",
		"hex": "19A974",
		"source": "https://semaphoreci.com"
	},
	{
		"title": "Semrush",
		"hex": "FF642D",
		"source": "https://www.semrush.com"
	},
	{
		"title": "SemVer",
		"hex": "3F4551",
		"source": "https://github.com/semver/semver.org/blob/b6983849e38911195a24357809187c2f50af0d40/assets/500x500(light).jpg"
	},
	{
		"title": "Sencha",
		"hex": "86BC40",
		"source": "https://design.sencha.com",
		"guidelines": "https://design.sencha.com/productlogo.html"
	},
	{
		"title": "SendGrid",
		"hex": "51A9E3",
		"source": "https://sendgrid.com/en-us/resource/brand",
		"guidelines": "https://sendgrid.com/en-us/resource/brand"
	},
	{
		"title": "Sennheiser",
		"hex": "000000",
		"source": "https://sennheiser.com"
	},
	{
		"title": "Sensu",
		"hex": "89C967",
		"source": "https://github.com/sensu/web/blob/c823738c11e576d6b2e5d4ca2d216dbd472c0b11/src/assets/logo/graphic/green.svg"
	},
	{
		"title": "Sentry",
		"hex": "362D59",
		"source": "https://sentry.io/branding/"
	},
	{
		"title": "SEPA",
		"hex": "2350A9",
		"source": "https://www.europeanpaymentscouncil.eu/document-library/other/sepa-logo-vector-format",
		"guidelines": "https://www.europeanpaymentscouncil.eu/document-library/other/sepa-logo-visual-identity-guidelines"
	},
	{
		"title": "Sequelize",
		"hex": "52B0E7",
		"source": "https://github.com/sequelize/website/blob/e6a482fa58a839b15ace80e3c8901ed2887be45e/static/img/logo-simple.svg"
	},
	{
		"title": "Server Fault",
		"hex": "E7282D",
		"source": "https://stackoverflow.com/company/logos",
		"guidelines": "https://stackoverflow.com/legal/trademark-guidance"
	},
	{
		"title": "Serverless",
		"hex": "FD5750",
		"source": "https://serverless.com"
	},
	{
		"title": "Session",
		"hex": "000000",
		"source": "https://getsession.org"
	},
	{
		"title": "Sessionize",
		"hex": "1AB394",
		"source": "https://sessionize.com/brand"
	},
	{
		"title": "Setapp",
		"hex": "E6C3A5",
		"source": "https://setapp.com"
	},
	{
		"title": "SFML",
		"hex": "8CC445",
		"source": "https://www.sfml-dev.org/download/goodies/"
	},
	{
		"title": "shadcn/ui",
		"hex": "000000",
		"source": "https://ui.shadcn.com"
	},
	{
		"title": "Shadow",
		"hex": "0A0C0D",
		"source": "https://shadow.tech"
	},
	{
		"title": "Shanghai Metro",
		"hex": "EC1C24",
		"source": "https://en.wikipedia.org/wiki/File:Shanghai_Metro_Full_Logo.svg"
	},
	{
		"title": "ShareX",
		"hex": "2885F1",
		"source": "https://getsharex.com/brand-assets"
	},
	{
		"title": "sharp",
		"hex": "99CC00",
		"source": "https://github.com/lovell/sharp/blob/315f519e1dd9adca0678e94a5ed0492cb5e0aae4/docs/image/sharp-logo-mono.svg"
	},
	{
		"title": "Shazam",
		"hex": "0088FF",
		"source": "https://shazam.com"
	},
	{
		"title": "Shell",
		"hex": "FFD500",
		"source": "https://en.wikipedia.org/wiki/File:Shell_logo.svg"
	},
	{
		"title": "Shelly",
		"hex": "4495D1",
		"source": "https://shelly.com"
	},
	{
		"title": "Shenzhen Metro",
		"hex": "009943",
		"source": "https://en.wikipedia.org/wiki/File:Shenzhen_Metro_Corporation_logo_full.svg"
	},
	{
		"title": "Shields.io",
		"hex": "000000",
		"source": "https://shields.io"
	},
	{
		"title": "Shikimori",
		"hex": "343434",
		"source": "https://shikimori.one"
	},
	{
		"title": "Shopee",
		"hex": "EE4D2D",
		"source": "https://shopee.com"
	},
	{
		"title": "Shopify",
		"hex": "7AB55C",
		"source": "https://www.shopify.com/brand-assets",
		"guidelines": "https://www.shopify.com/brand-assets"
	},
	{
		"title": "Shopware",
		"hex": "189EFF",
		"source": "https://www.shopware.com/en/press/press-material/"
	},
	{
		"title": "Shortcut",
		"hex": "58B1E4",
		"source": "https://www.shortcut.com/branding",
		"guidelines": "https://www.shortcut.com/branding"
	},
	{
		"title": "Showpad",
		"hex": "2D2E83",
		"source": "https://www.showpad.com"
	},
	{
		"title": "Showtime",
		"hex": "B10000",
		"source": "https://commons.wikimedia.org/wiki/File:Showtime.svg"
	},
	{
		"title": "Showwcase",
		"hex": "0A0D14",
		"source": "https://www.showwcase.com"
	},
	{
		"title": "Shutterstock",
		"hex": "EE2B24",
		"source": "https://shutterstock.com/es/discover/brand-downloads",
		"guidelines": "https://shutterstock.com/es/discover/brand-downloads"
	},
	{
		"title": "Sidekiq",
		"hex": "B1003E",
		"source": "https://sidekiq.org/about.html",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "SideQuest",
		"hex": "101227",
		"source": "https://sidequestvr.com/branding",
		"guidelines": "https://sidequestvr.com/branding"
	},
	{
		"title": "Siemens",
		"hex": "009999",
		"source": "https://siemens.com"
	},
	{
		"title": "SiFive",
		"hex": "252323",
		"source": "https://www.sifive.com",
		"guidelines": "https://www.sifive.com/terms"
	},
	{
		"title": "Signal",
		"hex": "3B45FD",
		"source": "https://signal.org/brand",
		"guidelines": "https://signal.org/brand"
	},
	{
		"title": "Silver Airways",
		"hex": "D0006F",
		"source": "https://www.silverairways.com"
	},
	{
		"title": "Similarweb",
		"hex": "092540",
		"source": "https://www.similarweb.com"
	},
	{
		"title": "Simkl",
		"hex": "000000",
		"source": "https://simkl.com"
	},
	{
		"title": "Simple Analytics",
		"hex": "FF4F64",
		"source": "https://simpleanalytics.com",
		"guidelines": "https://simpleanalytics.com/press"
	},
	{
		"title": "Simple Icons",
		"hex": "111111",
		"source": "https://simpleicons.org",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "SimpleLogin",
		"hex": "EA319F",
		"source": "https://simplelogin.io/press"
	},
	{
		"title": "Simplenote",
		"hex": "3361CC",
		"source": "https://en.wikipedia.org/wiki/File:Simplenote_logo.svg"
	},
	{
		"title": "SimpleX",
		"hex": "000000",
		"source": "https://github.com/simplex-chat/simplex-chat/blob/2f730d54e9858452e87e641b7fd618c669da68aa/website/src/img/new/logo-symbol-light.svg"
	},
	{
		"title": "Sina Weibo",
		"hex": "E6162D",
		"source": "https://en.wikipedia.org/wiki/Sina_Weibo"
	},
	{
		"title": "Singapore Airlines",
		"hex": "F99F1C",
		"source": "https://www.singaporeair.com"
	},
	{
		"title": "SingleStore",
		"hex": "AA00FF",
		"source": "https://www.singlestore.com/brand/"
	},
	{
		"title": "Sitecore",
		"hex": "EB1F1F",
		"source": "https://www.sitecore.com"
	},
	{
		"title": "SitePoint",
		"hex": "258AAF",
		"source": "https://www.sitepoint.com"
	},
	{
		"title": "SiYuan",
		"hex": "D23F31",
		"source": "https://b3log.org/brand-marking.html",
		"aliases": {
			"aka": [
				"sy"
			],
			"loc": {
				"zh-CN": "思源笔记",
				"zh-HK": "思源筆記",
				"zh-MO": "思源筆記",
				"zh-MY": "思源笔记",
				"zh-SG": "思源笔记",
				"zh-TW": "思源筆記"
			}
		}
	},
	{
		"title": "Skaffold",
		"hex": "2AA2D6",
		"source": "https://github.com/GoogleContainerTools/skaffold/blob/9376dc047aded2adb188f599267fbb829a327dfd/logo/skaffold.eps"
	},
	{
		"title": "Sketch",
		"hex": "F7B500",
		"source": "https://www.sketch.com/about-us/#press",
		"guidelines": "https://www.sketch.com/about-us/#press"
	},
	{
		"title": "Sketchfab",
		"hex": "1CAAD9",
		"source": "https://sketchfab.com/press"
	},
	{
		"title": "SketchUp",
		"hex": "005F9E",
		"source": "https://www.sketchup.com"
	},
	{
		"title": "Skillshare",
		"hex": "00FF84",
		"source": "https://www.skillshare.com"
	},
	{
		"title": "ŠKODA",
		"hex": "0E3A2F",
		"source": "https://www.skoda-connect.com"
	},
	{
		"title": "Sky",
		"hex": "0072C9",
		"source": "https://www.skysports.com"
	},
	{
		"title": "Skypack",
		"hex": "3167FF",
		"source": "https://skypack.dev"
	},
	{
		"title": "Slack",
		"hex": "4A154B",
		"source": "https://slack.com/brand-guidelines",
		"guidelines": "https://slack.com/brand-guidelines"
	},
	{
		"title": "Slackware",
		"hex": "000000",
		"source": "https://en.wikipedia.org/wiki/Slackware"
	},
	{
		"title": "Slashdot",
		"hex": "026664",
		"source": "https://commons.wikimedia.org/wiki/File:Slashdot_wordmark_and_logo.svg"
	},
	{
		"title": "SlickPic",
		"hex": "FF880F",
		"source": "https://www.slickpic.com"
	},
	{
		"title": "Slides",
		"hex": "E4637C",
		"source": "https://slides.com/about"
	},
	{
		"title": "SlideShare",
		"hex": "008ED2",
		"source": "https://www.slideshare.net/ss/creators/"
	},
	{
		"title": "Slint",
		"hex": "2379F4",
		"source": "https://github.com/slint-ui/slint/blob/10ae5cd60ab3fcd01ef89a300c97e2e0952bc750/logo/slint-logo-full-dark.png",
		"guidelines": "https://github.com/slint-ui/slint/blob/master/logo/README.md",
		"license": {
			"type": "CC-BY-ND-4.0"
		}
	},
	{
		"title": "smart",
		"hex": "D7E600",
		"source": "https://global.smart.com"
	},
	{
		"title": "SmartThings",
		"hex": "15BFFF",
		"source": "https://www.smartthings.com/press-kit",
		"guidelines": "https://www.smartthings.com/press-kit"
	},
	{
		"title": "Smashing Magazine",
		"hex": "E85C33",
		"source": "https://www.smashingmagazine.com"
	},
	{
		"title": "SMRT",
		"hex": "EE2E24",
		"source": "https://commons.wikimedia.org/wiki/File:SMRT_Corporation.svg"
	},
	{
		"title": "SmugMug",
		"hex": "6DB944",
		"source": "https://www.smugmughelp.com/articles/409-smugmug-s-logo-and-usage"
	},
	{
		"title": "Snapchat",
		"hex": "FFFC00",
		"source": "https://www.snapchat.com/brand-guidelines",
		"guidelines": "https://www.snapchat.com/brand-guidelines"
	},
	{
		"title": "Snapcraft",
		"hex": "82BEA0",
		"source": "https://github.com/snapcore/snap-store-badges/tree/eda2cb0495ef7f4d479e231079967c9d27f2bc70",
		"license": {
			"type": "CC-BY-ND-2.0"
		}
	},
	{
		"title": "Snapdragon",
		"hex": "C33139",
		"source": "https://commons.wikimedia.org/wiki/File:Snapdragon_Logo.svg",
		"aliases": {
			"aka": [
				"Qualcomm Snapdragon"
			]
		}
	},
	{
		"title": "SNCF",
		"hex": "CA0939",
		"source": "https://www.sncf.com",
		"guidelines": "https://www.sncf.com/fr/groupe/marques/sncf/identite"
	},
	{
		"title": "Snort",
		"hex": "F6A7AA",
		"source": "https://snort.org"
	},
	{
		"title": "Snowflake",
		"hex": "29B5E8",
		"source": "https://www.snowflake.com/brand-guidelines/",
		"guidelines": "https://www.snowflake.com/brand-guidelines/"
	},
	{
		"title": "Snowpack",
		"hex": "2E5E82",
		"source": "https://www.snowpack.dev"
	},
	{
		"title": "Snyk",
		"hex": "4C4A73",
		"source": "https://snyk.io/press-kit"
	},
	{
		"title": "Social Blade",
		"hex": "B3382C",
		"source": "https://socialblade.com/info/media"
	},
	{
		"title": "Society6",
		"hex": "000000",
		"source": "https://society6.com"
	},
	{
		"title": "Socket",
		"hex": "C93CD7",
		"source": "https://github.com/SocketDev/vscode-socket-security/blob/06c5fdc59fad40ae87b3d42c5c42cd17c6edaf17/logo-red.svg"
	},
	{
		"title": "Socket.io",
		"hex": "010101",
		"source": "https://socket.io"
	},
	{
		"title": "Softcatalà",
		"hex": "BA2626",
		"source": "https://www.softcatala.org/uploads/2016/03/SC_marca.svg",
		"guidelines": "https://www.softcatala.org/premsa/imatge-corporativa",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Softpedia",
		"hex": "002873",
		"source": "https://commons.wikimedia.org/wiki/File:Softpedia_logo.svg"
	},
	{
		"title": "Sogou",
		"hex": "FB6022",
		"source": "https://www.sogou.com"
	},
	{
		"title": "Solana",
		"hex": "9945FF",
		"source": "https://solana.com/branding",
		"guidelines": "https://solana.com/branding"
	},
	{
		"title": "Solid",
		"hex": "2C4F7C",
		"source": "https://www.solidjs.com/media"
	},
	{
		"title": "Solidity",
		"hex": "363636",
		"source": "https://docs.soliditylang.org/en/v0.8.6/brand-guide.html",
		"guidelines": "https://docs.soliditylang.org/en/v0.8.6/brand-guide.html",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "Sololearn",
		"hex": "149EF2",
		"source": "https://www.sololearn.com",
		"aliases": {
			"aka": [
				"SoloLearn"
			]
		}
	},
	{
		"title": "Solus",
		"hex": "5294E2",
		"source": "https://getsol.us/branding/"
	},
	{
		"title": "Sonar",
		"hex": "FD3456",
		"source": "https://www.sonarsource.com"
	},
	{
		"title": "SonarCloud",
		"hex": "F3702A",
		"source": "https://sonarcloud.io/about"
	},
	{
		"title": "SonarLint",
		"hex": "CB2029",
		"source": "https://www.sonarlint.org/logos/",
		"guidelines": "https://www.sonarlint.org/logos/"
	},
	{
		"title": "SonarQube",
		"hex": "4E9BCD",
		"source": "https://www.sonarqube.org/logos/",
		"guidelines": "https://www.sonarqube.org/logos/"
	},
	{
		"title": "sonarr",
		"hex": "2596BE",
		"source": "https://github.com/Sonarr/Sonarr/blob/913b845faadc3c9fc005abfba815426743d01bdf/Logo/Sonarr.svg"
	},
	{
		"title": "Sonatype",
		"hex": "1B1C30",
		"source": "https://www.sonatype.com/company/press-kit",
		"guidelines": "https://www.sonatype.com/company/press-kit"
	},
	{
		"title": "Songkick",
		"hex": "F80046",
		"source": "https://www.songkick.com/style-guide/design",
		"guidelines": "https://www.songkick.com/style-guide/design"
	},
	{
		"title": "Songoda",
		"hex": "FC494A",
		"source": "https://songoda.com/branding",
		"guidelines": "https://songoda.com/branding"
	},
	{
		"title": "SonicWall",
		"hex": "FF791A",
		"source": "https://brandfolder.com/sonicwall/sonicwall-external"
	},
	{
		"title": "Sonos",
		"hex": "000000",
		"source": "https://www.sonos.com/en-gb/home"
	},
	{
		"title": "Sony",
		"hex": "FFFFFF",
		"source": "https://www.sony.com"
	},
	{
		"title": "Soriana",
		"hex": "D52B1E",
		"source": "https://www.soriana.com"
	},
	{
		"title": "Soundcharts",
		"hex": "0C1528",
		"source": "https://soundcharts.com/img/soundcharts-logo.svg"
	},
	{
		"title": "SoundCloud",
		"hex": "FF5500",
		"source": "https://press.soundcloud.com"
	},
	{
		"title": "Source Engine",
		"hex": "F79A10",
		"source": "https://developer.valvesoftware.com/favicon.ico"
	},
	{
		"title": "SourceForge",
		"hex": "FF6600",
		"source": "https://sourceforge.net"
	},
	{
		"title": "SourceHut",
		"hex": "000000",
		"source": "https://sourcehut.org/logo/",
		"guidelines": "https://sourcehut.org/logo/",
		"license": {
			"type": "CC0-1.0"
		}
	},
	{
		"title": "Sourcetree",
		"hex": "0052CC",
		"source": "https://atlassian.design/resources/logo-library",
		"guidelines": "https://atlassian.design/foundations/logos/"
	},
	{
		"title": "Southwest Airlines",
		"hex": "304CB2",
		"source": "https://www.southwest.com"
	},
	{
		"title": "Spacemacs",
		"hex": "9266CC",
		"source": "https://www.spacemacs.org",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Spaceship",
		"hex": "394EFF",
		"source": "https://www.spaceship.com"
	},
	{
		"title": "SpaceX",
		"hex": "000000",
		"source": "https://www.spacex.com"
	},
	{
		"title": "spaCy",
		"hex": "09A3D5",
		"source": "https://github.com/explosion/spaCy/blob/c17980e535a8009b14ee4d1f818db207d9c07e55/website/src/images/logo.svg"
	},
	{
		"title": "Spark AR",
		"hex": "FF5C83",
		"source": "https://sparkar.facebook.com"
	},
	{
		"title": "Sparkasse",
		"hex": "FF0000",
		"source": "https://www.sparkasse.de",
		"guidelines": "https://www.sparkasse.de/nutzungshinweise.html"
	},
	{
		"title": "SparkFun",
		"hex": "E53525",
		"source": "https://www.sparkfun.com/brand_assets",
		"guidelines": "https://www.sparkfun.com/brand_assets"
	},
	{
		"title": "SparkPost",
		"hex": "FA6423",
		"source": "https://www.sparkpost.com/press-kit/",
		"guidelines": "https://www.sparkpost.com/press-kit/"
	},
	{
		"title": "SPDX",
		"hex": "4398CC",
		"source": "https://spdx.org/Resources"
	},
	{
		"title": "Speaker Deck",
		"hex": "009287",
		"source": "https://speakerdeck.com"
	},
	{
		"title": "Spectrum",
		"hex": "7B16FF",
		"source": "https://spectrum.chat"
	},
	{
		"title": "Speedtest",
		"hex": "141526",
		"source": "https://www.speedtest.net"
	},
	{
		"title": "SpeedyPage",
		"hex": "1C71F9",
		"source": "https://speedypage.com"
	},
	{
		"title": "Sphere Online Judge",
		"slug": "spoj",
		"hex": "337AB7",
		"source": "https://www.spoj.com",
		"aliases": {
			"aka": [
				"SPOJ"
			]
		}
	},
	{
		"title": "Sphinx",
		"hex": "000000",
		"source": "https://github.com/sphinx-doc/sphinx/blob/ed84d63e6f2c4fd43b97fc43ee8be4156a13af9e/doc/_static/favicon.svg",
		"license": {
			"type": "BSD-3-Clause"
		}
	},
	{
		"title": "SpigotMC",
		"hex": "ED8106",
		"source": "https://www.spigotmc.org"
	},
	{
		"title": "Spine",
		"hex": "FF4000",
		"source": "https://esotericsoftware.com/branding",
		"guidelines": "https://esotericsoftware.com/branding"
	},
	{
		"title": "Spinnaker",
		"hex": "139BB4",
		"source": "https://github.com/spinnaker/spinnaker.github.io/tree/0cdd37af7541293a810494a1bb4d7df9ef553d60/assets/images"
	},
	{
		"title": "Splunk",
		"hex": "000000",
		"source": "https://www.splunk.com"
	},
	{
		"title": "Spond",
		"hex": "EE4353",
		"source": "https://spond.com"
	},
	{
		"title": "Spotify",
		"hex": "1ED760",
		"source": "https://developer.spotify.com/documentation/general/design-and-branding/#using-our-logo",
		"guidelines": "https://developer.spotify.com/documentation/general/design-and-branding/#using-our-logo"
	},
	{
		"title": "Spotlight",
		"hex": "352A71",
		"source": "https://www.spotlight.com"
	},
	{
		"title": "Spreadshirt",
		"hex": "00B2A5",
		"source": "https://www.spreadshirt.ie",
		"aliases": {
			"dup": [
				{
					"title": "Spreadshop",
					"hex": "FF9343",
					"source": "https://www.spreadshop.com"
				}
			]
		}
	},
	{
		"title": "Spreaker",
		"hex": "F5C300",
		"source": "https://www.spreaker.com"
	},
	{
		"title": "Spring",
		"hex": "6DB33F",
		"source": "https://spring.io/trademarks"
	},
	{
		"title": "Spring",
		"slug": "spring_creators",
		"hex": "000000",
		"source": "https://www.spri.ng"
	},
	{
		"title": "Spring Boot",
		"hex": "6DB33F",
		"source": "https://spring.io/projects"
	},
	{
		"title": "Spring Security",
		"hex": "6DB33F",
		"source": "https://spring.io/projects"
	},
	{
		"title": "Spyder IDE",
		"hex": "8C0000",
		"source": "https://github.com/spyder-ide/spyder/blob/f384133b1f10678aabda81cac30785698590c3f0/branding/logo/logomark/spyder-logomark.svg"
	},
	{
		"title": "SQLAlchemy",
		"hex": "D71F00",
		"source": "https://commons.wikimedia.org/wiki/File:SQLAlchemy.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "SQLite",
		"hex": "003B57",
		"source": "https://github.com/sqlite/sqlite/blob/43e862723ec680542ca6f608f9963c0993dd7324/art/sqlite370.eps"
	},
	{
		"title": "Square",
		"hex": "3E4348",
		"source": "https://squareup.com"
	},
	{
		"title": "Square Enix",
		"hex": "ED1C24",
		"source": "https://www.square-enix.com"
	},
	{
		"title": "Squarespace",
		"hex": "000000",
		"source": "https://www.squarespace.com/logo-guidelines",
		"guidelines": "https://www.squarespace.com/brand-guidelines"
	},
	{
		"title": "SRG SSR",
		"hex": "AF001E",
		"source": "https://www.srgssr.ch/en/news-media/downloads/logos",
		"aliases": {
			"loc": {
				"ch-DE": "Schweizerische Radio- und Fernsehgesellschaft",
				"ch-FR": "Société suisse de radiodiffusion et télévision",
				"ch-IT": "Società svizzera di radiotelevisione",
				"ch-RM": "Societad Svizra da Radio e Televisiun",
				"gb-EN": "Swiss Broadcasting Corporation"
			}
		}
	},
	{
		"title": "SSRN",
		"hex": "154881",
		"source": "https://www.ssrn.com"
	},
	{
		"title": "SST",
		"hex": "E27152",
		"source": "https://sst.dev",
		"guidelines": "https://github.com/serverless-stack/identity"
	},
	{
		"title": "Stack Exchange",
		"hex": "1E5397",
		"source": "https://stackoverflow.com/company/logos",
		"guidelines": "https://stackoverflow.com/legal/trademark-guidance"
	},
	{
		"title": "Stack Overflow",
		"hex": "F58025",
		"source": "https://stackoverflow.design/brand/logo/",
		"guidelines": "https://stackoverflow.com/legal/trademark-guidance"
	},
	{
		"title": "Stackbit",
		"hex": "207BEA",
		"source": "https://www.stackbit.com/branding-guidelines/",
		"guidelines": "https://www.stackbit.com/branding-guidelines/"
	},
	{
		"title": "StackBlitz",
		"hex": "1269D3",
		"source": "https://stackblitz.com"
	},
	{
		"title": "StackEdit",
		"hex": "606060",
		"source": "https://github.com/benweet/stackedit/blob/46383b5b6a54b65b8720d786ed0a0518b9ad652d/src/assets/iconStackedit.svg"
	},
	{
		"title": "StackHawk",
		"hex": "00CBC6",
		"source": "https://www.stackhawk.com/press/"
	},
	{
		"title": "StackShare",
		"hex": "0690FA",
		"source": "https://stackshare.io/branding"
	},
	{
		"title": "Stadia",
		"hex": "CD2640",
		"source": "https://stadia.google.com/home"
	},
	{
		"title": "Staffbase",
		"hex": "00A4FD",
		"source": "https://staffbase.com/en/about/press-assets/"
	},
	{
		"title": "Stagetimer",
		"hex": "00A66C",
		"source": "https://stagetimer.io"
	},
	{
		"title": "Standard Resume",
		"hex": "2A3FFB",
		"source": "https://standardresume.co/press"
	},
	{
		"title": "StandardJS",
		"hex": "F3DF49",
		"source": "https://github.com/standard/standard/blob/6516bf87f127b7968c34cac0100d48d6c455a891/sticker.svg"
	},
	{
		"title": "Star Trek",
		"hex": "FFE200",
		"source": "https://intl.startrek.com"
	},
	{
		"title": "Starbucks",
		"hex": "006241",
		"source": "https://starbucks.com",
		"guidelines": "https://creative.starbucks.com"
	},
	{
		"title": "Stardock",
		"hex": "004B8D",
		"source": "https://www.stardock.com/press/stardock%20branding/"
	},
	{
		"title": "Starling Bank",
		"hex": "6935D3",
		"source": "https://www.starlingbank.com/media/",
		"guidelines": "https://www.starlingbank.com/docs/brand/starling-bank-brand-guidelines.pdf"
	},
	{
		"title": "Starship",
		"hex": "DD0B78",
		"source": "https://starship.rs"
	},
	{
		"title": "start.gg",
		"hex": "2E75BA",
		"source": "https://help.start.gg/en/articles/1716774-start-gg-brand-guidelines",
		"guidelines": "https://help.start.gg/en/articles/1716774-start-gg-brand-guidelines"
	},
	{
		"title": "Startpage",
		"hex": "6563FF",
		"source": "https://startpage.com/en/about-us"
	},
	{
		"title": "STARZ",
		"hex": "082125",
		"source": "https://www.starz.com/takethelead"
	},
	{
		"title": "Statamic",
		"hex": "FF269E",
		"source": "https://statamic.com/branding",
		"guidelines": "https://statamic.com/branding"
	},
	{
		"title": "Statista",
		"hex": "001327",
		"source": "https://www.statista.com"
	},
	{
		"title": "Statuspage",
		"hex": "172B4D",
		"source": "https://www.atlassian.com/company/news/press-kit"
	},
	{
		"title": "Statuspal",
		"hex": "4934BF",
		"source": "https://statuspal.io"
	},
	{
		"title": "Steam",
		"hex": "000000",
		"source": "https://partner.steamgames.com/doc/marketing/branding",
		"guidelines": "https://partner.steamgames.com/doc/marketing/branding"
	},
	{
		"title": "Steam Deck",
		"hex": "1A9FFF",
		"source": "https://partner.steamgames.com/doc/marketing/branding",
		"guidelines": "https://partner.steamgames.com/doc/marketing/branding"
	},
	{
		"title": "SteamDB",
		"hex": "000000",
		"source": "https://steamdb.info"
	},
	{
		"title": "Steamworks",
		"hex": "1E1E1E",
		"source": "https://partner.steamgames.com"
	},
	{
		"title": "Steelseries",
		"hex": "FF5200",
		"source": "https://techblog.steelseries.com/ux-guide/index.html"
	},
	{
		"title": "Steem",
		"hex": "171FC9",
		"source": "https://steem.com/brand/"
	},
	{
		"title": "Steemit",
		"hex": "06D6A9",
		"source": "https://steemit.com"
	},
	{
		"title": "Steinberg",
		"hex": "C90827",
		"source": "https://new.steinberg.net/press/"
	},
	{
		"title": "Stellar",
		"hex": "7D00FF",
		"source": "https://www.stellar.org/press"
	},
	{
		"title": "Stencil",
		"hex": "5530FF",
		"source": "https://ionic.io/ionicons"
	},
	{
		"title": "Stencyl",
		"hex": "8E1C04",
		"source": "https://www.stencyl.com/about/press/"
	},
	{
		"title": "Stimulus",
		"hex": "77E8B9",
		"source": "https://stimulus.hotwire.dev"
	},
	{
		"title": "STMicroelectronics",
		"hex": "03234B",
		"source": "https://www.st.com"
	},
	{
		"title": "StockX",
		"hex": "006340",
		"source": "https://stockx.com/about/brand-assets"
	},
	{
		"title": "StopStalk",
		"hex": "536DFE",
		"source": "https://github.com/stopstalk/media-resources/blob/265b728c26ba597b957e72134a3b49a10dc0c91d/stopstalk-small-black.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Storyblok",
		"hex": "09B3AF",
		"source": "https://www.storyblok.com/press",
		"guidelines": "https://www.storyblok.com/press"
	},
	{
		"title": "Storybook",
		"hex": "FF4785",
		"source": "https://github.com/storybookjs/brand/tree/6f4d67f65f8275c53c310a73a8da6c6e96c8488c",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Strapi",
		"hex": "4945FF",
		"source": "https://handbook.strapi.io/strapi-brand-book-2022/strapi-logo",
		"guidelines": "https://handbook.strapi.io/strapi-brand-book-2022"
	},
	{
		"title": "Strava",
		"hex": "FC4C02",
		"source": "https://itunes.apple.com/us/app/strava-running-and-cycling-gps/id426826309"
	},
	{
		"title": "Streamlabs",
		"hex": "80F5D2",
		"source": "https://streamlabs.com/about"
	},
	{
		"title": "Streamlit",
		"hex": "FF4B4B",
		"source": "https://www.streamlit.io/brand",
		"guidelines": "https://www.streamlit.io/brand"
	},
	{
		"title": "StreamRunners",
		"hex": "6644F8",
		"source": "https://streamrunners.fr"
	},
	{
		"title": "Stremio",
		"hex": "685CEE",
		"source": "https://github.com/Stremio/stremio-brand/blob/3f3743087b11e81374cf943aaf1e041af1c97ee3/logos/SVG/stremio-logo-icon-only-fullcolor.svg"
	},
	{
		"title": "Stripe",
		"hex": "635BFF",
		"source": "https://stripe.com/newsroom/information"
	},
	{
		"title": "strongSwan",
		"hex": "E00033",
		"source": "https://strongswan.org"
	},
	{
		"title": "Stryker",
		"hex": "E74C3C",
		"source": "https://stryker-mutator.io"
	},
	{
		"title": "StubHub",
		"hex": "003168",
		"source": "https://www.stubhub.com"
	},
	{
		"title": "Studio 3T",
		"hex": "17AF66",
		"source": "https://studio3t.com"
	},
	{
		"title": "styled-components",
		"hex": "DB7093",
		"source": "https://www.styled-components.com"
	},
	{
		"title": "stylelint",
		"hex": "263238",
		"source": "https://github.com/stylelint/stylelint/blob/1f7bbb2d189b3e27b42de25f2948e3e5eec1b759/identity/stylelint-icon-black.svg"
	},
	{
		"title": "StyleShare",
		"hex": "212121",
		"source": "https://www.stylesha.re"
	},
	{
		"title": "Stylus",
		"hex": "333333",
		"source": "https://github.com/stylus/stylus-lang.com/blob/c833bf697e39e1174c7c6e679e0e5a23d0baeb90/img/stylus-logo.svg"
	},
	{
		"title": "Subaru",
		"hex": "013C74",
		"source": "https://commons.wikimedia.org/wiki/File:Subaru_logo.svg"
	},
	{
		"title": "Sublime Text",
		"hex": "FF9800",
		"source": "https://www.sublimetext.com"
	},
	{
		"title": "Substack",
		"hex": "FF6719",
		"source": "https://on.substack.com"
	},
	{
		"title": "Subtitle Edit",
		"hex": "CC2424",
		"source": "https://github.com/SubtitleEdit/subtitleedit/issues/61#issuecomment-1442100888"
	},
	{
		"title": "Subversion",
		"hex": "809CC9",
		"source": "https://subversion.apache.org/logo"
	},
	{
		"title": "suckless",
		"hex": "1177AA",
		"source": "https://suckless.org"
	},
	{
		"title": "Sui",
		"hex": "4DA2FF",
		"source": "https://sui.io/media-kit",
		"guidelines": "https://sui.io/media-kit"
	},
	{
		"title": "Sumo Logic",
		"hex": "000099",
		"source": "https://sites.google.com/sumologic.com/sumo-logic-brand/home",
		"guidelines": "https://sites.google.com/sumologic.com/sumo-logic-brand/home"
	},
	{
		"title": "Suno",
		"hex": "000000",
		"source": "https://suno.com"
	},
	{
		"title": "Sunrise",
		"hex": "DA291C",
		"source": "https://www.sunrise.ch"
	},
	{
		"title": "Supabase",
		"hex": "3FCF8E",
		"source": "https://github.com/supabase/supabase/blob/4031a7549f5d46da7bc79c01d56be4177dc7c114/packages/common/assets/images/supabase-logo-wordmark--light.svg"
	},
	{
		"title": "Super User",
		"hex": "38A1CE",
		"source": "https://stackoverflow.design/brand/logo/",
		"guidelines": "https://stackoverflow.com/legal/trademark-guidance"
	},
	{
		"title": "Supercrease",
		"hex": "000000",
		"source": "https://supercrease.com/wp-content/themes/super-crease/assets/svgs/super-crease.svg"
	},
	{
		"title": "Supermicro",
		"hex": "151F6D",
		"source": "https://www.supermicro.com/manuals/supermicro_logo_guidelines.pdf"
	},
	{
		"title": "Surfshark",
		"hex": "1EBFBF",
		"source": "https://surfshark.com/press/assets"
	},
	{
		"title": "SurrealDB",
		"hex": "FF00A0",
		"source": "https://github.com/surrealdb/surrealdb/blob/b5b4601b09b8f1c1334675bbeb4e7408df8dc882/img/logo.svg"
	},
	{
		"title": "SurveyMonkey",
		"hex": "00BF6F",
		"source": "https://www.surveymonkey.com/mp/brandassets/",
		"guidelines": "https://www.surveymonkey.com/mp/brandassets/"
	},
	{
		"title": "SUSE",
		"hex": "0C322C",
		"source": "https://brand.suse.com",
		"guidelines": "https://brand.suse.com"
	},
	{
		"title": "Suzuki",
		"hex": "E30613",
		"source": "https://www.suzuki.ie"
	},
	{
		"title": "Svelte",
		"hex": "FF3E00",
		"source": "https://github.com/sveltejs/branding/blob/c4dfca6743572087a6aef0e109ffe3d95596e86a/svelte-logo.svg",
		"aliases": {
			"dup": [
				{
					"title": "Sapper",
					"hex": "159497",
					"source": "https://sapper.svelte.dev"
				}
			]
		}
	},
	{
		"title": "SVG",
		"hex": "FFB13B",
		"source": "https://www.w3.org/2009/08/svg-logos.html",
		"guidelines": "https://www.w3.org/2009/08/svg-logos.html",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "SVG.js",
		"hex": "FF0066",
		"source": "https://github.com/svgdotjs/svg.logo/blob/0de9ff2cca6c058968f838baaaf507e475ee4583/logo.svg"
	},
	{
		"title": "SVGO",
		"hex": "3E7FC1",
		"source": "https://github.com/svg/svgo/blob/93a5db197ca32990131bf41becf2e002bb0841bf/logo/isotype.svg"
	},
	{
		"title": "SvgTrace",
		"hex": "F453C4",
		"source": "https://svgtrace.com"
	},
	{
		"title": "Swagger",
		"hex": "85EA2D",
		"source": "https://swagger.io"
	},
	{
		"title": "Swarm",
		"hex": "FFA633",
		"source": "https://foursquare.com/about/logos"
	},
	{
		"title": "Sway",
		"hex": "68751C",
		"source": "https://github.com/swaywm/sway/blob/77b9ddabe2a97c5d04c30929b0f8cbde3470fdd7/assets/Sway_Tree.svg",
		"aliases": {
			"aka": [
				"SwayWM"
			]
		}
	},
	{
		"title": "SWC",
		"hex": "F8C457",
		"source": "https://github.com/swc-project/logo/blob/f26cac1b4a490e3bdf128d3b084bb57f4fab1aac/svg/swc_black.svg"
	},
	{
		"title": "Swift",
		"hex": "F05138",
		"source": "https://developer.apple.com/swift/resources/",
		"guidelines": "https://developer.apple.com/swift/resources/"
	},
	{
		"title": "Swiggy",
		"hex": "FC8019",
		"source": "https://www.swiggy.com"
	},
	{
		"title": "Swiper",
		"hex": "6332F6",
		"source": "https://swiperjs.com"
	},
	{
		"title": "SWR",
		"hex": "000000",
		"source": "https://swr.vercel.app"
	},
	{
		"title": "Symantec",
		"hex": "FDB511",
		"source": "https://commons.wikimedia.org/wiki/File:Symantec_logo10.svg"
	},
	{
		"title": "Symbolab",
		"hex": "DB3F59",
		"source": "https://www.symbolab.com"
	},
	{
		"title": "Symfony",
		"hex": "000000",
		"source": "https://symfony.com/logo",
		"guidelines": "https://symfony.com/trademark"
	},
	{
		"title": "Symphony",
		"hex": "0098FF",
		"source": "https://symphony.com"
	},
	{
		"title": "SymPy",
		"hex": "3B5526",
		"source": "https://github.com/sympy/sympy.github.com/blob/e606a6dc2ee90b1ddaa9c36be6c92392ab300f72/media/sympy-notailtext.svg"
	},
	{
		"title": "Syncthing",
		"hex": "0891D1",
		"source": "https://github.com/syncthing/syncthing/blob/bdfd0f0548d2f6fc4b5500690dbd383baa3b0561/assets/logo-only.svg"
	},
	{
		"title": "Synology",
		"hex": "B5B5B6",
		"source": "https://www.synology.com/en-global/company/branding",
		"guidelines": "https://www.synology.com/en-global/company/branding"
	},
	{
		"title": "System76",
		"hex": "585048",
		"source": "https://github.com/system76/brand/blob/7a31740b54f929b62a165baa61dfb0b5164261e8/System76%20branding/system76-logo_secondary.svg"
	},
	{
		"title": "Tabelog",
		"hex": "F2CC38",
		"source": "https://tabelog.com",
		"aliases": {
			"loc": {
				"ja-JP": "食べログ"
			}
		}
	},
	{
		"title": "TableCheck",
		"hex": "7935D2",
		"source": "https://www.tablecheck.com/join"
	},
	{
		"title": "Taco Bell",
		"hex": "38096C",
		"source": "https://www.tacobell.com"
	},
	{
		"title": "tado°",
		"hex": "FFA900",
		"source": "https://www.tado.com/gb-en/press-assets"
	},
	{
		"title": "Taichi Graphics",
		"hex": "000000",
		"source": "https://taichi.graphics"
	},
	{
		"title": "Taichi Lang",
		"hex": "000000",
		"source": "https://docs.taichi-lang.org/blog"
	},
	{
		"title": "Tails",
		"hex": "56347C",
		"source": "https://tails.boum.org/contribute/how/promote/material/logo/"
	},
	{
		"title": "Tailscale",
		"hex": "242424",
		"source": "https://tailscale.com/press"
	},
	{
		"title": "Tailwind CSS",
		"hex": "06B6D4",
		"source": "https://tailwindcss.com/brand",
		"guidelines": "https://tailwindcss.com/brand"
	},
	{
		"title": "Taipy",
		"hex": "FF371A",
		"source": "https://taipy.io"
	},
	{
		"title": "Take-Two Interactive Software",
		"hex": "000000",
		"source": "https://www.take2games.com/ir"
	},
	{
		"title": "Talend",
		"hex": "FF6D70",
		"source": "https://www.talend.com/blog"
	},
	{
		"title": "Talenthouse",
		"hex": "000000",
		"source": "https://www.talenthouse.com"
	},
	{
		"title": "Talos",
		"hex": "FF7300",
		"source": "https://github.com/siderolabs/talos/blob/e3fda049fee62f3c5cef4ae08eaf848826a6dbed/website/assets/icons/logo.svg"
	},
	{
		"title": "Tamiya",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:TAMIYA_Logo.svg"
	},
	{
		"title": "Tampermonkey",
		"hex": "00485B",
		"source": "https://commons.wikimedia.org/wiki/File:Tampermonkey_logo.svg"
	},
	{
		"title": "Taobao",
		"hex": "E94F20",
		"source": "https://www.alibabagroup.com/en/ir/reports"
	},
	{
		"title": "Tapas",
		"hex": "FFCE00",
		"source": "https://tapas.io/site/about#media"
	},
	{
		"title": "Target",
		"hex": "CC0000",
		"source": "https://www.target.com"
	},
	{
		"title": "TAROM",
		"hex": "003366",
		"source": "https://www.tarom.ro"
	},
	{
		"title": "Task",
		"hex": "29BEB0",
		"source": "https://github.com/go-task/task/blob/84ad0056e49e2206bf5903863cdf972a7305072c/docs/static/img/logo_mono.svg"
	},
	{
		"title": "Tasmota",
		"hex": "1FA3EC",
		"source": "https://github.com/tasmota/docs/blob/f9ad71612681d85f3b21406c7defa86b3eaa6bb9/docs/images/symbol.svg"
	},
	{
		"title": "Tata",
		"hex": "486AAE",
		"source": "https://www.tatasteel.com/media/media-kit/logos-usage-guidelines",
		"guidelines": "https://www.tatasteel.com/media/media-kit/logos-usage-guidelines"
	},
	{
		"title": "Tata Consultancy Services",
		"slug": "tcs",
		"hex": "EE3984",
		"source": "https://www.tcs.com",
		"aliases": {
			"aka": [
				"TCS"
			]
		}
	},
	{
		"title": "Tauri",
		"hex": "24C8D8",
		"source": "https://github.com/tauri-apps/tauri-docs/blob/b1cdfa9d7c6d0b17dae60a90266ddced40a7b384/static/img/tauri.svg",
		"guidelines": "https://github.com/tauri-apps/tauri-docs/blob/b1cdfa9d7c6d0b17dae60a90266ddced40a7b384/static/img/Brand_Guidelines.pdf",
		"license": {
			"type": "CC-BY-NC-ND-4.0"
		}
	},
	{
		"title": "TaxBuzz",
		"hex": "ED8B0B",
		"source": "https://www.taxbuzz.com"
	},
	{
		"title": "Teal",
		"hex": "005149",
		"source": "https://www.tealhq.com"
	},
	{
		"title": "TeamCity",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos",
		"guidelines": "https://www.jetbrains.com/company/brand"
	},
	{
		"title": "TeamSpeak",
		"hex": "4B69B6",
		"source": "https://teamspeak.com"
	},
	{
		"title": "TeamViewer",
		"hex": "050A52",
		"source": "https://www.teamviewer.com"
	},
	{
		"title": "TechCrunch",
		"hex": "029F00",
		"source": "https://commons.wikimedia.org/wiki/File:TechCrunch_logo.svg"
	},
	{
		"title": "TED",
		"hex": "E62B1E",
		"source": "https://www.ted.com/participate/organize-a-local-tedx-event/tedx-organizer-guide/branding-promotions/logo-and-design/your-tedx-logo",
		"guidelines": "https://www.ted.com/participate/organize-a-local-tedx-event/tedx-organizer-guide/branding-promotions/logo-and-design/your-tedx-logo"
	},
	{
		"title": "TeePublic",
		"hex": "4E64DF",
		"source": "https://teepublic.design/brand-kit",
		"guidelines": "https://teepublic.design"
	},
	{
		"title": "Teespring",
		"hex": "ED2761",
		"source": "https://teespring.com"
	},
	{
		"title": "Tekton",
		"hex": "FD495C",
		"source": "https://github.com/cdfoundation/artwork/blob/3e748ca9cf9c3136a4a571f7655271b568c16a64/tekton/icon/black/tekton-icon-black.svg",
		"guidelines": "https://github.com/cdfoundation/artwork/blob/main/tekton/tekton_brand_guide.pdf"
	},
	{
		"title": "TELE 5",
		"hex": "FF00FF",
		"source": "https://commons.wikimedia.org/wiki/File:Tele_5_Logo_2021.svg"
	},
	{
		"title": "Télé-Québec",
		"hex": "1343FB",
		"source": "https://www.telequebec.tv/societe/logo-et-normes-techniques"
	},
	{
		"title": "Telefónica",
		"hex": "0066FF",
		"source": "https://commons.wikimedia.org/wiki/File:Telef%C3%B3nica_2021_logo.svg"
	},
	{
		"title": "Telegram",
		"hex": "26A5E4",
		"source": "https://telegram.org/tour/screenshots"
	},
	{
		"title": "Telegraph",
		"hex": "FAFAFA",
		"source": "https://telegra.ph"
	},
	{
		"title": "Temporal",
		"hex": "000000",
		"source": "https://github.com/temporalio/temporaldotio/blob/b6b5f3ed1fda818d5d6c07e27ec15d51a61f2267/public/images/icons/temporal-no-text.svg"
	},
	{
		"title": "TensorFlow",
		"hex": "FF6F00",
		"source": "https://www.tensorflow.org"
	},
	{
		"title": "Teradata",
		"hex": "F37440",
		"source": "https://github.com/Teradata/teradata.github.io/blob/0fb3886aaeefea7bea4951c300f49ac8f9c2476f/src/assets/icons/teradata-icon.svg"
	},
	{
		"title": "teratail",
		"hex": "F4C51C",
		"source": "https://teratail.com"
	},
	{
		"title": "Termius",
		"hex": "000000",
		"source": "https://termius.com/brand-resources",
		"guidelines": "https://termius.com/terms-of-use"
	},
	{
		"title": "Terraform",
		"hex": "844FBA",
		"source": "https://www.hashicorp.com/brand",
		"guidelines": "https://www.hashicorp.com/brand"
	},
	{
		"title": "Tesco",
		"hex": "00539F",
		"source": "https://www.tesco.com"
	},
	{
		"title": "Tesla",
		"hex": "CC0000",
		"source": "https://www.tesla.com/tesla-gallery"
	},
	{
		"title": "TestCafe",
		"hex": "36B6E5",
		"source": "https://github.com/DevExpress/testcafe/blob/dd174b6682b5f2675ac90e305d3d893c36a1d814/media/logos/svg/TestCafe-logo-600.svg"
	},
	{
		"title": "Testin",
		"hex": "007DD7",
		"source": "https://www.testin.cn"
	},
	{
		"title": "Testing Library",
		"hex": "E33332",
		"source": "https://testing-library.com"
	},
	{
		"title": "TestRail",
		"hex": "65C179",
		"source": "https://www.testrail.com",
		"guidelines": "https://www.ideracorp.com/Legal/idera-trademark-usage-guidelines-and-abuse-policy"
	},
	{
		"title": "Tether",
		"hex": "50AF95",
		"source": "https://tether.to/branding/",
		"guidelines": "https://tether.to/branding/",
		"aliases": {
			"aka": [
				"USDt"
			]
		}
	},
	{
		"title": "Textpattern",
		"hex": "FFDA44",
		"source": "https://textpattern.com"
	},
	{
		"title": "TGA",
		"hex": "0014FF",
		"source": "https://thegameawards.com/about",
		"aliases": {
			"aka": [
				"The Game Awards"
			]
		}
	},
	{
		"title": "Thangs",
		"hex": "FFBC00",
		"source": "https://thangs.com"
	},
	{
		"title": "Thanos",
		"hex": "6D41FF",
		"source": "https://thanos.io"
	},
	{
		"title": "The Algorithms",
		"hex": "00BCB4",
		"source": "https://github.com/TheAlgorithms/website/blob/f4e439578c88fed3b21c70898605238602975d2d/public/logo_t.svg"
	},
	{
		"title": "The Boring Company",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:The_Boring_Company_Logo.svg"
	},
	{
		"title": "The Conversation",
		"hex": "D8352A",
		"source": "https://theconversation.com/republishing-guidelines"
	},
	{
		"title": "THE FINALS",
		"hex": "D31F3C",
		"source": "https://www.embark-studios.com/press"
	},
	{
		"title": "The Guardian",
		"hex": "052962",
		"source": "https://www.theguardian.com/international"
	},
	{
		"title": "The Irish Times",
		"hex": "000000",
		"source": "https://www.irishtimes.com"
	},
	{
		"title": "The Mighty",
		"hex": "D0072A",
		"source": "https://themighty.com"
	},
	{
		"title": "The Models Resource",
		"hex": "3A75BD",
		"source": "https://www.models-resource.com"
	},
	{
		"title": "The Movie Database",
		"hex": "01B4E4",
		"source": "https://www.themoviedb.org/about/logos-attribution",
		"aliases": {
			"aka": [
				"TMDB"
			]
		}
	},
	{
		"title": "The North Face",
		"hex": "000000",
		"source": "https://www.thenorthface.com"
	},
	{
		"title": "The Odin Project",
		"hex": "A9792B",
		"source": "https://www.theodinproject.com"
	},
	{
		"title": "The Register",
		"hex": "FF0000",
		"source": "https://www.theregister.co.uk"
	},
	{
		"title": "The Sounds Resource",
		"hex": "39BE6B",
		"source": "https://www.sounds-resource.com"
	},
	{
		"title": "The Spriters Resource",
		"hex": "BE3939",
		"source": "https://www.spriters-resource.com"
	},
	{
		"title": "The Washington Post",
		"hex": "231F20",
		"source": "https://www.washingtonpost.com/brand-studio/archive/"
	},
	{
		"title": "The Weather Channel",
		"hex": "003399",
		"source": "https://weather.com",
		"aliases": {
			"aka": [
				"weather.com"
			]
		}
	},
	{
		"title": "Thingiverse",
		"hex": "248BFB",
		"source": "https://www.thingiverse.com"
	},
	{
		"title": "ThinkPad",
		"hex": "EE2624",
		"source": "https://www.lenovo.com/us/en/thinkpad"
	},
	{
		"title": "thirdweb",
		"hex": "F213A4",
		"source": "https://thirdweb.com"
	},
	{
		"title": "Threadless",
		"hex": "0099FF",
		"source": "https://www.threadless.com/about-us"
	},
	{
		"title": "Threads",
		"hex": "000000",
		"source": "https://about.meta.com/brand/resources/instagram/threads",
		"guidelines": "https://about.meta.com/brand/resources/instagram/threads"
	},
	{
		"title": "Three.js",
		"hex": "000000",
		"source": "https://github.com/mrdoob/three.js/blob/a567b810cfcb7f6a03e4faea99f03c53081da477/files/icon.svg"
	},
	{
		"title": "Threema",
		"hex": "3FE669",
		"source": "https://threema.ch/en/press"
	},
	{
		"title": "Thumbtack",
		"hex": "009FD9",
		"source": "https://www.thumbtack.com/press/media-resources/"
	},
	{
		"title": "Thunderbird",
		"hex": "0A84FF",
		"source": "https://design.thunderbird.net/resources/logo"
	},
	{
		"title": "Thunderstore",
		"hex": "23FFB0",
		"source": "https://github.com/thunderstore-io/brand-guidelines/blob/7b5d4b62ca192a61b8ce5842cd8f5ad1f24ffcfd/assets/logo/thunderstore-logomark-black.svg",
		"guidelines": "https://github.com/thunderstore-io/brand-guidelines"
	},
	{
		"title": "Thurgauer Kantonalbank",
		"hex": "006D41",
		"source": "https://www.tkb.ch"
	},
	{
		"title": "Thymeleaf",
		"hex": "005F0F",
		"source": "https://github.com/thymeleaf/thymeleaf-org/blob/0427d4d4c6f08d3a1fbed3bc90ceeebcf094b532/artwork/thymeleaf%202016/thymeleaf.svg"
	},
	{
		"title": "Ticketmaster",
		"hex": "026CDF",
		"source": "https://design.ticketmaster.com/brand/overview/"
	},
	{
		"title": "TickTick",
		"hex": "4772FA",
		"source": "https://ticktick.com"
	},
	{
		"title": "Tidal",
		"hex": "000000",
		"source": "https://tidal.com/press"
	},
	{
		"title": "TiddlyWiki",
		"hex": "111111",
		"source": "https://tiddlywiki.com"
	},
	{
		"title": "Tide",
		"hex": "4050FB",
		"source": "https://www.tide.co/newsroom"
	},
	{
		"title": "Tidyverse",
		"hex": "1A162D",
		"source": "https://github.com/rstudio/hex-stickers/blob/69528093ef59f541e5a4798dbcb00e60267e8870/SVG/tidyverse.svg"
	},
	{
		"title": "TietoEVRY",
		"hex": "063752",
		"source": "https://www.tietoevry.com/en/about-us/our-company/"
	},
	{
		"title": "TikTok",
		"hex": "000000",
		"source": "https://tiktok.com"
	},
	{
		"title": "Tilda Publishing",
		"hex": "FFA282",
		"source": "https://tilda.cc/mediakit"
	},
	{
		"title": "Tile",
		"hex": "000000",
		"source": "https://www.thetileapp.com"
	},
	{
		"title": "Timescale",
		"hex": "FDB515",
		"source": "https://www.timescale.com"
	},
	{
		"title": "Tina",
		"hex": "EC4815",
		"source": "https://github.com/tinacms/tinacms/blob/965edfb7d2a318ab6b86a4772e4daebf53f34f2e/examples/tina-self-hosted-demo/public/tina.svg"
	},
	{
		"title": "Tinder",
		"hex": "FF6B6B",
		"source": "https://www.gotinder.com/press"
	},
	{
		"title": "Tindie",
		"hex": "17AEB9",
		"source": "https://www.tindie.com/tindieu"
	},
	{
		"title": "Tinkercad",
		"hex": "1477D1",
		"source": "https://www.tinkercad.com"
	},
	{
		"title": "tinygrad",
		"hex": "FFFFFF",
		"source": "https://github.com/tinygrad/tinygrad/blob/1025dfb94def0bf3afe7c9ef6af9581727263ab4/docs/logo_tiny_light.svg"
	},
	{
		"title": "TinyLetter",
		"hex": "ED1C24",
		"source": "https://tinyletter.com/site/press/"
	},
	{
		"title": "Tistory",
		"hex": "000000",
		"source": "https://tistory.com",
		"aliases": {
			"loc": {
				"ko-KR": "티스토리"
			}
		}
	},
	{
		"title": "tldraw",
		"hex": "FAFAFA",
		"source": "https://tldraw.dev",
		"guidelines": "https://github.com/tldraw/tldraw/blob/main/TRADEMARKS.md"
	},
	{
		"title": "tmux",
		"hex": "1BB91F",
		"source": "https://github.com/tmux/tmux/blob/e26356607e38cbb4676a7c91815ae2d5734443c3/logo/tmux-logo-1-color.svg"
	},
	{
		"title": "Todoist",
		"hex": "E44332",
		"source": "https://doist.com/press"
	},
	{
		"title": "Toggl",
		"hex": "FFDE91",
		"source": "https://toggl.com/track/media-toolkit",
		"guidelines": "https://toggl.com/track/media-toolkit"
	},
	{
		"title": "Toggl Track",
		"hex": "E57CD8",
		"source": "https://toggl.com/track/media-toolkit",
		"guidelines": "https://toggl.com/track/media-toolkit"
	},
	{
		"title": "Tokyo Metro",
		"hex": "149DD3",
		"source": "https://commons.wikimedia.org/wiki/File:Tokyo_Metro_combined_logo.svg"
	},
	{
		"title": "Toll",
		"hex": "007A68",
		"source": "https://www.tollgroup.com"
	},
	{
		"title": "TOML",
		"hex": "9C4121",
		"source": "https://github.com/toml-lang/toml/blob/625f62b55c5acdfb9924c78e1d0bf4cf0be23d91/logos/toml.svg"
	},
	{
		"title": "Tomorrowland",
		"hex": "000000",
		"source": "https://tomorrowland.com"
	},
	{
		"title": "TomTom",
		"hex": "DF1B12",
		"source": "https://brandguide.tomtom.com/design/logo",
		"guidelines": "https://brandguide.tomtom.com"
	},
	{
		"title": "TON",
		"hex": "0098EA",
		"source": "https://ton.org/en/brand-assets",
		"guidelines": "https://ton.org/en/brand-assets"
	},
	{
		"title": "Top.gg",
		"hex": "FF3366",
		"source": "https://top.gg"
	},
	{
		"title": "Topcoder",
		"hex": "29A7DF",
		"source": "https://www.topcoder.com/thrive/articles/How%20to%20use%20the%20Topcoder%20GUI%20KIT",
		"guidelines": "https://www.topcoder.com/thrive/articles/How%20to%20use%20the%20Topcoder%20GUI%20KIT"
	},
	{
		"title": "Toptal",
		"hex": "3863A0",
		"source": "https://www.toptal.com/branding"
	},
	{
		"title": "Tor Browser",
		"hex": "7D4698",
		"source": "https://styleguide.torproject.org/brand-assets"
	},
	{
		"title": "Tor Project",
		"hex": "7D4698",
		"source": "https://styleguide.torproject.org/brand-assets"
	},
	{
		"title": "Torizon",
		"hex": "FAAF00",
		"source": "https://toradex.com/torizon"
	},
	{
		"title": "Toshiba",
		"hex": "FF0000",
		"source": "https://commons.wikimedia.org/wiki/File:Toshiba_logo.svg"
	},
	{
		"title": "TOTVS",
		"hex": "363636",
		"source": "https://marca.totvs.com/downloads",
		"guidelines": "https://marca.totvs.com/identidade-visual"
	},
	{
		"title": "TourBox",
		"hex": "231F20",
		"source": "https://www.tourboxtech.com"
	},
	{
		"title": "Tower",
		"hex": "00CAF4",
		"source": "https://www.git-tower.com/company/press",
		"guidelines": "https://www.git-tower.com/company/press"
	},
	{
		"title": "Toyota",
		"hex": "EB0A1E",
		"source": "https://www.toyota.com/brandguidelines/logo/",
		"guidelines": "https://www.toyota.com/brandguidelines/"
	},
	{
		"title": "TP-Link",
		"hex": "4ACBD6",
		"source": "https://www.tp-link.com"
	},
	{
		"title": "tqdm",
		"hex": "FFC107",
		"source": "https://github.com/tqdm/img/blob/0dd23d9336af67976f88f9988ea660cde78c54d4/logo.svg"
	},
	{
		"title": "Traccar",
		"hex": "000000",
		"source": "https://www.traccar.org"
	},
	{
		"title": "TradingView",
		"hex": "131622",
		"source": "https://www.tradingview.com/media-kit"
	},
	{
		"title": "Traefik Mesh",
		"hex": "9D0FB0",
		"source": "https://github.com/traefik/mesh/blob/ef03c40b78c08931d47fdad0be10d1986f4e21bc/docs/content/assets/img/traefik-mesh-logo.svg"
	},
	{
		"title": "Traefik Proxy",
		"hex": "24A1C1",
		"source": "https://traefik.io/traefik"
	},
	{
		"title": "Trailforks",
		"hex": "FFCD00",
		"source": "https://www.trailforks.com/about/graphics",
		"guidelines": "https://www.trailforks.com/about/graphics"
	},
	{
		"title": "TrainerRoad",
		"hex": "DA291C",
		"source": "https://www.trainerroad.com/press",
		"guidelines": "https://www.trainerroad.com/press"
	},
	{
		"title": "Trakt",
		"hex": "9F42C6",
		"source": "https://trakt.tv/branding",
		"guidelines": "https://trakt.tv/branding"
	},
	{
		"title": "Transifex",
		"hex": "0064AB",
		"source": "https://app.transifex.com/contact/"
	},
	{
		"title": "Transmission",
		"hex": "D70008",
		"source": "https://github.com/transmission/transmission/blob/7c9e04d035f3f75a8124e83d612701824487eb4e/gtk/icons/hicolor_apps_symbolic_transmission-symbolic.svg"
	},
	{
		"title": "Transport for Ireland",
		"hex": "00B274",
		"source": "https://www.transportforireland.ie"
	},
	{
		"title": "Transport for London",
		"hex": "113B92",
		"source": "https://tfl.gov.uk"
	},
	{
		"title": "Travis CI",
		"hex": "3EAAAF",
		"source": "https://travis-ci.com/logo"
	},
	{
		"title": "Treehouse",
		"hex": "5FCF80",
		"source": "https://teamtreehouse.com"
	},
	{
		"title": "Trello",
		"hex": "0052CC",
		"source": "https://atlassian.design/resources/logo-library",
		"guidelines": "https://atlassian.design/foundations/logos"
	},
	{
		"title": "Trend Micro",
		"hex": "D71921",
		"source": "https://www.trendmicro.com"
	},
	{
		"title": "Treyarch",
		"hex": "000000",
		"source": "https://en.wikipedia.org/wiki/File:Treyarch_logo.svg"
	},
	{
		"title": "Tricentis",
		"hex": "12438C",
		"source": "https://www.tricentis.com"
	},
	{
		"title": "Trilium",
		"hex": "000000",
		"source": "https://github.com/zadam/trilium/blob/05d2f4fe96f49c5bc7f3a02a9e47fc352ce5971d/images/icon.svg"
	},
	{
		"title": "Triller",
		"hex": "FF0089",
		"source": "https://triller.co"
	},
	{
		"title": "TrillerTV",
		"hex": "E61414",
		"source": "https://fite.tv",
		"aliases": {
			"old": [
				"FITE"
			]
		}
	},
	{
		"title": "Trimble",
		"hex": "0063A3",
		"source": "https://www.trimble.com",
		"guidelines": "https://brand.trimble.com"
	},
	{
		"title": "Trino",
		"hex": "DD00A1",
		"source": "https://github.com/trinodb/docs.trino.io/blob/653a46f6bdc64b5f67302dc9ab8a0c432ca25e70/352/_static/trino.svg"
	},
	{
		"title": "Trip.com",
		"hex": "287DFA",
		"source": "https://careers.trip.com"
	},
	{
		"title": "Tripadvisor",
		"hex": "34E0A1",
		"source": "https://tripadvisor.mediaroom.com/logo-guidelines",
		"guidelines": "https://tripadvisor.mediaroom.com/logo-guidelines"
	},
	{
		"title": "trivago",
		"hex": "E32851",
		"source": "https://company.trivago.com/press-media",
		"guidelines": "https://company.trivago.com/press-media"
	},
	{
		"title": "Trivy",
		"hex": "1904DA",
		"source": "https://www.aquasec.com/brand",
		"guidelines": "https://www.aquasec.com/brand"
	},
	{
		"title": "Trove",
		"hex": "2D004B",
		"source": "https://trove.nla.gov.au/about/who-we-are/our-logo",
		"guidelines": "https://trove.nla.gov.au/about/who-we-are/trove-brand-guidelines"
	},
	{
		"title": "tRPC",
		"hex": "2596BE",
		"source": "https://github.com/trpc/trpc/blob/e0df4a2d5b498dd953a65901e04915c6e3f7ecc5/www/static/img/logo-no-text.svg"
	},
	{
		"title": "TrueNAS",
		"hex": "0095D5",
		"source": "https://www.truenas.com"
	},
	{
		"title": "TrueUp",
		"hex": "4E71DA",
		"source": "https://www.trueup.io"
	},
	{
		"title": "trulia",
		"hex": "0A0B09",
		"source": "https://www.trulia.com/newsroom/media/brand-logos",
		"guidelines": "https://www.trulia.com/newsroom/media/brand-logos"
	},
	{
		"title": "Trusted Shops",
		"hex": "FFDC0F",
		"source": "https://brand.trustedshops.com/d/dorIFVeUmcN9/corporate-design"
	},
	{
		"title": "Trustpilot",
		"hex": "00B67A",
		"source": "https://support.trustpilot.com/hc/en-us/articles/206289947-Trustpilot-Brand-Assets-Style-Guide",
		"guidelines": "https://support.trustpilot.com/hc/en-us/articles/206289947-Trustpilot-Brand-Assets-Style-Guide"
	},
	{
		"title": "Try It Online",
		"hex": "303030",
		"source": "https://tio.run"
	},
	{
		"title": "TryHackMe",
		"hex": "212C42",
		"source": "https://tryhackme.com"
	},
	{
		"title": "ts-node",
		"hex": "3178C6",
		"source": "https://typestrong.org/ts-node"
	},
	{
		"title": "Tubi",
		"hex": "7408FF",
		"source": "https://gdpr.tubi.tv"
	},
	{
		"title": "TUI",
		"hex": "D40E14",
		"source": "https://www.design.tui/brand/logos",
		"guidelines": "https://www.design.tui/brand"
	},
	{
		"title": "Tumblr",
		"hex": "36465D",
		"source": "https://www.tumblr.com/logo",
		"guidelines": "https://www.tumblr.com/logo"
	},
	{
		"title": "TuneIn",
		"hex": "14D8CC",
		"source": "https://cms.tunein.com/press/"
	},
	{
		"title": "Turbo",
		"hex": "5CD8E5",
		"source": "https://turbo.hotwired.dev"
	},
	{
		"title": "Turborepo",
		"hex": "EF4444",
		"source": "https://github.com/vercel/turborepo/blob/7312e316629a2138f895a90c9704045891be817b/docs/public/logo-light.svg"
	},
	{
		"title": "TurboSquid",
		"hex": "FF8135",
		"source": "https://www.brand.turbosquid.com/turbosquidicons",
		"guidelines": "https://www.brand.turbosquid.com"
	},
	{
		"title": "Turkish Airlines",
		"hex": "C70A0C",
		"source": "https://www.turkishairlines.com/en-int/press-room/logo-archive/index.html"
	},
	{
		"title": "Turso",
		"hex": "4FF8D2",
		"source": "https://turso.tech"
	},
	{
		"title": "Tuta",
		"hex": "850122",
		"source": "https://github.com/tutao/tutanota/blob/65d087b1bc2cb7aee46e7a46431303483d2da986/resources/favicon/logo-favicon.svg",
		"guidelines": "https://tuta.com/press",
		"aliases": {
			"aka": [
				"Tutanota"
			]
		}
	},
	{
		"title": "TV Time",
		"hex": "FFD400",
		"source": "https://www.tvtime.com"
	},
	{
		"title": "TV4 Play",
		"hex": "E0001C",
		"source": "https://tv4play.se"
	},
	{
		"title": "Twilio",
		"hex": "F22F46",
		"source": "https://www.twilio.com/company/brand"
	},
	{
		"title": "Twinkly",
		"hex": "FCC15E",
		"source": "https://help.twinkly.com/en/help/quick-guides"
	},
	{
		"title": "Twinmotion",
		"hex": "000000",
		"source": "https://www.twinmotion.com"
	},
	{
		"title": "Twitch",
		"hex": "9146FF",
		"source": "https://brand.twitch.tv",
		"guidelines": "https://brand.twitch.tv"
	},
	{
		"title": "Typeform",
		"hex": "262627",
		"source": "https://www.typeform.com"
	},
	{
		"title": "TypeORM",
		"hex": "FE0803",
		"source": "https://github.com/typeorm/typeorm/blob/e7649d2746f907ff36b1efb600402dedd5f5a499/resources/logo_big.png",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Typer",
		"hex": "000000",
		"source": "https://typer.tiangolo.com"
	},
	{
		"title": "TypeScript",
		"hex": "3178C6",
		"source": "https://www.typescriptlang.org/branding",
		"guidelines": "https://www.typescriptlang.org/branding"
	},
	{
		"title": "TYPO3",
		"hex": "FF8700",
		"source": "https://styleguide.typo3.com/styleguide/logo",
		"guidelines": "https://styleguide.typo3.com"
	},
	{
		"title": "Typst",
		"hex": "239DAD",
		"source": "https://typst.app",
		"guidelines": "https://typst.app/legal/brand"
	},
	{
		"title": "U.S. News",
		"hex": "005EA6",
		"source": "https://www.usnews.com"
	},
	{
		"title": "Uber",
		"hex": "000000",
		"source": "https://assets.uber.com/d/k4nuxdZ8MC7E/logos/collection/151",
		"guidelines": "https://assets.uber.com/d/k4nuxdZ8MC7E/user-guide#/user-guide/terms-of-use"
	},
	{
		"title": "Uber Eats",
		"hex": "06C167",
		"source": "https://assets.uber.com/d/k4nuxdZ8MC7E/logos/collection/150",
		"guidelines": "https://assets.uber.com/d/k4nuxdZ8MC7E/user-guide#/user-guide/terms-of-use"
	},
	{
		"title": "Ubiquiti",
		"hex": "0559C9",
		"source": "https://www.ui.com"
	},
	{
		"title": "Ubisoft",
		"hex": "000000",
		"source": "https://www.ubisoft.com/en-US/company/overview.aspx"
	},
	{
		"title": "uBlock Origin",
		"hex": "800000",
		"source": "https://github.com/gorhill/uBlock/blob/59aa235952a9289cfe72e4fb9f8a7d8f4c80be9a/src/img/ublock.svg"
	},
	{
		"title": "Ubuntu",
		"hex": "E95420",
		"source": "https://design.ubuntu.com/resources",
		"guidelines": "https://design.ubuntu.com/brand"
	},
	{
		"title": "Ubuntu MATE",
		"hex": "84A454",
		"source": "https://ubuntu-mate.org"
	},
	{
		"title": "Udacity",
		"hex": "02B3E4",
		"source": "https://www.udacity.com"
	},
	{
		"title": "Udemy",
		"hex": "A435F0",
		"source": "https://udemy.com",
		"guidelines": "https://support.udemy.com/hc/en-us/articles/8926753692567-Trademark-Usage-Guidelines"
	},
	{
		"title": "UFC",
		"hex": "D20A0A",
		"source": "https://www.ufc.com"
	},
	{
		"title": "UIkit",
		"hex": "2396F3",
		"source": "https://getuikit.com"
	},
	{
		"title": "UiPath",
		"hex": "FA4616",
		"source": "https://www.uipath.com/newsroom",
		"guidelines": "https://brandguidelines.uipath.com"
	},
	{
		"title": "UKCA",
		"hex": "000000",
		"source": "https://www.gov.uk/guidance/using-the-ukca-marking",
		"guidelines": "https://www.gov.uk/guidance/using-the-ukca-marking"
	},
	{
		"title": "Ultralytics",
		"hex": "111F68",
		"source": "https://www.ultralytics.com",
		"guidelines": "https://www.ultralytics.com/brand"
	},
	{
		"title": "Ulule",
		"hex": "18A5D6",
		"source": "https://ulule.frontify.com/d/EX3dK8qsXgqh/branding-guidelines"
	},
	{
		"title": "Umami",
		"hex": "000000",
		"source": "https://github.com/umami-software/umami/blob/3572df0a09503f357a06fe7f816295ba2c878325/assets/logo.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Umbraco",
		"hex": "3544B1",
		"source": "https://umbraco.com"
	},
	{
		"title": "Umbrel",
		"hex": "5351FB",
		"source": "https://umbrel.com"
	},
	{
		"title": "UML",
		"hex": "FABD14",
		"source": "https://www.uml.org",
		"aliases": {
			"aka": [
				"Unified Modelling Language"
			]
		}
	},
	{
		"title": "Unacademy",
		"hex": "08BD80",
		"source": "https://unacademy.com"
	},
	{
		"title": "Under Armour",
		"hex": "1D1D1D",
		"source": "https://www.underarmour.com/en-us"
	},
	{
		"title": "Underscore.js",
		"hex": "0371B5",
		"source": "https://github.com/jashkenas/underscore/blob/f098f61ff84931dea69c276b3674a62b6ae4def7/docs/images/underscore.png"
	},
	{
		"title": "Undertale",
		"hex": "E71D29",
		"source": "https://undertale.com"
	},
	{
		"title": "Unicode",
		"hex": "5455FE",
		"source": "https://commons.wikimedia.org/wiki/File:New_Unicode_logo.svg"
	},
	{
		"title": "Unilever",
		"hex": "1F36C7",
		"source": "https://www.unilever.com/our-company/the-logo"
	},
	{
		"title": "Uniqlo",
		"hex": "FF0000",
		"source": "https://www.uniqlo.com"
	},
	{
		"title": "Uniqlo",
		"slug": "uniqlo_ja",
		"hex": "FF0000",
		"source": "https://www.uniqlo.com",
		"aliases": {
			"loc": {
				"ja-JP": "ユニクロ"
			}
		}
	},
	{
		"title": "United Airlines",
		"hex": "002244",
		"source": "https://www.united.com"
	},
	{
		"title": "United Nations",
		"hex": "009EDB",
		"source": "https://www.un.org/en",
		"guidelines": "https://www.un.org/styleguide/pdf/UN_brand_identity_quick_guide_2020.pdf"
	},
	{
		"title": "Unity",
		"hex": "FFFFFF",
		"source": "https://brand.unity.com",
		"guidelines": "https://brand.unity.com"
	},
	{
		"title": "UnJS",
		"hex": "ECDC5A",
		"source": "https://unjs.io",
		"guidelines": "https://unjs.io/design-kit",
		"aliases": {
			"aka": [
				"Unified JavaScript"
			]
		}
	},
	{
		"title": "Unlicense",
		"hex": "808080",
		"source": "https://commons.wikimedia.org/wiki/File:PD-icon.svg"
	},
	{
		"title": "UnoCSS",
		"hex": "333333",
		"source": "https://github.com/unocss/unocss/blob/fc2ed5bb6019b45565ff5293d4b650522f1b79b4/playground/public/icon.svg"
	},
	{
		"title": "unpkg",
		"hex": "000000",
		"source": "https://github.com/mjackson/unpkg/blob/af8c8db00fdacd77961ab2a8c3edb45a27d3a6a3/public/favicon.ico"
	},
	{
		"title": "Unraid",
		"hex": "F15A2C",
		"source": "https://unraid.net"
	},
	{
		"title": "Unreal Engine",
		"hex": "0E1128",
		"source": "https://www.unrealengine.com/en-US/branding",
		"guidelines": "https://www.unrealengine.com/en-US/branding"
	},
	{
		"title": "Unsplash",
		"hex": "000000",
		"source": "https://unsplash.com"
	},
	{
		"title": "Untappd",
		"hex": "FFC000",
		"source": "https://untappd.com"
	},
	{
		"title": "UpCloud",
		"hex": "7B00FF",
		"source": "https://upcloud.com/brand-assets/",
		"guidelines": "https://upcloud.com/brand-assets/"
	},
	{
		"title": "Uphold",
		"hex": "49CC68",
		"source": "https://uphold.com/en-us/brand-assets",
		"guidelines": "https://uphold.com/en-us/brand-assets"
	},
	{
		"title": "UpLabs",
		"hex": "3930D8",
		"source": "https://www.uplabs.com"
	},
	{
		"title": "Upptime",
		"hex": "1ABC9C",
		"source": "https://upptime.js.org"
	},
	{
		"title": "UPS",
		"hex": "150400",
		"source": "https://www.ups.com"
	},
	{
		"title": "Upstash",
		"hex": "00E9A3",
		"source": "https://upstash.com"
	},
	{
		"title": "Uptime Kuma",
		"hex": "5CDD8B",
		"source": "https://uptime.kuma.pet"
	},
	{
		"title": "Upwork",
		"hex": "6FDA44",
		"source": "https://www.upwork.com/press/"
	},
	{
		"title": "USPS",
		"hex": "333366",
		"source": "https://www.usps.com"
	},
	{
		"title": "uTorrent",
		"hex": "76B83F",
		"source": "https://www.utorrent.com"
	},
	{
		"title": "uv",
		"hex": "DE5FE9",
		"source": "https://docs.astral.sh/uv/"
	},
	{
		"title": "V",
		"hex": "5D87BF",
		"source": "https://github.com/vlang/v-logo/blob/eec050c901ed3afefce8cbe56092d55ed6770706/dist/v-logo.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "v0",
		"hex": "000000",
		"source": "https://v0.dev"
	},
	{
		"title": "V2EX",
		"hex": "1F1F1F",
		"source": "https://www.v2ex.com"
	},
	{
		"title": "V8",
		"hex": "4B8BF5",
		"source": "https://v8.dev/logo"
	},
	{
		"title": "Vaadin",
		"hex": "00B4F0",
		"source": "https://vaadin.com/trademark",
		"guidelines": "https://vaadin.com/trademark"
	},
	{
		"title": "Vagrant",
		"hex": "1868F2",
		"source": "https://www.hashicorp.com/brand",
		"guidelines": "https://www.hashicorp.com/brand"
	},
	{
		"title": "Vala",
		"hex": "7239B3",
		"source": "https://commons.wikimedia.org/wiki/File:Vala_Logo.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Valorant",
		"hex": "FA4454",
		"source": "https://commons.wikimedia.org/wiki/File:Valorant_logo_-_black_color_version.svg"
	},
	{
		"title": "Valve",
		"hex": "F74843",
		"source": "https://www.valvesoftware.com"
	},
	{
		"title": "Vapor",
		"hex": "0D0D0D",
		"source": "https://vapor.codes"
	},
	{
		"title": "Vault",
		"hex": "FFEC6E",
		"source": "https://www.hashicorp.com/brand",
		"guidelines": "https://www.hashicorp.com/brand"
	},
	{
		"title": "Vaultwarden",
		"hex": "000000",
		"source": "https://github.com/dani-garcia/vaultwarden/blob/44e9e1a58ed37bf4b352bb499fd3e97adcd3b26b/resources/vaultwarden-icon.svg"
	},
	{
		"title": "Vauxhall",
		"hex": "EB001E",
		"source": "https://www.stellantis.com/en/brands/vauxhall"
	},
	{
		"title": "vBulletin",
		"hex": "184D66",
		"source": "https://commons.wikimedia.org/wiki/File:VBulletin.svg"
	},
	{
		"title": "Vectary",
		"hex": "6100FF",
		"source": "https://www.vectary.com"
	},
	{
		"title": "Vector Logo Zone",
		"hex": "184D66",
		"source": "https://www.vectorlogo.zone"
	},
	{
		"title": "Vectorworks",
		"hex": "000000",
		"source": "https://www.vectorworks.net/en-US"
	},
	{
		"title": "Veeam",
		"hex": "00B336",
		"source": "https://www.veeam.com/newsroom/veeam-graphics.html"
	},
	{
		"title": "VEED",
		"hex": "B6FF60",
		"source": "https://www.veed.io"
	},
	{
		"title": "Veepee",
		"hex": "EC008C",
		"source": "https://www.veepee.fr"
	},
	{
		"title": "Vega",
		"hex": "2450B2",
		"source": "https://github.com/vega/logos/blob/af32bc29f0c09c8de826aaafb037935fb69e960a/assets/VG_Black.svg",
		"guidelines": "https://github.com/vega/logos",
		"license": {
			"type": "BSD-3-Clause"
		}
	},
	{
		"title": "VEGAS",
		"hex": "1A1A1A",
		"source": "https://www.vegascreativesoftware.com"
	},
	{
		"title": "Velocity",
		"hex": "1BBAE0",
		"source": "https://github.com/PaperMC/website/blob/cc46d6922f4eeef595685808672694521a58bdc6/assets/brand/velocity.svg"
	},
	{
		"title": "Velog",
		"hex": "20C997",
		"source": "https://github.com/velopert/velog-client/blob/8fbbb371f4b4525b6747e54d0c608900ea8bf03e/src/static/svg/velog-icon.svg"
	},
	{
		"title": "Vencord",
		"hex": "D3859B",
		"source": "https://github.com/Vencord/Vesktop/blob/ccff1ac3efde2b4fc826d2f411d79e42d80dcb70/build/icon.png"
	},
	{
		"title": "Venmo",
		"hex": "008CFF",
		"source": "https://venmo.com/about/brand",
		"guidelines": "https://venmo.com/about/brand"
	},
	{
		"title": "Vercel",
		"hex": "000000",
		"source": "https://vercel.com/geist/brands",
		"guidelines": "https://vercel.com/geist/brands"
	},
	{
		"title": "Verdaccio",
		"hex": "4B5E40",
		"source": "https://verdaccio.org/docs/logo",
		"guidelines": "https://verdaccio.org/docs/logo"
	},
	{
		"title": "Veritas",
		"hex": "B1181E",
		"source": "https://my.veritas.com/cs/groups/partner/documents/styleguide/mdaw/mdq5/~edisp/tus3cpeapp3855186572.pdf"
	},
	{
		"title": "Verizon",
		"hex": "CD040B",
		"source": "https://www.verizondigitalmedia.com/about/logo-usage/"
	},
	{
		"title": "Vespa",
		"hex": "85B09A",
		"source": "https://www.piaggiogroup.com/en/archive/document/logo-guide",
		"guidelines": "https://www.piaggiogroup.com/en/archive/document/logo-guide"
	},
	{
		"title": "Vestel",
		"hex": "DD052B",
		"source": "https://commons.wikimedia.org/wiki/File:Vestel_logo.svg"
	},
	{
		"title": "VEXXHOST",
		"hex": "2A1659",
		"source": "https://vexxhost.com"
	},
	{
		"title": "vFairs",
		"hex": "EF4678",
		"source": "https://www.vfairs.com"
	},
	{
		"title": "Viadeo",
		"hex": "F07355",
		"source": "https://viadeo.journaldunet.com"
	},
	{
		"title": "Viaplay",
		"hex": "FE365F",
		"source": "https://commons.wikimedia.org/wiki/File:Viaplay_Group.svg"
	},
	{
		"title": "Viber",
		"hex": "7360F2",
		"source": "https://www.viber.com/brand-center",
		"guidelines": "https://www.viber.com/brand-center"
	},
	{
		"title": "Viblo",
		"hex": "5387C6",
		"source": "https://viblo.asia"
	},
	{
		"title": "VictoriaMetrics",
		"hex": "621773",
		"source": "https://github.com/VictoriaMetrics/VictoriaMetrics/blob/24d61bf19374b42ef9839c13c7d35ce8888170e0/docs/assets/images/vm_logo.svg",
		"guidelines": "https://docs.victoriametrics.com/#victoriametrics-logo",
		"aliases": {
			"aka": [
				"VM"
			],
			"loc": {
				"ko-KR": "빅토리아메트릭스"
			}
		}
	},
	{
		"title": "Victron Energy",
		"hex": "0066B2",
		"source": "https://www.victronenergy.com/information/press",
		"guidelines": "https://www.victronenergy.com/information/press"
	},
	{
		"title": "Vim",
		"hex": "019733",
		"source": "https://commons.wikimedia.org/wiki/File:Vimlogo.svg"
	},
	{
		"title": "Vimeo",
		"hex": "1AB7EA",
		"source": "https://press.vimeo.com/brand-guidelines",
		"guidelines": "https://press.vimeo.com/brand-guidelines"
	},
	{
		"title": "Vimeo Livestream",
		"hex": "0A0A20",
		"source": "https://livestream.com"
	},
	{
		"title": "Vinted",
		"hex": "007782",
		"source": "https://www.vinted.com"
	},
	{
		"title": "Virgin",
		"hex": "E10A0A",
		"source": "https://www.virgin.com/img/virgin-logo-square.svg",
		"aliases": {
			"aka": [
				"Virgin Group"
			]
		}
	},
	{
		"title": "Virgin Atlantic",
		"hex": "DA0530",
		"source": "https://www.virginatlantic.com"
	},
	{
		"title": "Virgin Media",
		"hex": "ED1A37",
		"source": "https://commons.wikimedia.org/wiki/File:Virgin_Media.svg"
	},
	{
		"title": "VirtualBox",
		"hex": "2F61B4",
		"source": "https://www.virtualbox.org/svn/vbox/trunk/src/VBox/Artwork/OSE",
		"aliases": {
			"aka": [
				"Oracle VirtualBox"
			]
		}
	},
	{
		"title": "VirusTotal",
		"hex": "394EFF",
		"source": "https://www.virustotal.com"
	},
	{
		"title": "Visa",
		"hex": "1A1F71",
		"source": "https://merchantsignageeu.visa.com/product.asp?dptID=696"
	},
	{
		"title": "visx",
		"hex": "FF1231",
		"source": "https://airbnb.io/visx"
	},
	{
		"title": "Vite",
		"hex": "646CFF",
		"source": "https://vitejs.dev"
	},
	{
		"title": "VitePress",
		"hex": "5C73E7",
		"source": "https://github.com/vuejs/vitepress/blob/f7aef3ca23dae39e226c85d7bb2579dbf7c758f3/art/vitepress-logo-mini.svg"
	},
	{
		"title": "Vitess",
		"hex": "F16728",
		"source": "https://cncf-branding.netlify.app/projects/vitess/"
	},
	{
		"title": "Vitest",
		"hex": "6E9F18",
		"source": "https://vitest.dev"
	},
	{
		"title": "Viva Wallet",
		"hex": "1F263A",
		"source": "https://www.vivawallet.com/gb_en/press-center-gb"
	},
	{
		"title": "Vivaldi",
		"hex": "EF3939",
		"source": "https://vivaldi.com/press",
		"guidelines": "https://vivaldi.com/press",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "Vivino",
		"hex": "A61A30",
		"source": "https://www.vivino.com/press",
		"guidelines": "https://www.vivino.com/press"
	},
	{
		"title": "Vivint",
		"hex": "212721",
		"source": "https://brandfolder.com/portals/vivint",
		"guidelines": "https://s.tiled.co/2wH-ED5/branding-guide"
	},
	{
		"title": "vivo",
		"hex": "415FFF",
		"source": "https://www.vivo.com"
	},
	{
		"title": "VK",
		"hex": "0077FF",
		"source": "https://vk.com/brand",
		"guidelines": "https://vk.com/brand"
	},
	{
		"title": "VLC media player",
		"hex": "FF8800",
		"source": "https://code.videolan.org/videolan/vlc/-/blob/1ce7f686ee17a028d2d79627ae69f22d905f2e23/extras/package/macosx/asset_sources/vlc_app_icon.svg"
	},
	{
		"title": "VMware",
		"hex": "607078",
		"source": "https://myvmware.workspaceair.com"
	},
	{
		"title": "Vodafone",
		"hex": "E60000",
		"source": "https://web.vodafone.com.eg"
	},
	{
		"title": "Void Linux",
		"hex": "478061",
		"source": "https://alpha.de.repo.voidlinux.org/logos/void-dark2.svg"
	},
	{
		"title": "VoIP.ms",
		"hex": "E1382D",
		"source": "https://voip.ms"
	},
	{
		"title": "Volkswagen",
		"hex": "151F5D",
		"source": "https://www.vw.com"
	},
	{
		"title": "Volvo",
		"hex": "003057",
		"source": "https://www.media.volvocars.com/global/en-gb/logos"
	},
	{
		"title": "Vonage",
		"hex": "000000",
		"source": "https://www.vonage.com"
	},
	{
		"title": "Voron Design",
		"hex": "ED3023",
		"source": "https://github.com/VoronDesign/Voron-Extras/blob/d8591f964b408b3da21b6f9b4ab0437e229065de/Images/Logo/SVG/Voron_Design_Hex.svg"
	},
	{
		"title": "Vowpal Wabbit",
		"hex": "FF81F9",
		"source": "https://github.com/VowpalWabbit/vowpal_wabbit/blob/1da1aa4bb4f2dfb5e1a6083c14b429b30eba372d/logo_assets/vowpal-wabbits-icon.svg"
	},
	{
		"title": "VOX",
		"hex": "DA074A",
		"source": "https://commons.wikimedia.org/wiki/File:VOX_Logo_2013.svg"
	},
	{
		"title": "VRChat",
		"hex": "000000",
		"source": "https://hello.vrchat.com/press",
		"guidelines": "https://hello.vrchat.com/press"
	},
	{
		"title": "VSCO",
		"hex": "000000",
		"source": "https://vsco.co"
	},
	{
		"title": "VSCodium",
		"hex": "2F80ED",
		"source": "https://github.com/VSCodium/vscodium.github.io/blob/ed028c57f10e6432ec55dfc34d4db1a83fba941d/img/codium_cnl.svg"
	},
	{
		"title": "VTEX",
		"hex": "ED125F",
		"source": "https://vtex.com"
	},
	{
		"title": "Vue.js",
		"hex": "4FC08D",
		"source": "https://github.com/vuejs/art/blob/a1c78b74569b70a25300925b4eacfefcc143b8f6/logo.svg",
		"guidelines": "https://github.com/vuejs/art/blob/a1c78b74569b70a25300925b4eacfefcc143b8f6/README.md",
		"license": {
			"type": "CC-BY-NC-SA-4.0"
		}
	},
	{
		"title": "Vuetify",
		"hex": "1867C0",
		"source": "https://vuetifyjs.com/resources/brand-kit",
		"guidelines": "https://vuetifyjs.com/resources/brand-kit",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Vulkan",
		"hex": "A41E22",
		"source": "https://www.khronos.org/legal/trademarks",
		"guidelines": "https://www.khronos.org/files/legal/Khronos-Logo-Usage-Guide.pdf"
	},
	{
		"title": "Vultr",
		"hex": "007BFC",
		"source": "https://www.vultr.com/company/brand-assets",
		"guidelines": "https://www.vultr.com/company/brand-assets"
	},
	{
		"title": "Vyond",
		"hex": "D95E26",
		"source": "https://www.vyond.com"
	},
	{
		"title": "W3Schools",
		"hex": "04AA6D",
		"source": "https://profile.w3schools.com"
	},
	{
		"title": "Wacom",
		"hex": "000000",
		"source": "https://support.wacom.com/hc/en-us"
	},
	{
		"title": "Wagmi",
		"hex": "000000",
		"source": "https://wagmi.sh"
	},
	{
		"title": "Wagtail",
		"hex": "43B1B0",
		"source": "https://github.com/wagtail/wagtail/blob/e3e46e23b780aa2b1b521de081cb81872f77466d/wagtail/admin/static_src/wagtailadmin/images/wagtail-logo.svg"
	},
	{
		"title": "Wails",
		"hex": "DF0000",
		"source": "https://wails.io"
	},
	{
		"title": "WakaTime",
		"hex": "000000",
		"source": "https://wakatime.com/legal/logos-and-trademark-usage",
		"guidelines": "https://wakatime.com/legal/logos-and-trademark-usage"
	},
	{
		"title": "WALKMAN",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:Walkman_logo_(2000).svg"
	},
	{
		"title": "Wallabag",
		"hex": "3F6184",
		"source": "https://github.com/wallabag/logo/blob/f670395da2d85c3bbcb8dcfa8d2a339d8af5abb0/_default/icon/svg/logo-icon-black-no-bg.svg"
	},
	{
		"title": "WalletConnect",
		"hex": "3B99FC",
		"source": "https://walletconnect.com/brand",
		"guidelines": "https://walletconnect.com/brand"
	},
	{
		"title": "Walmart",
		"hex": "0071CE",
		"source": "https://corporate.walmart.com",
		"guidelines": "https://one.walmart.com/content/people-experience/associate-brand-center.html"
	},
	{
		"title": "Wantedly",
		"hex": "21BDDB",
		"source": "https://wantedlyinc.com/ja/brand_assets",
		"guidelines": "https://wantedlyinc.com/ja/brand_assets"
	},
	{
		"title": "Wappalyzer",
		"hex": "4608AD",
		"source": "https://www.wappalyzer.com/logos",
		"guidelines": "https://www.wappalyzer.com/logos"
	},
	{
		"title": "Warner Bros.",
		"slug": "warnerbros",
		"hex": "004DB4",
		"source": "https://www.warnerbros.com"
	},
	{
		"title": "Warp",
		"hex": "01A4FF",
		"source": "https://warp.dev"
	},
	{
		"title": "Wasabi",
		"hex": "01CD3E",
		"source": "https://wasabi.com"
	},
	{
		"title": "wasmCloud",
		"hex": "00BC8E",
		"source": "https://github.com/wasmCloud/branding/blob/0827503c63f55471a0c709e97d609f56d716be40/03.Icon/Vector/SVG/Wasmcloud.Icon_Black.svg",
		"guidelines": "https://github.com/wasmCloud/branding/blob/0827503c63f55471a0c709e97d609f56d716be40/wasmcloud_Visual.Guidelines_1.0.pdf"
	},
	{
		"title": "Wasmer",
		"hex": "4946DD",
		"source": "https://github.com/wasmerio/wasmer.io/blob/0d425f5b4ace56496e75278e304f54492c46adde/public/images/icon.svg"
	},
	{
		"title": "Watchtower",
		"hex": "416271",
		"source": "https://containrrr.dev/watchtower"
	},
	{
		"title": "Wattpad",
		"hex": "FF500A",
		"source": "https://company.wattpad.com/brandguideline",
		"guidelines": "https://company.wattpad.com/brandguideline"
	},
	{
		"title": "Wayland",
		"hex": "FFBC00",
		"source": "https://gitlab.freedesktop.org/wayland/weston/-/blob/77ede00a938b8137bd638ce67b6f58cb52b1d1b0/data/wayland.svg",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Waze",
		"hex": "33CCFF",
		"source": "https://www.waze.com"
	},
	{
		"title": "WazirX",
		"hex": "3067F0",
		"source": "https://wazirx.com"
	},
	{
		"title": "Wear OS",
		"hex": "4285F4",
		"source": "https://partnermarketinghub.withgoogle.com/#/brands/"
	},
	{
		"title": "Weasyl",
		"hex": "990000",
		"source": "https://www.weasyl.com"
	},
	{
		"title": "WEB.DE",
		"hex": "FFD800",
		"source": "https://web.de"
	},
	{
		"title": "Web3.js",
		"hex": "F16822",
		"source": "https://github.com/ChainSafe/web3.js/blob/fdbda4958cbdbaebe8ed5ea59183582b07fac254/assets/logo/web3js.svg"
	},
	{
		"title": "WebAssembly",
		"hex": "654FF0",
		"source": "https://webassembly.org",
		"aliases": {
			"aka": [
				"Wasm"
			]
		}
	},
	{
		"title": "WebAuthn",
		"hex": "3423A6",
		"source": "https://github.com/webauthn-open-source/webauthn-logos/blob/b21be672811eb4a5caadaba41044970cae299a55/final-webauthn-logo-logo-black.svg",
		"guidelines": "https://github.com/webauthn-open-source/webauthn-logos/blob/b21be672811eb4a5caadaba41044970cae299a55/README.md"
	},
	{
		"title": "webcomponents.org",
		"hex": "29ABE2",
		"source": "https://www.webcomponents.org"
	},
	{
		"title": "WebdriverIO",
		"hex": "EA5906",
		"source": "https://webdriver.io/docs/api"
	},
	{
		"title": "Webex",
		"hex": "000000",
		"source": "https://github.com/momentum-design/momentum-ui/blob/970c5bec962a3f72e17e0b7ed69f2c38d298c405/icons-rebrand/svg/webex-helix-filled.svg",
		"guidelines": "https://resources.webex.com/webex/brand-exchange-collection",
		"license": {
			"type": "custom",
			"url": "https://www.cisco.com/c/en/us/about/legal/trademarks.html"
		}
	},
	{
		"title": "Webflow",
		"hex": "146EF5",
		"source": "https://brand-at.webflow.io/resources#logos",
		"guidelines": "https://brand-at.webflow.io"
	},
	{
		"title": "WebGL",
		"hex": "990000",
		"source": "https://www.khronos.org/legal/trademarks",
		"guidelines": "https://www.khronos.org/files/legal/Khronos-Logo-Usage-Guide.pdf"
	},
	{
		"title": "WebGPU",
		"hex": "005A9C",
		"source": "https://www.w3.org/2023/02/webgpu-logos.html",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "Weblate",
		"hex": "2ECCAA",
		"source": "https://github.com/WeblateOrg/graphics/blob/669e4f910abd9ec36fda172d2ea6f2f424a32ace/logo/weblate-black.svg",
		"license": {
			"type": "GPL-3.0-only"
		}
	},
	{
		"title": "Webmin",
		"hex": "7DA0D0",
		"source": "https://github.com/webmin/webmin/blob/84d2d3d17f638a43939220f78b83bfefbae37f76/images/webmin-blue.svg"
	},
	{
		"title": "WebMoney",
		"hex": "036CB5",
		"source": "https://www.webmoney.ru/rus/developers/logos.shtml"
	},
	{
		"title": "Webpack",
		"hex": "8DD6F9",
		"source": "https://webpack.js.org/branding",
		"guidelines": "https://webpack.js.org/branding",
		"license": {
			"type": "custom",
			"url": "https://js.foundation/about/governance/trademark-policy"
		}
	},
	{
		"title": "WebRTC",
		"hex": "333333",
		"source": "https://webrtc.org"
	},
	{
		"title": "WebStorm",
		"hex": "000000",
		"source": "https://www.jetbrains.com/company/brand/logos",
		"guidelines": "https://www.jetbrains.com/company/brand"
	},
	{
		"title": "WEBTOON",
		"hex": "00D564",
		"source": "https://webtoons.com"
	},
	{
		"title": "webtrees",
		"hex": "2694E8",
		"source": "https://webtrees.net",
		"guidelines": "https://wtwi.jprodina.cz/index.php?title=Logo_webtrees"
	},
	{
		"title": "WeChat",
		"hex": "07C160",
		"source": "https://wechat.design/tool/brand",
		"guidelines": "https://wechat.design/brand/main-brand"
	},
	{
		"title": "WeGame",
		"hex": "FAAB00",
		"source": "https://www.wegame.com.cn"
	},
	{
		"title": "Weights & Biases",
		"hex": "FFBE00",
		"source": "https://wandb.ai"
	},
	{
		"title": "Welcome to the Jungle",
		"hex": "FFCD00",
		"source": "https://www.welcometothejungle.com",
		"aliases": {
			"aka": [
				"WTTJ"
			]
		}
	},
	{
		"title": "Wellfound",
		"hex": "000000",
		"source": "https://wellfound.com/logo"
	},
	{
		"title": "Wells Fargo",
		"hex": "D71E28",
		"source": "https://www.wellsfargo.com/about"
	},
	{
		"title": "WEMO",
		"hex": "72D44C",
		"source": "https://commons.wikimedia.org/wiki/File:WeMoApp.svg"
	},
	{
		"title": "Western Digital",
		"hex": "995DFF",
		"source": "https://www.westerndigital.com",
		"aliases": {
			"aka": [
				"WD"
			]
		}
	},
	{
		"title": "Western Union",
		"hex": "FFDD00",
		"source": "https://www.westernunion.com"
	},
	{
		"title": "WeTransfer",
		"hex": "409FFF",
		"source": "https://wetransfer.com"
	},
	{
		"title": "WezTerm",
		"hex": "4E49EE",
		"source": "https://github.com/wez/wezterm/blob/fe78b5821fc106c1061f4c1cc454ff01e74bf97d/assets/icon/wezterm-icon.svg"
	},
	{
		"title": "wgpu",
		"hex": "40E0D0",
		"source": "https://wgpu.rs"
	},
	{
		"title": "WhatsApp",
		"hex": "25D366",
		"source": "https://about.meta.com/brand/resources/whatsapp/whatsapp-brand",
		"guidelines": "https://about.meta.com/brand/resources/whatsapp/whatsapp-brand"
	},
	{
		"title": "When I Work",
		"hex": "51A33D",
		"source": "https://wheniwork.com"
	},
	{
		"title": "wiki.gg",
		"hex": "FF1985",
		"source": "https://commons.wiki.gg/wiki/Category:Wiki.gg_logos"
	},
	{
		"title": "Wiki.js",
		"hex": "1976D2",
		"source": "https://cdn.js.wiki/images/wikijs-butterfly-mono.svg"
	},
	{
		"title": "Wikibooks",
		"hex": "006699",
		"source": "https://commons.wikimedia.org/wiki/File:Wikibooks-logo-white.svg"
	},
	{
		"title": "Wikidata",
		"hex": "006699",
		"source": "https://commons.wikimedia.org/wiki/File:Wikidata-logo-en.svg"
	},
	{
		"title": "Wikimedia Commons",
		"hex": "006699",
		"source": "https://commons.wikimedia.org/wiki/File:Commons-logo.svg"
	},
	{
		"title": "Wikimedia Foundation",
		"hex": "000000",
		"source": "https://foundation.wikimedia.org/wiki/File:Wikimedia-logo_black.svg",
		"guidelines": "https://foundation.wikimedia.org/wiki/Wikimedia_visual_identity_guidelines"
	},
	{
		"title": "Wikipedia",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:Wikipedia-logo-v2.svg"
	},
	{
		"title": "Wikiquote",
		"hex": "006699",
		"source": "https://commons.wikimedia.org/wiki/File:Wikiquote-logo.svg"
	},
	{
		"title": "Wikiversity",
		"hex": "00649A",
		"source": "https://commons.wikimedia.org/wiki/File:Wikiversity-logo-white.svg"
	},
	{
		"title": "Wikivoyage",
		"hex": "006699",
		"source": "https://commons.wikimedia.org/wiki/File:Wikivoyage-Logo-v3-en.svg"
	},
	{
		"title": "Winamp",
		"hex": "F93821",
		"source": "https://www.winamp.com"
	},
	{
		"title": "Wine",
		"hex": "800000",
		"source": "https://gitlab.winehq.org/wine/wine/-/blob/658df7f2121d4dc7c6e6044b9527e07391843250/programs/winecfg/logo.svg"
	},
	{
		"title": "Wipro",
		"hex": "341C53",
		"source": "https://www.wipro.com/content/dam/nexus/en/service-lines/applications/latest-thinking/state-of-cybersecurity-report-2019.pdf"
	},
	{
		"title": "Wire",
		"hex": "000000",
		"source": "https://brand.wire.com",
		"guidelines": "https://brand.wire.com"
	},
	{
		"title": "WireGuard",
		"hex": "88171A",
		"source": "https://www.wireguard.com",
		"guidelines": "https://www.wireguard.com/trademark-policy"
	},
	{
		"title": "Wireshark",
		"hex": "1679A7",
		"source": "https://gitlab.com/wanduow/wireshark/-/blob/cd5539b0f76975474869984a9d2f0fce29d5c21e/image/wsicon.svg"
	},
	{
		"title": "Wise",
		"hex": "9FE870",
		"source": "https://wise.design/foundations/logo",
		"guidelines": "https://wise.design/foundations/logo"
	},
	{
		"title": "Wish",
		"hex": "32E476",
		"source": "https://wish.com"
	},
	{
		"title": "Wistia",
		"hex": "58B7FE",
		"source": "https://wistia.com/about/assets",
		"guidelines": "https://wistia.com/about/assets"
	},
	{
		"title": "Wix",
		"hex": "0C6EFC",
		"source": "https://www.wix.com/about/design-assets",
		"guidelines": "https://www.wix.com/about/design-assets"
	},
	{
		"title": "Wizz Air",
		"hex": "C6007E",
		"source": "https://wizzair.com/en-gb/information-and-services/about-us/press-office/logos"
	},
	{
		"title": "Wolfram",
		"hex": "DD1100",
		"source": "https://company.wolfram.com/press-center/wolfram-corporate"
	},
	{
		"title": "Wolfram Language",
		"hex": "DD1100",
		"source": "https://company.wolfram.com/press-center/language"
	},
	{
		"title": "Wolfram Mathematica",
		"hex": "DD1100",
		"source": "https://company.wolfram.com/press-center/mathematica"
	},
	{
		"title": "Wondershare",
		"hex": "000000",
		"source": "https://www.wondershare.com/news/media-assets.html"
	},
	{
		"title": "Wondershare Filmora",
		"hex": "07273D",
		"source": "https://filmora.wondershare.com"
	},
	{
		"title": "Woo",
		"hex": "96588A",
		"source": "https://woocommerce.com/style-guide",
		"guidelines": "https://woocommerce.com/trademark-guidelines"
	},
	{
		"title": "WooCommerce",
		"hex": "96588A",
		"source": "https://woocommerce.com/style-guide",
		"guidelines": "https://woocommerce.com/trademark-guidelines"
	},
	{
		"title": "WordPress",
		"hex": "21759B",
		"source": "https://wordpress.org/about/logos",
		"guidelines": "https://wordpressfoundation.org/trademark-policy"
	},
	{
		"title": "Workplace",
		"hex": "4526CE",
		"source": "https://about.meta.com/brand/resources/workplace/workplace-brand",
		"guidelines": "https://about.meta.com/brand/resources/workplace/workplace-brand"
	},
	{
		"title": "World Health Organization",
		"hex": "0093D5",
		"source": "https://www.who.int"
	},
	{
		"title": "WP Engine",
		"hex": "0ECAD4",
		"source": "https://wpengine.com/brand-assets",
		"guidelines": "https://wpengine.com/brand-assets"
	},
	{
		"title": "WP Rocket",
		"hex": "F56640",
		"source": "https://wp-rocket.me"
	},
	{
		"title": "WPExplorer",
		"hex": "2563EB",
		"source": "https://wpexplorer.com"
	},
	{
		"title": "Write.as",
		"hex": "5AC4EE",
		"source": "https://write.as/brand",
		"guidelines": "https://write.as/brand"
	},
	{
		"title": "WWE",
		"hex": "000000",
		"source": "https://commons.wikimedia.org/wiki/File:WWE_Network_logo.svg"
	},
	{
		"title": "Wwise",
		"hex": "00549F",
		"source": "https://www.audiokinetic.com/resources/credits/",
		"guidelines": "https://www.audiokinetic.com/resources/credits/"
	},
	{
		"title": "WXT",
		"hex": "67D55E",
		"source": "https://github.com/wxt-dev/wxt/blob/0d540a6df9c1bf55bb8209c4d881715719fa03b1/docs/public/logo.svg"
	},
	{
		"title": "Wykop",
		"hex": "367DA9",
		"source": "https://wykop.pl"
	},
	{
		"title": "Wyze",
		"hex": "1DF0BB",
		"source": "https://www.wyze.com"
	},
	{
		"title": "X",
		"hex": "000000",
		"source": "https://x.com",
		"guidelines": "https://about.x.com/en/who-we-are/brand-toolkit",
		"aliases": {
			"aka": [
				"Twitter"
			]
		}
	},
	{
		"title": "X.Org",
		"hex": "F28834",
		"source": "https://commons.wikimedia.org/wiki/File:X.Org_Logo.svg"
	},
	{
		"title": "XAMPP",
		"hex": "FB7A24",
		"source": "https://apachefriends.org"
	},
	{
		"title": "Xcode",
		"hex": "147EFB",
		"source": "https://developer.apple.com/develop"
	},
	{
		"title": "XDA Developers",
		"hex": "EA7100",
		"source": "https://www.xda-developers.com"
	},
	{
		"title": "Xendit",
		"hex": "4573FF",
		"source": "https://www.xendit.co/en/company/asset-and-branding"
	},
	{
		"title": "Xero",
		"hex": "13B5EA",
		"source": "https://www.xero.com/uk/about/media/downloads"
	},
	{
		"title": "XFCE",
		"hex": "2284F2",
		"source": "https://www.xfce.org/download#artwork"
	},
	{
		"title": "Xiaohongshu",
		"hex": "FF2442",
		"source": "https://pro.xiaohongshu.com",
		"aliases": {
			"loc": {
				"zh-CN": "小红书"
			}
		}
	},
	{
		"title": "Xiaomi",
		"hex": "FF6900",
		"source": "https://www.mi.com/global"
	},
	{
		"title": "Xing",
		"hex": "006567",
		"source": "https://dev.xing.com/logo_rules"
	},
	{
		"title": "XML",
		"hex": "005FAD",
		"source": "https://www.w3.org/Icons/XML",
		"aliases": {
			"aka": [
				"Extensible Markup Language"
			]
		}
	},
	{
		"title": "XMPP",
		"hex": "002B5C",
		"source": "https://github.com/xsf/xmpp.org/blob/82856a2cec0a99b197c6985191635544e6b3ed69/static/images/logos/xmpp-logo.svg"
	},
	{
		"title": "XO",
		"hex": "5ED9C7",
		"source": "https://github.com/xojs/xo/tree/f9c7db99255d009b3c81535ced021c3f6ade57b4"
	},
	{
		"title": "XRP",
		"hex": "25A768",
		"source": "https://xrpl.org"
	},
	{
		"title": "XSplit",
		"hex": "0095DE",
		"source": "https://www.xsplit.com/presskit"
	},
	{
		"title": "XState",
		"hex": "2C3E50",
		"source": "https://github.com/davidkpiano/xstate/blob/544df7f00e2ef49603b5e5ff2f0d183ff6bd5e7c/docs/.vuepress/public/logo.svg"
	},
	{
		"title": "Xubuntu",
		"hex": "0044AA",
		"source": "https://commons.wikimedia.org/wiki/File:Xubuntu_Icon.svg"
	},
	{
		"title": "xyflow",
		"hex": "1A192B",
		"source": "https://github.com/xyflow/web/blob/fe6af5d1c78de492fc64a39ab8a2085f1eb7164d/sites/xyflow.com/public/img/favicon.svg",
		"aliases": {
			"aka": [
				"reactflow",
				"svelteflow"
			]
		}
	},
	{
		"title": "Y Combinator",
		"hex": "F0652F",
		"source": "https://www.ycombinator.com/press"
	},
	{
		"title": "yabai",
		"hex": "00364B",
		"source": "https://github.com/koekeishiya/yabai/blob/86c759186d7c588dfd8c6a84aac1ebc4730e988e/assets/icon/icon.svg"
	},
	{
		"title": "Yale",
		"hex": "FFD900",
		"source": "https://yalehome.com"
	},
	{
		"title": "Yamaha Corporation",
		"hex": "4B1E78",
		"source": "https://www.yamaha.com/en/"
	},
	{
		"title": "Yamaha Motor Corporation",
		"hex": "E60012",
		"source": "https://commons.wikimedia.org/wiki/File:Yamaha_Motor_Logo_(full).svg"
	},
	{
		"title": "YAML",
		"hex": "CB171E",
		"source": "https://commons.wikimedia.org/wiki/File:Official_YAML_Logo.svg"
	},
	{
		"title": "Yandex Cloud",
		"hex": "5282FF",
		"source": "https://cloud.yandex.com/en/brandbook",
		"guidelines": "https://cloud.yandex.com/en/brandbook"
	},
	{
		"title": "Yarn",
		"hex": "2C8EBB",
		"source": "https://github.com/yarnpkg/assets/blob/76d30ca2aebed5b73ea8131d972218fb860bd32d/yarn-kitten-circle.svg",
		"guidelines": "https://github.com/yarnpkg/assets/tree/76d30ca2aebed5b73ea8131d972218fb860bd32d",
		"license": {
			"type": "CC-BY-4.0"
		}
	},
	{
		"title": "Yelp",
		"hex": "FF1A1A",
		"source": "https://www.yelp.com/brand",
		"guidelines": "https://www.yelp.com/brand"
	},
	{
		"title": "Yeti",
		"hex": "00263C",
		"source": "https://www.yeti.com"
	},
	{
		"title": "Yii",
		"hex": "40B3D8",
		"source": "https://www.yiiframework.com"
	},
	{
		"title": "Yoast",
		"hex": "A61E69",
		"source": "https://yoast.com/brand",
		"guidelines": "https://yoast.com/brand"
	},
	{
		"title": "YOLO",
		"hex": "111F68",
		"source": "https://www.ultralytics.com/brand",
		"guidelines": "https://www.ultralytics.com/brand"
	},
	{
		"title": "YouHodler",
		"hex": "546DF9",
		"source": "https://www.youhodler.com/company"
	},
	{
		"title": "YouTube",
		"hex": "FF0000",
		"source": "https://www.youtube.com/howyoutubeworks/resources/brand-resources/#logos-icons-and-colors",
		"guidelines": "https://www.youtube.com/howyoutubeworks/resources/brand-resources/#logos-icons-and-colors"
	},
	{
		"title": "YouTube Gaming",
		"hex": "FF0000",
		"source": "https://gaming.youtube.com"
	},
	{
		"title": "YouTube Kids",
		"hex": "FF0000",
		"source": "https://www.youtube.com/intl/ALL_us/kids"
	},
	{
		"title": "YouTube Music",
		"hex": "FF0000",
		"source": "https://partnermarketinghub.withgoogle.com/#/brands"
	},
	{
		"title": "YouTube Shorts",
		"hex": "FF0000",
		"source": "https://www.youtube.com/shorts"
	},
	{
		"title": "YouTube Studio",
		"hex": "FF0000",
		"source": "https://www.youtube.com"
	},
	{
		"title": "YouTube TV",
		"hex": "FF0000",
		"source": "https://partnermarketinghub.withgoogle.com/#/brands"
	},
	{
		"title": "Yr",
		"hex": "00B9F1",
		"source": "https://www.yr.no"
	},
	{
		"title": "Yubico",
		"hex": "84BD00",
		"source": "https://www.yubico.com/wp-content/themes/coronado/img/icon.svg"
	},
	{
		"title": "YunoHost",
		"hex": "000000",
		"source": "https://github.com/YunoHost/doc/blob/0157b052481407b3c06cc2892de225f14c42520b/images/ynh_logo_black.svg"
	},
	{
		"title": "Żabka",
		"hex": "006420",
		"source": "https://www.zabka.pl"
	},
	{
		"title": "Zaim",
		"hex": "50A135",
		"source": "https://zaim.net"
	},
	{
		"title": "Zalando",
		"hex": "FF6900",
		"source": "https://www.zalando.co.uk"
	},
	{
		"title": "Zalo",
		"hex": "0068FF",
		"source": "https://zalo.me"
	},
	{
		"title": "ZAP",
		"hex": "00549E",
		"source": "https://www.zaproxy.org",
		"aliases": {
			"aka": [
				"Zed Attack Proxy"
			]
		}
	},
	{
		"title": "Zapier",
		"hex": "FF4F00",
		"source": "https://www.figma.com/file/NQFxTCE5pGR3dHZt0DkOyy/Zapier-Brand-Guidelines-%5BExternal%5D?type=design&node-id=101-9701&mode=design",
		"guidelines": "https://www.figma.com/file/NQFxTCE5pGR3dHZt0DkOyy/Zapier-Brand-Guidelines-%5BExternal%5D?type=design&node-id=101-9701&mode=design"
	},
	{
		"title": "Zara",
		"hex": "000000",
		"source": "https://www.zara.com"
	},
	{
		"title": "Zazzle",
		"hex": "212121",
		"source": "https://www.zazzle.com/logo",
		"guidelines": "https://www.zazzle.com/logo"
	},
	{
		"title": "Zcash",
		"hex": "F3B724",
		"source": "https://z.cash",
		"guidelines": "https://zfnd.org/trademark-policy",
		"aliases": {
			"aka": [
				"ZEC"
			]
		}
	},
	{
		"title": "ZCOOL",
		"hex": "FFF200",
		"source": "https://www.zcool.com.cn/appdown"
	},
	{
		"title": "ZDF",
		"hex": "FA7D19",
		"source": "https://www.zdf.de"
	},
	{
		"title": "ZebPay",
		"hex": "2072EF",
		"source": "https://www.zebpay.com"
	},
	{
		"title": "Zebra Technologies",
		"hex": "000000",
		"source": "https://www.zebra.com"
	},
	{
		"title": "Zed Industries",
		"hex": "084CCF",
		"source": "https://github.com/zed-industries/zed/blob/ccc939124fa2f366b3029926447fd0a0c46a85c7/assets/icons/logo_96.svg"
	},
	{
		"title": "Zelle",
		"hex": "6D1ED4",
		"source": "https://www.zellepay.com"
	},
	{
		"title": "Zen Browser",
		"hex": "F76F53",
		"source": "https://github.com/zen-browser/branding/blob/4b99730c9d3c8fe3ec71d31a07e74cfd488fc27f/Official/Word%20Marks/SVG/zen_logo_icon_color.svg"
	},
	{
		"title": "Zend",
		"hex": "0679EA",
		"source": "https://www.zend.com"
	},
	{
		"title": "Zendesk",
		"hex": "03363D",
		"source": "https://brandland.zendesk.com",
		"guidelines": "https://brandland.zendesk.com"
	},
	{
		"title": "Zenn",
		"hex": "3EA8FF",
		"source": "https://zenn.dev/mediakit"
	},
	{
		"title": "Zenodo",
		"hex": "1682D4",
		"source": "https://about.zenodo.org",
		"guidelines": "https://about.zenodo.org"
	},
	{
		"title": "Zensar",
		"hex": "000000",
		"source": "https://www.zensar.com/about/our-story/our-brand/#logo"
	},
	{
		"title": "Zerodha",
		"hex": "387ED1",
		"source": "https://zerodha.com"
	},
	{
		"title": "ZeroTier",
		"hex": "FFB441",
		"source": "https://www.zerotier.com",
		"guidelines": "https://www.zerotier.com/media-kit"
	},
	{
		"title": "Zettlr",
		"hex": "1CB27E",
		"source": "https://www.zettlr.com",
		"guidelines": "https://www.zettlr.com/press"
	},
	{
		"title": "Zhihu",
		"hex": "0084FF",
		"source": "https://www.zhihu.com"
	},
	{
		"title": "Zig",
		"hex": "F7A41D",
		"source": "https://github.com/ziglang/logo/blob/6446ba8e37a0651da720d8869e1ce9264fa0c0b9/zig-mark.svg",
		"license": {
			"type": "CC-BY-SA-4.0"
		}
	},
	{
		"title": "Zigbee",
		"hex": "EB0443",
		"source": "https://csa-iot.org/all-solutions/zigbee"
	},
	{
		"title": "Zigbee2MQTT",
		"hex": "FFC135",
		"source": "https://github.com/Koenkk/zigbee2mqtt/blob/434981b567122c745c6a5228cd89b74694b15e4c/images/logo_vector.svg"
	},
	{
		"title": "Ziggo",
		"hex": "F48C00",
		"source": "https://www.ziggosport.nl"
	},
	{
		"title": "Zilch",
		"hex": "00D287",
		"source": "https://www.zilch.com"
	},
	{
		"title": "Zillow",
		"hex": "006AFF",
		"source": "https://www.zillow.com"
	},
	{
		"title": "ZincSearch",
		"hex": "5BA37F",
		"source": "https://github.com/zincsearch/zincsearch-docs/blob/f5b8bec0c05c10968f54aca3eabde9d4d77a1712/docs/images/logo.svg"
	},
	{
		"title": "Zingat",
		"hex": "009CFB",
		"source": "https://www.zingat.com"
	},
	{
		"title": "Zod",
		"hex": "3E67B1",
		"source": "https://zod.dev",
		"license": {
			"type": "MIT"
		}
	},
	{
		"title": "Zoho",
		"hex": "E42527",
		"source": "https://www.zoho.com/branding"
	},
	{
		"title": "Zoiper",
		"hex": "F47920",
		"source": "https://www.zoiper.com/en/products"
	},
	{
		"title": "Zomato",
		"hex": "E23744",
		"source": "https://www.zomato.com/business/apps"
	},
	{
		"title": "Zoom",
		"hex": "0B5CFF",
		"source": "https://brand.zoom.us/media-library/",
		"guidelines": "https://brand.zoom.us/usage-legal/"
	},
	{
		"title": "Zorin",
		"hex": "15A6F0",
		"source": "https://zorin.com/press"
	},
	{
		"title": "Zotero",
		"hex": "CC2936",
		"source": "https://www.zotero.org/support/brand"
	},
	{
		"title": "Zsh",
		"hex": "F15A24",
		"source": "https://github.com/Zsh-art/logo/blob/17617f2f6c70c65943a48745c91d997e7561f19d/svg/white_logomark.svg"
	},
	{
		"title": "Zulip",
		"hex": "6492FE",
		"source": "https://github.com/zulip/zulip/blob/df9e40491dc77b658d943cff36a816d46e32ce1b/static/images/logo/zulip-org-logo.svg"
	},
	{
		"title": "Zyte",
		"hex": "B02CCE",
		"source": "https://www.zyte.com"
	}
]

